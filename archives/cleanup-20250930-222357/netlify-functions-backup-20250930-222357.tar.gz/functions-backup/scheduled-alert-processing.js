const { createClient } = require('@supabase/supabase-js');

// Environment variables
const supabaseUrl = process.env.SUPABASE_URL;
const supabaseServiceKey = process.env.SUPABASE_SERVICE_ROLE_KEY;

exports.handler = async (event, context) => {
  const headers = {
    'Content-Type': 'application/json'
  };

  try {
    console.log('Starting scheduled alert processing...');
    
    // Initialize Supabase
    const supabase = createClient(supabaseUrl, supabaseServiceKey);

    // Step 1: Process alert matching for recent articles
    console.log('Processing alert matching...');
    const matchingResult = await processAlertMatching();
    
    // Step 2: Send immediate notifications
    console.log('Sending immediate notifications...');
    const immediateNotifications = await sendImmediateNotifications();
    
    // Step 3: Log processing statistics
    await logProcessingStats(supabase, {
      articlesProcessed: matchingResult.processed || 0,
      matchesFound: matchingResult.matches || 0,
      immediateNotificationsSent: immediateNotifications.emailsSent + immediateNotifications.whatsappSent || 0
    });

    const result = {
      success: true,
      timestamp: new Date().toISOString(),
      alertMatching: matchingResult,
      notifications: immediateNotifications,
      message: 'Scheduled alert processing completed successfully'
    };

    console.log('Alert processing completed:', result);

    return {
      statusCode: 200,
      headers,
      body: JSON.stringify(result)
    };

  } catch (error) {
    console.error('Error in scheduled alert processing:', error);
    
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({
        error: 'Scheduled processing failed',
        message: error.message,
        timestamp: new Date().toISOString()
      })
    };
  }
};

async function processAlertMatching() {
  try {
    const response = await fetch(`${process.env.URL}/.netlify/functions/process-alert-matching`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({}) // Process recent articles
    });

    if (!response.ok) {
      throw new Error(`Alert matching failed: ${response.status}`);
    }

    return await response.json();
  } catch (error) {
    console.error('Error processing alert matching:', error);
    return { success: false, error: error.message };
  }
}

async function sendImmediateNotifications() {
  try {
    const response = await fetch(`${process.env.URL}/.netlify/functions/send-alert-notifications`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({ frequency: 'immediate' })
    });

    if (!response.ok) {
      throw new Error(`Notification sending failed: ${response.status}`);
    }

    return await response.json();
  } catch (error) {
    console.error('Error sending immediate notifications:', error);
    return { success: false, error: error.message, emailsSent: 0, whatsappSent: 0 };
  }
}

async function logProcessingStats(supabase, stats) {
  try {
    const { error } = await supabase
      .from('alert_processing_logs')
      .insert({
        processed_at: new Date().toISOString(),
        articles_processed: stats.articlesProcessed,
        matches_found: stats.matchesFound,
        notifications_sent: stats.immediateNotificationsSent,
        processing_type: 'scheduled_immediate'
      });

    if (error) {
      console.error('Error logging processing stats:', error);
    }
  } catch (error) {
    console.error('Error in logProcessingStats:', error);
  }
}
