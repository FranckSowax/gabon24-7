const { createClient } = require('@supabase/supabase-js');
const { extractFacebookGabon24Image } = require('./facebook-gabon24-image-extractor');

// Configuration Supabase
const supabaseUrl = process.env.SUPABASE_URL;
const supabaseServiceKey = process.env.SUPABASE_SERVICE_ROLE_KEY;
const supabase = createClient(supabaseUrl, supabaseServiceKey);

// Fonction pour tester l'extraction d'images sur des posts Facebook Gabon 24
async function testFacebookGabon24ImageExtraction() {
  try {
    console.log('🧪 [TEST] Début du test d\'extraction d\'images Facebook Gabon 24...');

    // Récupérer quelques articles Facebook Gabon 24 récents depuis la base
    const { data: articles, error } = await supabase
      .from('articles')
      .select('id, title, link, image_url, source')
      .eq('source', 'Gabon 24')
      .ilike('link', '%facebook.com%')
      .order('created_at', { ascending: false })
      .limit(8);

    if (error) {
      console.error('❌ Erreur récupération articles:', error);
      return { success: false, error: error.message };
    }

    if (!articles || articles.length === 0) {
      console.log('⚠️ Aucun article Facebook Gabon 24 trouvé dans la base');
      return { success: false, message: 'Aucun article Facebook trouvé' };
    }

    console.log(`📊 ${articles.length} articles Facebook Gabon 24 trouvés pour test`);

    const results = [];
    let successCount = 0;
    let failureCount = 0;

    // Tester l'extraction pour chaque article
    for (const article of articles) {
      console.log(`\n🔍 Test post: ${article.title.substring(0, 50)}...`);
      console.log(`   URL: ${article.link}`);
      console.log(`   Image actuelle: ${article.image_url || 'Aucune'}`);

      try {
        // Tenter l'extraction d'image Facebook
        const extractedImage = await extractFacebookGabon24Image(article.link);
        
        const result = {
          articleId: article.id,
          title: article.title.substring(0, 100),
          link: article.link,
          currentImage: article.image_url,
          extractedImage: extractedImage,
          success: !!extractedImage,
          needsUpdate: !article.image_url || 
                      article.image_url.includes('unsplash.com') ||
                      article.image_url.includes('placeholder')
        };

        results.push(result);

        if (extractedImage) {
          successCount++;
          console.log(`   ✅ Image extraite: ${extractedImage.substring(0, 80)}...`);
          
          // Si l'article n'a pas d'image ou a une image générique, proposer la mise à jour
          if (result.needsUpdate) {
            console.log(`   🔄 Article nécessite une mise à jour d'image`);
          }
        } else {
          failureCount++;
          console.log(`   ❌ Aucune image extraite`);
        }

      } catch (error) {
        failureCount++;
        console.error(`   ❌ Erreur extraction: ${error.message}`);
        results.push({
          articleId: article.id,
          title: article.title.substring(0, 100),
          link: article.link,
          currentImage: article.image_url,
          extractedImage: null,
          success: false,
          error: error.message
        });
      }

      // Pause entre les tests pour éviter la surcharge Facebook
      await new Promise(resolve => setTimeout(resolve, 2000));
    }

    // Résumé des résultats
    console.log(`\n📊 RÉSULTATS DU TEST FACEBOOK GABON 24:`);
    console.log(`   ✅ Succès: ${successCount}/${articles.length}`);
    console.log(`   ❌ Échecs: ${failureCount}/${articles.length}`);
    console.log(`   📈 Taux de réussite: ${((successCount / articles.length) * 100).toFixed(1)}%`);

    // Compter les articles qui nécessitent une mise à jour
    const needsUpdate = results.filter(r => r.needsUpdate && r.success).length;
    console.log(`   🔄 Articles pouvant être mis à jour: ${needsUpdate}`);

    // Analyser les types d'images extraites
    const imageTypes = results
      .filter(r => r.extractedImage)
      .map(r => {
        if (r.extractedImage.includes('fbcdn.net')) return 'Facebook CDN';
        if (r.extractedImage.includes('scontent')) return 'Facebook Content';
        return 'Autre';
      });
    
    const typeStats = imageTypes.reduce((acc, type) => {
      acc[type] = (acc[type] || 0) + 1;
      return acc;
    }, {});

    console.log(`   📸 Types d'images extraites:`, typeStats);

    return {
      success: true,
      summary: {
        totalTested: articles.length,
        successCount,
        failureCount,
        successRate: ((successCount / articles.length) * 100).toFixed(1),
        needsUpdate,
        imageTypes: typeStats
      },
      results
    };

  } catch (error) {
    console.error('❌ Erreur générale du test:', error);
    return { success: false, error: error.message };
  }
}

// Handler Netlify
exports.handler = async (event, context) => {
  const headers = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'Content-Type',
    'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
  };

  if (event.httpMethod === 'OPTIONS') {
    return { statusCode: 200, headers, body: '' };
  }

  try {
    const testResults = await testFacebookGabon24ImageExtraction();
    
    return {
      statusCode: 200,
      headers,
      body: JSON.stringify({
        timestamp: new Date().toISOString(),
        platform: 'Facebook Gabon 24',
        ...testResults
      })
    };

  } catch (error) {
    console.error('Error in test-facebook-gabon24-images:', error);
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({
        success: false,
        error: error.message,
        timestamp: new Date().toISOString()
      })
    };
  }
};
