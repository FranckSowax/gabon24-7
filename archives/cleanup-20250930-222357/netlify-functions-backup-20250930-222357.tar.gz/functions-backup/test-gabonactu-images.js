const { createClient } = require('@supabase/supabase-js');
const { extractGabonActuImage } = require('./gabonactu-image-extractor');

// Configuration Supabase
const supabaseUrl = process.env.SUPABASE_URL;
const supabaseServiceKey = process.env.SUPABASE_SERVICE_ROLE_KEY;
const supabase = createClient(supabaseUrl, supabaseServiceKey);

// Fonction pour tester l'extraction d'images sur des articles Gabon Actu existants
async function testGabonActuImageExtraction() {
  try {
    console.log('🧪 [TEST] Début du test d\'extraction d\'images Gabon Actu...');

    // Récupérer quelques articles Gabon Actu récents depuis la base
    const { data: articles, error } = await supabase
      .from('articles')
      .select('id, title, link, image_url, source')
      .eq('source', 'Gabon Actu')
      .order('created_at', { ascending: false })
      .limit(10);

    if (error) {
      console.error('❌ Erreur récupération articles:', error);
      return { success: false, error: error.message };
    }

    if (!articles || articles.length === 0) {
      console.log('⚠️ Aucun article Gabon Actu trouvé dans la base');
      return { success: false, message: 'Aucun article trouvé' };
    }

    console.log(`📊 ${articles.length} articles Gabon Actu trouvés pour test`);

    const results = [];
    let successCount = 0;
    let failureCount = 0;

    // Tester l'extraction pour chaque article
    for (const article of articles) {
      console.log(`\n🔍 Test article: ${article.title.substring(0, 50)}...`);
      console.log(`   URL: ${article.link}`);
      console.log(`   Image actuelle: ${article.image_url || 'Aucune'}`);

      try {
        // Tenter l'extraction d'image
        const extractedImage = await extractGabonActuImage(article.link);
        
        const result = {
          articleId: article.id,
          title: article.title.substring(0, 100),
          link: article.link,
          currentImage: article.image_url,
          extractedImage: extractedImage,
          success: !!extractedImage,
          needsUpdate: !article.image_url || article.image_url.includes('unsplash.com')
        };

        results.push(result);

        if (extractedImage) {
          successCount++;
          console.log(`   ✅ Image extraite: ${extractedImage}`);
          
          // Si l'article n'a pas d'image ou a une image Unsplash, proposer la mise à jour
          if (result.needsUpdate) {
            console.log(`   🔄 Article nécessite une mise à jour d'image`);
          }
        } else {
          failureCount++;
          console.log(`   ❌ Aucune image extraite`);
        }

      } catch (error) {
        failureCount++;
        console.error(`   ❌ Erreur extraction: ${error.message}`);
        results.push({
          articleId: article.id,
          title: article.title.substring(0, 100),
          link: article.link,
          currentImage: article.image_url,
          extractedImage: null,
          success: false,
          error: error.message
        });
      }

      // Pause entre les tests pour éviter la surcharge
      await new Promise(resolve => setTimeout(resolve, 1000));
    }

    // Résumé des résultats
    console.log(`\n📊 RÉSULTATS DU TEST:`);
    console.log(`   ✅ Succès: ${successCount}/${articles.length}`);
    console.log(`   ❌ Échecs: ${failureCount}/${articles.length}`);
    console.log(`   📈 Taux de réussite: ${((successCount / articles.length) * 100).toFixed(1)}%`);

    // Compter les articles qui nécessitent une mise à jour
    const needsUpdate = results.filter(r => r.needsUpdate && r.success).length;
    console.log(`   🔄 Articles pouvant être mis à jour: ${needsUpdate}`);

    return {
      success: true,
      summary: {
        totalTested: articles.length,
        successCount,
        failureCount,
        successRate: ((successCount / articles.length) * 100).toFixed(1),
        needsUpdate
      },
      results
    };

  } catch (error) {
    console.error('❌ Erreur générale du test:', error);
    return { success: false, error: error.message };
  }
}

// Handler Netlify
exports.handler = async (event, context) => {
  const headers = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'Content-Type',
    'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
  };

  if (event.httpMethod === 'OPTIONS') {
    return { statusCode: 200, headers, body: '' };
  }

  try {
    const testResults = await testGabonActuImageExtraction();
    
    return {
      statusCode: 200,
      headers,
      body: JSON.stringify({
        timestamp: new Date().toISOString(),
        ...testResults
      })
    };

  } catch (error) {
    console.error('Error in test-gabonactu-images:', error);
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({
        success: false,
        error: error.message,
        timestamp: new Date().toISOString()
      })
    };
  }
};
