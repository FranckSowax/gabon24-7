// Import de la fonction de génération
const { handler: generateDailyPoll } = require('./generate-daily-poll');

// Fonction planifiée qui s'exécute tous les jours à 19h00 GMT (20h00 WAT - Heure du Gabon)
exports.handler = async (event, context) => {
  console.log('⏰ Exécution planifiée - Génération du sondage quotidien...');
  
  try {
    // Créer un événement simulé pour la fonction de génération
    const simulatedEvent = {
      httpMethod: 'POST',
      body: JSON.stringify({
        source: 'scheduled',
        timestamp: new Date().toISOString()
      }),
      headers: {
        'Content-Type': 'application/json'
      }
    };

    // Appeler la fonction de génération
    const result = await generateDailyPoll(simulatedEvent, context);
    
    if (result.statusCode === 200) {
      const data = JSON.parse(result.body);
      console.log('✅ Sondage quotidien généré avec succès:', data.data?.title);
      
      return {
        statusCode: 200,
        body: JSON.stringify({
          success: true,
          message: 'Sondage quotidien généré automatiquement',
          timestamp: new Date().toISOString(),
          poll_data: data.data
        })
      };
    } else {
      console.error('❌ Échec génération sondage:', result.body);
      throw new Error(`Génération échouée: ${result.statusCode}`);
    }
    
  } catch (error) {
    console.error('❌ Erreur lors de l\'exécution planifiée:', error);
    
    // En cas d'erreur, on peut implémenter une notification
    // ou un système de retry ici
    
    return {
      statusCode: 500,
      body: JSON.stringify({
        success: false,
        error: 'Erreur lors de la génération automatique',
        details: error.message,
        timestamp: new Date().toISOString()
      })
    };
  }
};
