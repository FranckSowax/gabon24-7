const { createClient } = require('@supabase/supabase-js')

const supabaseUrl = process.env.SUPABASE_URL
const supabaseServiceKey = process.env.SUPABASE_SERVICE_ROLE_KEY
const openaiApiKey = process.env.OPENAI_API_KEY

console.log('🔍 Environment variables check:')
console.log('SUPABASE_URL:', supabaseUrl ? 'SET' : 'MISSING')
console.log('SUPABASE_SERVICE_ROLE_KEY:', supabaseServiceKey ? 'SET' : 'MISSING')
console.log('OPENAI_API_KEY:', openaiApiKey ? `SET (${openaiApiKey.substring(0, 7)}...)` : 'MISSING')

const supabase = createClient(supabaseUrl, supabaseServiceKey)

exports.handler = async (event, context) => {
  // Set CORS headers
  const headers = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'Content-Type',
    'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
    'Content-Type': 'application/json'
  }

  // Handle preflight requests
  if (event.httpMethod === 'OPTIONS') {
    return {
      statusCode: 200,
      headers
    }
  }

  if (event.httpMethod !== 'POST') {
    return {
      statusCode: 405,
      headers,
      body: JSON.stringify({ error: 'Method not allowed' })
    }
  }

  try {
    const { secteur, problematique, userId } = JSON.parse(event.body)
    
    if (!secteur || !problematique) {
      return {
        statusCode: 400,
        headers,
        body: JSON.stringify({ error: 'Secteur et problématique requis' })
      }
    }

    if (!userId) {
      return {
        statusCode: 400,
        headers,
        body: JSON.stringify({ error: 'User ID is required' })
      }
    }

    console.log('🎯 Generating business ideas for:', { secteur: secteur.nom, problematique, userId })

    // Check user credit balance before processing
    console.log('💳 Checking user credit balance...')
    const creditResponse = await fetch(`${process.env.URL}/.netlify/functions/credit-manager`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        action: 'checkBalance',
        userId: userId
      })
    })

    if (!creditResponse.ok) {
      console.log('❌ Error checking credit balance')
      return {
        statusCode: 500,
        headers,
        body: JSON.stringify({ error: 'Error checking credit balance' })
      }
    }

    const creditData = await creditResponse.json()
    console.log('💰 Credit balance:', creditData.available_balance)

    // Service costs 5 credits for business ideas generation
    const REQUIRED_CREDITS = 5
    if (creditData.available_balance < REQUIRED_CREDITS) {
      console.log(`❌ Insufficient credits: ${creditData.available_balance} < ${REQUIRED_CREDITS}`)
      return {
        statusCode: 402, // Payment Required
        headers,
        body: JSON.stringify({ 
          error: 'Crédits insuffisants', 
          message: `Cette génération d'idées nécessite ${REQUIRED_CREDITS} crédits. Votre solde actuel est de ${creditData.available_balance} crédits.`,
          required_credits: REQUIRED_CREDITS,
          current_balance: creditData.available_balance,
          need_to_purchase: REQUIRED_CREDITS - creditData.available_balance
        })
      }
    }

    // Check if OpenAI API key is available
    if (!openaiApiKey || openaiApiKey.trim() === '') {
      console.log('⚠️ Using DEMO data - OpenAI API key not configured')
      const demoIdeas = generateDemoBusinessIdeas(secteur, problematique)
      return {
        statusCode: 200,
        headers,
        body: JSON.stringify(demoIdeas)
      }
    }

    console.log('🤖 Calling OpenAI for business ideas generation...')
    const businessIdeas = await generateWithOpenAI(secteur, problematique)
    
    // Consume credits after successful AI generation
    console.log('💳 Consuming credits after successful generation...')
    try {
      const consumeResponse = await fetch(`${process.env.URL}/.netlify/functions/credit-manager`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          action: 'consumeCredits',
          userId: userId,
          serviceName: 'generate_business_ideas',
          amount: REQUIRED_CREDITS,
          referenceId: `business_ideas_${Date.now()}`,
          openaiUsage: {
            model: 'gpt-3.5-turbo',
            prompt_tokens: 400, // Estimated
            completion_tokens: 600, // Estimated
            total_tokens: 1000,
            estimated_cost: 0.06 // Estimated in XAF
          }
        })
      })

      if (consumeResponse.ok) {
        console.log('✅ Credits consumed successfully')
      } else {
        console.log('⚠️ Warning: Credit consumption failed, but generation was successful')
      }
    } catch (creditError) {
      console.log('⚠️ Warning: Credit consumption error:', creditError.message)
    }
    
    return {
      statusCode: 200,
      headers,
      body: JSON.stringify(businessIdeas)
    }

  } catch (error) {
    console.error('❌ Error generating business ideas:', error)
    
    // Fallback to demo data on error
    const demoIdeas = generateDemoBusinessIdeas(
      { nom: 'Secteur Général' }, 
      'Problématique générale'
    )
    
    return {
      statusCode: 200,
      headers,
      body: JSON.stringify(demoIdeas)
    }
  }
}

async function generateWithOpenAI(secteur, problematique) {
  const prompt = `
Générez 3 idées de business concrètes pour le secteur "${secteur.nom}" au Gabon, en réponse à cette problématique : "${problematique}"

Contexte du secteur :
- Description : ${secteur.description}
- Potentiel : ${secteur.potentiel}
- Problématique liée : ${secteur.problematique_liee}

Répondez UNIQUEMENT avec un objet JSON valide contenant :
{
  "secteur": "${secteur.nom}",
  "problematique": "${problematique}",
  "idees": [
    {
      "titre": "Nom de l'idée business 1",
      "description": "Description détaillée de l'idée (150-200 mots)",
      "investissement": "Investissement initial estimé en FCFA",
      "revenus_potentiels": "Revenus potentiels mensuels en FCFA",
      "delai_lancement": "Délai de lancement estimé",
      "avantages": ["avantage1", "avantage2", "avantage3"],
      "defis": ["défi1", "défi2"],
      "score_faisabilite": 85
    },
    {
      "titre": "Nom de l'idée business 2",
      "description": "Description détaillée",
      "investissement": "Investissement",
      "revenus_potentiels": "Revenus",
      "delai_lancement": "Délai",
      "avantages": ["avantage1", "avantage2", "avantage3"],
      "defis": ["défi1", "défi2"],
      "score_faisabilite": 78
    },
    {
      "titre": "Nom de l'idée business 3",
      "description": "Description détaillée",
      "investissement": "Investissement",
      "revenus_potentiels": "Revenus",
      "delai_lancement": "Délai",
      "avantages": ["avantage1", "avantage2", "avantage3"],
      "defis": ["défi1", "défi2"],
      "score_faisabilite": 72
    }
  ]
}

Concentrez-vous sur des idées réalisables et adaptées au marché gabonais.`

  try {
    console.log('📡 Making request to OpenAI API...')
    const response = await fetch('https://api.openai.com/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${openaiApiKey}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        model: 'gpt-3.5-turbo',
        messages: [
          {
            role: 'system',
            content: 'Vous êtes un expert en entrepreneuriat et développement économique au Gabon. Vous générez des idées de business concrètes et réalisables.'
          },
          {
            role: 'user',
            content: prompt
          }
        ],
        max_tokens: 1000,
        temperature: 0.8
      })
    })

    console.log('📊 OpenAI API response status:', response.status)
    if (!response.ok) {
      if (response.status === 429) {
        console.log('⏰ Rate limit hit - will retry with exponential backoff')
        await new Promise(resolve => setTimeout(resolve, 2000))
        
        console.log('🔄 Retrying OpenAI request...')
        const retryResponse = await fetch('https://api.openai.com/v1/chat/completions', {
          method: 'POST',
          headers: {
            'Authorization': `Bearer ${openaiApiKey}`,
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            model: 'gpt-3.5-turbo',
            messages: [
              {
                role: 'system',
                content: 'Vous êtes un expert en entrepreneuriat et développement économique au Gabon. Vous générez des idées de business concrètes et réalisables.'
              },
              {
                role: 'user',
                content: prompt
              }
            ],
            max_tokens: 1000,
            temperature: 0.8
          })
        })
        
        console.log('📊 Retry response status:', retryResponse.status)
        if (!retryResponse.ok) {
          throw new Error(`OpenAI API error after retry: ${retryResponse.status}`)
        }
        
        const retryData = await retryResponse.json()
        console.log('✅ Retry successful, parsing content...')
        const retryContent = retryData.choices[0].message.content
        
        const retryJsonMatch = retryContent.match(/\{[\s\S]*\}/)
        if (!retryJsonMatch) {
          throw new Error('Invalid JSON format in OpenAI response after retry')
        }
        
        return JSON.parse(retryJsonMatch[0])
      }
      throw new Error(`OpenAI API error: ${response.status}`)
    }

    const data = await response.json()
    console.log('🎯 OpenAI response received, parsing content...')
    const content = data.choices[0].message.content

    // Parse the JSON response
    const jsonMatch = content.match(/\{[\s\S]*\}/)
    if (jsonMatch) {
      return JSON.parse(jsonMatch[0])
    } else {
      throw new Error('Invalid JSON format in OpenAI response')
    }

  } catch (error) {
    console.error('❌ OpenAI API error:', error)
    throw error
  }
}

function generateDemoBusinessIdeas(secteur, problematique) {
  return {
    secteur: secteur.nom || 'Secteur Général',
    problematique: problematique || 'Problématique générale',
    idees: [
      {
        titre: "Plateforme digitale de services",
        description: "Développement d'une plateforme numérique qui connecte les prestataires de services locaux avec les clients. Cette solution répond aux besoins de modernisation et d'efficacité identifiés dans l'actualité. La plateforme inclurait un système de réservation, de paiement mobile et d'évaluation des services.",
        investissement: "500,000 - 1,500,000 FCFA",
        revenus_potentiels: "200,000 - 800,000 FCFA/mois",
        delai_lancement: "4-6 mois",
        avantages: ["Faibles coûts opérationnels", "Scalabilité élevée", "Réponse aux besoins du marché"],
        defis: ["Adoption technologique", "Concurrence établie"],
        score_faisabilite: 82
      },
      {
        titre: "Centre de formation spécialisée",
        description: "Création d'un centre de formation qui développe les compétences techniques et entrepreneuriales nécessaires pour répondre aux défis identifiés. Le centre proposerait des formations courtes, certifiantes et adaptées aux besoins du marché local gabonais.",
        investissement: "1,000,000 - 3,000,000 FCFA",
        revenus_potentiels: "400,000 - 1,200,000 FCFA/mois",
        delai_lancement: "6-8 mois",
        avantages: ["Demande forte", "Impact social positif", "Revenus récurrents"],
        defis: ["Recrutement formateurs", "Certification officielle"],
        score_faisabilite: 75
      },
      {
        titre: "Service de consulting local",
        description: "Lancement d'un cabinet de conseil spécialisé dans l'accompagnement des entreprises locales pour résoudre les problématiques identifiées. Services incluant l'audit, l'optimisation des processus et la stratégie de développement adaptée au contexte gabonais.",
        investissement: "200,000 - 800,000 FCFA",
        revenus_potentiels: "300,000 - 1,500,000 FCFA/mois",
        delai_lancement: "2-4 mois",
        avantages: ["Investissement minimal", "Expertise valorisée", "Réseau professionnel"],
        defis: ["Crédibilité à établir", "Concurrence consultants établis"],
        score_faisabilite: 78
      }
    ]
  }
}
