const { createClient } = require('@supabase/supabase-js')

const supabase = createClient(
  process.env.SUPABASE_URL,
  process.env.SUPABASE_SERVICE_ROLE_KEY
)

exports.handler = async (event, context) => {
  console.log('🗄️ Début de l\'archivage des anciens sondages...')
  
  try {
    // 1. Archiver tous les sondages actuellement publiés
    const { data: archivedPolls, error: archiveError } = await supabase
      .from('polls')
      .update({ 
        status: 'archived', 
        is_active: false 
      })
      .eq('status', 'published')
      .select()

    if (archiveError) {
      console.error('❌ Erreur lors de l\'archivage:', archiveError)
      throw archiveError
    }

    console.log(`📦 ${archivedPolls?.length || 0} sondages archivés`)

    // 2. Supprimer toutes les réponses des sondages archivés
    if (archivedPolls && archivedPolls.length > 0) {
      const pollIds = archivedPolls.map(poll => poll.id)
      
      const { error: deleteResponsesError } = await supabase
        .from('poll_responses')
        .delete()
        .in('poll_id', pollIds)

      if (deleteResponsesError) {
        console.error('❌ Erreur lors de la suppression des réponses:', deleteResponsesError)
      } else {
        console.log('🗑️ Réponses des anciens sondages supprimées')
      }

      // 3. Supprimer les statistiques des sondages archivés
      const { error: deleteStatsError } = await supabase
        .from('poll_stats')
        .delete()
        .in('poll_id', pollIds)

      if (deleteStatsError) {
        console.error('❌ Erreur lors de la suppression des stats:', deleteStatsError)
      } else {
        console.log('📊 Statistiques des anciens sondages supprimées')
      }

      // 4. Réinitialiser le compteur de votes dans les sondages archivés
      const { error: resetVotesError } = await supabase
        .from('polls')
        .update({ total_votes: 0 })
        .in('id', pollIds)

      if (resetVotesError) {
        console.error('❌ Erreur lors de la réinitialisation des votes:', resetVotesError)
      } else {
        console.log('🔄 Compteurs de votes réinitialisés')
      }
    }

    return {
      statusCode: 200,
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        success: true,
        message: 'Anciens sondages archivés et votes réinitialisés',
        archivedCount: archivedPolls?.length || 0
      })
    }

  } catch (error) {
    console.error('❌ Erreur dans archive-old-polls:', error)
    return {
      statusCode: 500,
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        success: false,
        error: 'Erreur serveur',
        message: error.message
      })
    }
  }
}
