const { createClient } = require('@supabase/supabase-js')

const supabase = createClient(
  process.env.SUPABASE_URL,
  process.env.SUPABASE_SERVICE_ROLE_KEY
)

exports.handler = async (event, context) => {
  console.log('📊 Début de la création du sondage quotidien...')
  
  try {
    // 1. D'abord archiver les anciens sondages
    const archiveResponse = await fetch(`${process.env.URL}/.netlify/functions/archive-old-polls`, {
      method: 'POST'
    })
    
    if (!archiveResponse.ok) {
      console.error('❌ Erreur lors de l\'archivage des anciens sondages')
    } else {
      console.log('✅ Anciens sondages archivés avec succès')
    }

    // 2. Créer un nouveau sondage avec série de questions pour aujourd'hui
    const pollSeries = [
      {
        title: "Développement économique du Gabon",
        questions: [
          {
            question: "Quelle devrait être la priorité du gouvernement gabonais pour 2025 ?",
            type: "mcq",
            options: ["Diversification économique", "Amélioration des infrastructures", "Réforme de l'éducation"]
          },
          {
            question: "Le Gabon devrait-il investir davantage dans les énergies renouvelables ?",
            type: "yes_no",
            options: []
          },
          {
            question: "Quel secteur nécessite le plus d'investissements au Gabon ?",
            type: "mcq",
            options: ["Santé publique", "Transport et logistique", "Agriculture et sécurité alimentaire"]
          },
          {
            question: "Êtes-vous optimiste concernant l'avenir économique du Gabon ?",
            type: "yes_no",
            options: []
          }
        ]
      },
      {
        title: "Éducation et jeunesse au Gabon",
        questions: [
          {
            question: "Quelle réforme éducative devrait être prioritaire au Gabon ?",
            type: "mcq",
            options: ["Formation des enseignants", "Infrastructures scolaires", "Programmes pédagogiques"]
          },
          {
            question: "Le système éducatif gabonais prépare-t-il bien les jeunes au marché du travail ?",
            type: "yes_no",
            options: []
          },
          {
            question: "Quelle mesure pourrait le mieux lutter contre le chômage des jeunes ?",
            type: "mcq",
            options: ["Formation professionnelle", "Création d'entreprises", "Secteur numérique"]
          }
        ]
      },
      {
        title: "Santé et société gabonaise",
        questions: [
          {
            question: "Quelle amélioration du système de santé est la plus urgente ?",
            type: "mcq",
            options: ["Accès aux soins", "Formation du personnel", "Équipements médicaux"]
          },
          {
            question: "Le Gabon gère-t-il bien les enjeux de santé publique ?",
            type: "yes_no",
            options: []
          },
          {
            question: "Quelle politique sociale devrait être renforcée ?",
            type: "mcq",
            options: ["Protection sociale", "Aide aux familles", "Insertion professionnelle"]
          },
          {
            question: "La couverture santé universelle devrait-elle être une priorité ?",
            type: "yes_no",
            options: []
          }
        ]
      }
    ]

    // Sélectionner une série de questions aléatoire
    const randomSeries = pollSeries[Math.floor(Math.random() * pollSeries.length)]

    // Calculer l'heure d'expiration (19h UTC le jour suivant)
    const now = new Date()
    const expiresAt = new Date()
    
    if (now.getUTCHours() >= 19) {
      // Si on est après 19h UTC, expirer demain à 19h UTC
      expiresAt.setUTCDate(expiresAt.getUTCDate() + 1)
    }
    expiresAt.setUTCHours(19, 0, 0, 0)

    // 3. Insérer le nouveau sondage principal dans la base de données
    const { data: pollData, error: pollError } = await supabase
      .from('polls')
      .insert({
        question: randomSeries.title,
        poll_type: 'series',
        options: [],
        expires_at: expiresAt.toISOString(),
        status: 'published'
      })
      .select()
      .single()

    if (pollError) {
      console.error('❌ Erreur lors de la création du sondage:', pollError)
      return {
        statusCode: 500,
        body: JSON.stringify({ 
          success: false, 
          error: 'Erreur lors de la création du sondage',
          details: pollError.message 
        })
      }
    }

    console.log('✅ Nouveau sondage créé:', pollData)

    // 4. Insérer les questions individuelles dans poll_questions
    const questionsToInsert = randomSeries.questions.map((q, index) => ({
      poll_id: pollData.id,
      question_text: q.question,
      question_type: q.type,
      options: q.options,
      question_order: index + 1
    }))

    const { data: questionsData, error: questionsError } = await supabase
      .from('poll_questions')
      .insert(questionsToInsert)
      .select()

    if (questionsError) {
      console.error('❌ Erreur lors de la création des questions:', questionsError)
      return {
        statusCode: 500,
        body: JSON.stringify({ 
          success: false, 
          error: 'Erreur lors de la création des questions',
          details: questionsError.message 
        })
      }
    }

    console.log('✅ Questions créées:', questionsData)

    return {
      statusCode: 200,
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        success: true,
        message: 'Nouveau sondage quotidien créé avec succès',
        poll: {
          id: newPoll.id,
          question: newPoll.question,
          type: newPoll.poll_type,
          expires_at: newPoll.expires_at
        }
      })
    }

  } catch (error) {
    console.error('❌ Erreur dans create-daily-poll:', error)
    return {
      statusCode: 500,
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        success: false,
        error: 'Erreur serveur',
        message: error.message
      })
    }
  }
}
