const { createClient } = require('@supabase/supabase-js');

// Configuration Supabase
const supabaseUrl = process.env.SUPABASE_URL;
const supabaseServiceKey = process.env.SUPABASE_SERVICE_ROLE_KEY;
const openaiApiKey = process.env.OPENAI_API_KEY;

if (!supabaseUrl || !supabaseServiceKey || !openaiApiKey) {
  console.error('❌ Variables d\'environnement manquantes');
}

const supabase = createClient(supabaseUrl, supabaseServiceKey);

/**
 * Analyser les actualités du jour pour extraire les thèmes principaux
 */
async function analyzeNewsTopics() {
  try {
    console.log('📰 Récupération des articles du jour...');
    
    // Récupérer les articles des dernières 24h
    const twentyFourHoursAgo = new Date();
    twentyFourHoursAgo.setHours(twentyFourHoursAgo.getHours() - 24);
    
    const { data: articles, error } = await supabase
      .from('articles')
      .select('title, summary, category, source, published_at')
      .gte('published_at', twentyFourHoursAgo.toISOString())
      .eq('is_published', true)
      .order('published_at', { ascending: false })
      .limit(20);

    if (error) {
      console.error('❌ Erreur récupération articles:', error);
      return null;
    }

    if (!articles || articles.length === 0) {
      console.log('⚠️ Aucun article trouvé pour les dernières 24h');
      return null;
    }

    console.log(`📊 ${articles.length} articles analysés`);

    // Créer un résumé des actualités
    const newsContext = {
      total_articles: articles.length,
      categories: [...new Set(articles.map(a => a.category))],
      sources: [...new Set(articles.map(a => a.source))],
      headlines: articles.slice(0, 10).map(a => ({
        title: a.title,
        summary: a.summary?.substring(0, 200) + '...',
        category: a.category
      }))
    };

    return newsContext;
  } catch (error) {
    console.error('❌ Erreur analyse actualités:', error);
    return null;
  }
}

/**
 * Générer des questions de sondage avec OpenAI
 */
async function generatePollQuestions(newsContext) {
  try {
    console.log('🤖 Génération des questions avec OpenAI...');
    
    const prompt = `Tu es un expert en sondages d'opinion sur les actualités gabonaises. 

Contexte des actualités du jour au Gabon :
- ${newsContext.total_articles} articles publiés
- Catégories : ${newsContext.categories.join(', ')}
- Titres principaux :
${newsContext.headlines.map(h => `  • ${h.title} (${h.category})`).join('\n')}

Génère UN sondage objectif et engageant pour les citoyens gabonais basé sur ces actualités. Le sondage doit :
- Être pertinent aux actualités du jour
- Avoir entre 3 et 5 questions maximum
- Mélanger les types : QCM (3-4 options), Oui/Non, ou questions d'opinion
- Être neutre politiquement
- Encourager le débat constructif
- Utiliser un langage accessible

Format de réponse JSON strict :
{
  "title": "Titre du sondage (court)",
  "description": "Description courte du contexte",
  "questions": [
    {
      "question": "Question principale ?",
      "type": "mcq", // ou "yes_no" 
      "options": ["Option 1", "Option 2", "Option 3"] // seulement pour MCQ
    }
  ],
  "duration_hours": 24
}

Exemple de types de questions appropriées :
- Opinion sur les mesures gouvernementales
- Priorités de développement économique
- Enjeux sociétaux (éducation, santé, emploi)
- Infrastructure et transport
- Environnement et développement durable`;

    const response = await fetch('https://api.openai.com/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${openaiApiKey}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        model: 'gpt-4o-mini',
        messages: [
          {
            role: 'system',
            content: 'Tu es un expert en sondages politiques et sociaux au Gabon. Réponds uniquement en JSON valide.'
          },
          {
            role: 'user',
            content: prompt
          }
        ],
        temperature: 0.7,
        max_tokens: 1500
      })
    });

    if (!response.ok) {
      throw new Error(`OpenAI API error: ${response.status}`);
    }

    const data = await response.json();
    const content = data.choices[0].message.content;
    
    // Parse le JSON de réponse
    const pollData = JSON.parse(content);
    
    console.log('✅ Questions générées:', pollData.title);
    return pollData;
    
  } catch (error) {
    console.error('❌ Erreur génération OpenAI:', error);
    
    // Fallback avec des questions par défaut
    return {
      title: "Sondage du Jour",
      description: "Votre opinion sur les enjeux actuels du Gabon",
      questions: [
        {
          question: "Quelle priorité devrait avoir le gouvernement gabonais actuellement ?",
          type: "mcq",
          options: [
            "Développement économique",
            "Amélioration des services publics", 
            "Infrastructure et transport",
            "Éducation et formation"
          ]
        }
      ],
      duration_hours: 24
    };
  }
}

/**
 * Sauvegarder le sondage dans la base de données
 */
async function savePollToDatabase(pollData) {
  try {
    console.log('💾 Sauvegarde du sondage...');
    
    // Archiver les anciens sondages actifs
    const { error: archiveError } = await supabase
      .from('polls')
      .update({ 
        status: 'archived',
        is_active: false 
      })
      .eq('status', 'published');
    
    if (archiveError) {
      console.error('Erreur archivage anciens sondages:', archiveError);
    } else {
      console.log('✅ Anciens sondages archivés');
    }

    // Créer les nouveaux sondages
    const polls = [];
    
    for (let i = 0; i < pollData.questions.length; i++) {
      const question = pollData.questions[i];
      const expiresAt = new Date();
      expiresAt.setHours(expiresAt.getHours() + pollData.duration_hours);
      
      const { data, error } = await supabase
        .from('polls')
        .insert({
          question: question.question,
          poll_type: question.type,
          options: question.type === 'mcq' ? question.options : [],
          expires_at: expiresAt.toISOString(),
          status: 'draft',
          scheduled_publish_at: new Date(Date.now() + 2 * 60 * 60 * 1000).toISOString(), // 21h GMT (2h après 19h)
          is_active: false,
          is_manual: false,
          total_votes: 0
        })
        .select()
        .single();

      if (error) {
        console.error('❌ Erreur sauvegarde question:', error);
        continue;
      }

      polls.push(data);
      console.log(`✅ Question ${i + 1} sauvegardée: ${question.question.substring(0, 50)}...`);
    }

    return polls;
    
  } catch (error) {
    console.error('❌ Erreur sauvegarde sondage:', error);
    return null;
  }
}

/**
 * Fonction principale
 */
exports.handler = async (event, context) => {
  const headers = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'Content-Type',
    'Access-Control-Allow-Methods': 'POST, OPTIONS',
    'Content-Type': 'application/json'
  };

  if (event.httpMethod === 'OPTIONS') {
    return { statusCode: 200, headers, body: '' };
  }

  try {
    console.log('🗳️ Début génération sondage quotidien...');
    
    // Vérification des variables d'environnement
    if (!supabaseUrl || !supabaseServiceKey || !openaiApiKey) {
      return {
        statusCode: 500,
        headers,
        body: JSON.stringify({
          success: false,
          error: 'Configuration manquante'
        })
      };
    }

    // 1. Analyser les actualités
    const newsContext = await analyzeNewsTopics();
    if (!newsContext) {
      return {
        statusCode: 500,
        headers,
        body: JSON.stringify({
          success: false,
          error: 'Impossible d\'analyser les actualités'
        })
      };
    }

    // 2. Générer les questions
    const pollData = await generatePollQuestions(newsContext);
    if (!pollData || !pollData.questions || pollData.questions.length === 0) {
      return {
        statusCode: 500,
        headers,
        body: JSON.stringify({
          success: false,
          error: 'Impossible de générer les questions'
        })
      };
    }

    // 3. Sauvegarder en base
    const savedPolls = await savePollToDatabase(pollData);
    if (!savedPolls || savedPolls.length === 0) {
      return {
        statusCode: 500,
        headers,
        body: JSON.stringify({
          success: false,
          error: 'Impossible de sauvegarder le sondage'
        })
      };
    }

    console.log(`✅ Sondage quotidien généré avec ${savedPolls.length} questions`);
    
    return {
      statusCode: 200,
      headers,
      body: JSON.stringify({
        success: true,
        message: `Sondage quotidien généré avec succès`,
        data: {
          title: pollData.title,
          questions_count: savedPolls.length,
          polls: savedPolls.map(p => ({
            id: p.id,
            question: p.question,
            type: p.poll_type,
            expires_at: p.expires_at
          }))
        }
      })
    };

  } catch (error) {
    console.error('❌ Erreur génération sondage:', error);
    
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({
        success: false,
        error: 'Erreur lors de la génération du sondage',
        details: error.message
      })
    };
  }
};
