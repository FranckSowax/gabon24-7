const fetch = require('node-fetch');
const cheerio = require('cheerio');

// Fonction pour extraire l'image d'un article Gabon Actu
async function extractGabonActuImage(articleUrl) {
  if (!articleUrl || !articleUrl.includes('gabonactu.com')) {
    return null;
  }

  try {
    console.log(`🔍 [GABON-ACTU] Extraction image depuis: ${articleUrl}`);
    
    // Fetch du contenu de l'article
    const response = await fetch(articleUrl, {
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
        'Accept-Language': 'fr-FR,fr;q=0.9,en;q=0.8',
        'Referer': 'https://gabonactu.com/',
      },
      timeout: 10000
    });

    if (!response.ok) {
      console.warn(`⚠️ [GABON-ACTU] Erreur HTTP ${response.status} pour ${articleUrl}`);
      return null;
    }

    const html = await response.text();
    const $ = cheerio.load(html);

    // Stratégies d'extraction d'images par ordre de priorité
    const imageSelectors = [
      // 1. Image principale de l'article (featured image)
      '.wp-post-image',
      '.post-thumbnail img',
      '.featured-image img',
      '.article-image img',
      
      // 2. Première image dans le contenu de l'article
      '.entry-content img:first',
      '.post-content img:first',
      '.content img:first',
      
      // 3. Meta tags Open Graph
      'meta[property="og:image"]',
      'meta[name="twitter:image"]',
      
      // 4. Images dans le header de l'article
      '.post-header img',
      '.article-header img',
      
      // 5. Toute image dans le contenu principal
      'article img',
      '.post img',
      '.single-post img',
      
      // 6. Images avec des classes spécifiques à Gabon Actu
      '.aligncenter img',
      '.wp-caption img',
      '.size-full'
    ];

    let imageUrl = null;
    let extractionMethod = '';

    // Essayer chaque sélecteur jusqu'à trouver une image valide
    for (const selector of imageSelectors) {
      const element = $(selector).first();
      
      if (element.length > 0) {
        if (selector.includes('meta')) {
          // Pour les meta tags
          imageUrl = element.attr('content');
          extractionMethod = `Meta tag: ${selector}`;
        } else {
          // Pour les balises img
          imageUrl = element.attr('src') || element.attr('data-src') || element.attr('data-lazy-src');
          extractionMethod = `Image selector: ${selector}`;
        }
        
        if (imageUrl) {
          // Nettoyer et valider l'URL
          imageUrl = imageUrl.trim();
          
          // Convertir en URL absolue si nécessaire
          if (imageUrl.startsWith('/')) {
            imageUrl = 'https://gabonactu.com' + imageUrl;
          } else if (imageUrl.startsWith('./')) {
            imageUrl = articleUrl.replace(/\/[^\/]*$/, '/') + imageUrl.substring(2);
          }
          
          // Vérifier que c'est une vraie image (pas une icon/logo/placeholder)
          const isValidImage = 
            imageUrl.match(/\.(jpg|jpeg|png|gif|webp)(\?.*)?$/i) &&
            !imageUrl.includes('icon') &&
            !imageUrl.includes('logo') &&
            !imageUrl.includes('avatar') &&
            !imageUrl.includes('placeholder') &&
            !imageUrl.includes('default') &&
            !imageUrl.includes('favicon') &&
            imageUrl.length > 20; // URLs trop courtes probablement pas valides
          
          if (isValidImage) {
            console.log(`✅ [GABON-ACTU] Image trouvée via ${extractionMethod}: ${imageUrl}`);
            return imageUrl;
          }
        }
      }
    }

    // Si aucune image trouvée via les sélecteurs, chercher dans le texte
    const articleText = $('.entry-content, .post-content, .content, article').text();
    console.log(`📝 [GABON-ACTU] Contenu article (${articleText.length} chars): ${articleText.substring(0, 200)}...`);

    console.warn(`⚠️ [GABON-ACTU] Aucune image trouvée pour: ${articleUrl}`);
    return null;

  } catch (error) {
    console.error(`❌ [GABON-ACTU] Erreur extraction image: ${error.message}`);
    return null;
  }
}

// Export pour utilisation dans d'autres fonctions
module.exports = { extractGabonActuImage };

// Handler Netlify pour test direct
exports.handler = async (event, context) => {
  const headers = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'Content-Type',
    'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
  };

  if (event.httpMethod === 'OPTIONS') {
    return { statusCode: 200, headers, body: '' };
  }

  try {
    const { url } = JSON.parse(event.body || '{}') || event.queryStringParameters || {};
    
    if (!url) {
      return {
        statusCode: 400,
        headers,
        body: JSON.stringify({ error: 'URL parameter required' })
      };
    }

    const imageUrl = await extractGabonActuImage(url);
    
    return {
      statusCode: 200,
      headers,
      body: JSON.stringify({
        success: true,
        articleUrl: url,
        imageUrl: imageUrl,
        timestamp: new Date().toISOString()
      })
    };

  } catch (error) {
    console.error('Error in gabonactu-image-extractor:', error);
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({
        success: false,
        error: error.message
      })
    };
  }
};
