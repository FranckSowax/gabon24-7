const { createClient } = require('@supabase/supabase-js');

// Configuration Supabase
const supabaseUrl = process.env.SUPABASE_URL;
const supabaseServiceKey = process.env.SUPABASE_SERVICE_ROLE_KEY;
const supabase = createClient(supabaseUrl, supabaseServiceKey);

exports.handler = async (event, context) => {
  // Headers CORS
  const headers = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'Content-Type',
    'Access-Control-Allow-Methods': 'GET, OPTIONS',
    'Content-Type': 'application/json'
  };

  // Gestion des requêtes OPTIONS (preflight)
  if (event.httpMethod === 'OPTIONS') {
    return {
      statusCode: 200,
      headers,
      body: ''
    };
  }

  if (event.httpMethod !== 'GET') {
    return {
      statusCode: 405,
      headers,
      body: JSON.stringify({ error: 'Method Not Allowed' })
    };
  }

  try {
    console.log('📚 Récupération des articles de cette semaine...');
    
    // Calculer la plage de dates pour "Cette Semaine" (7 derniers jours)
    const now = new Date();
    const oneWeekAgo = new Date(now);
    oneWeekAgo.setDate(oneWeekAgo.getDate() - 7);
    oneWeekAgo.setHours(0, 0, 0, 0); // Début de la journée il y a 7 jours
    
    const weekStart = oneWeekAgo.toISOString();
    const weekEnd = now.toISOString();
    console.log(`📅 Plage "Cette Semaine": ${weekStart} à ${weekEnd}`);

    // Récupérer les articles de cette semaine (7 derniers jours)
    const { data: articles, error } = await supabase
      .from('articles')
      .select(`
        id,
        title,
        summary,
        ai_summary,
        url,
        image_url,
        author,
        published_at,
        created_at,
        category,
        view_count,
        sentiment,
        keywords,
        read_time_minutes,
        is_published,
        feeds!inner(
          name,
          media_name,
          category
        )
      `)
      .eq('is_published', true)
      .gte('published_at', weekStart)
      .lte('published_at', weekEnd)
      .not('published_at', 'is', null)
      .order('published_at', { ascending: false })
      .limit(200); // Limite pour éviter les timeouts

    if (error) {
      console.error('❌ Erreur Supabase:', error);
      throw error;
    }

    console.log(`✅ ${articles?.length || 0} articles archivés récupérés`);

    // Filtrer et trier les articles avec des dates valides de cette semaine
    const validArticles = articles?.filter(article => {
      if (!article.published_at) return false;
      const date = new Date(article.published_at);
      if (isNaN(date.getTime())) return false;
      
      // Vérifier que la date est bien dans la plage de cette semaine
      const articleTime = date.getTime();
      const weekStartTime = oneWeekAgo.getTime();
      const weekEndTime = now.getTime();
      
      return articleTime >= weekStartTime && articleTime <= weekEndTime;
    }) || [];

    // Transformation des articles pour le frontend
    const transformedArticles = validArticles.map(article => ({
      id: article.id,
      title: article.title,
      summary: article.summary || article.ai_summary || 'Résumé non disponible',
      content: article.summary || article.ai_summary || '',
      url: article.url,
      imageUrl: article.image_url || `https://picsum.photos/800/400?random=${article.id}`,
      author: article.author || 'Rédaction',
      publishedAt: article.published_at,
      source: article.feeds?.media_name || article.feeds?.name || 'GabonNews',
      category: article.category || article.feeds?.category || 'actualités',
      viewCount: `${article.view_count || 0} vue${(article.view_count || 0) > 1 ? 's' : ''}`,
      view_count: article.view_count || 0,
      sentiment: article.sentiment || 'neutre',
      keywords: article.keywords || [],
      readTime: `${article.read_time_minutes || 2} min`
    }))
    // Tri chronologique décroissant (plus récent en premier)
    .sort((a, b) => {
      const dateA = new Date(a.publishedAt);
      const dateB = new Date(b.publishedAt);
      return dateB.getTime() - dateA.getTime();
    });

    return {
      statusCode: 200,
      headers,
      body: JSON.stringify({
        success: true,
        articles: transformedArticles,
        total: transformedArticles.length,
        week_start: weekStart,
        week_end: weekEnd,
        timestamp: new Date().toISOString()
      })
    };

  } catch (error) {
    console.error('❌ Erreur dans archived-articles:', error);
    
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({
        success: false,
        error: 'Erreur lors de la récupération des articles archivés',
        articles: [],
        total: 0
      })
    };
  }
};
