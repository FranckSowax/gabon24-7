const { createClient } = require('@supabase/supabase-js');

// Environment variables
const supabaseUrl = process.env.SUPABASE_URL;
const supabaseServiceKey = process.env.SUPABASE_SERVICE_ROLE_KEY;

exports.handler = async (event, context) => {
  const headers = {
    'Content-Type': 'application/json'
  };

  try {
    console.log('Starting scheduled digest notifications...');
    
    // Initialize Supabase
    const supabase = createClient(supabaseUrl, supabaseServiceKey);

    // Determine which frequency to process based on current time
    const now = new Date();
    const currentHour = now.getUTCHours();
    const dayOfWeek = now.getUTCDay(); // 0 = Sunday, 1 = Monday, etc.
    
    let frequencyToProcess = null;
    
    // Daily notifications at 8:00 UTC (9:00 GMT+1 Gabon time)
    if (currentHour === 8) {
      frequencyToProcess = 'daily';
    }
    
    // Weekly notifications on Monday at 8:00 UTC
    if (dayOfWeek === 1 && currentHour === 8) {
      frequencyToProcess = 'weekly';
    }

    if (!frequencyToProcess) {
      return {
        statusCode: 200,
        headers,
        body: JSON.stringify({
          success: true,
          message: 'No digest notifications scheduled for this time',
          timestamp: new Date().toISOString()
        })
      };
    }

    console.log(`Processing ${frequencyToProcess} notifications...`);

    // Send notifications for the determined frequency
    const notificationResult = await sendDigestNotifications(frequencyToProcess);
    
    // Log processing statistics
    await logDigestStats(supabase, {
      frequency: frequencyToProcess,
      emailsSent: notificationResult.emailsSent || 0,
      whatsappSent: notificationResult.whatsappSent || 0
    });

    const result = {
      success: true,
      timestamp: new Date().toISOString(),
      frequency: frequencyToProcess,
      notifications: notificationResult,
      message: `${frequencyToProcess} digest notifications completed successfully`
    };

    console.log('Digest notifications completed:', result);

    return {
      statusCode: 200,
      headers,
      body: JSON.stringify(result)
    };

  } catch (error) {
    console.error('Error in scheduled digest notifications:', error);
    
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({
        error: 'Digest notifications failed',
        message: error.message,
        timestamp: new Date().toISOString()
      })
    };
  }
};

async function sendDigestNotifications(frequency) {
  try {
    const response = await fetch(`${process.env.URL}/.netlify/functions/send-alert-notifications`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({ frequency })
    });

    if (!response.ok) {
      throw new Error(`Digest notification sending failed: ${response.status}`);
    }

    return await response.json();
  } catch (error) {
    console.error('Error sending digest notifications:', error);
    return { success: false, error: error.message, emailsSent: 0, whatsappSent: 0 };
  }
}

async function logDigestStats(supabase, stats) {
  try {
    const { error } = await supabase
      .from('alert_processing_logs')
      .insert({
        processed_at: new Date().toISOString(),
        articles_processed: 0,
        matches_found: 0,
        notifications_sent: stats.emailsSent + stats.whatsappSent,
        processing_type: `scheduled_${stats.frequency}`
      });

    if (error) {
      console.error('Error logging digest stats:', error);
    }
  } catch (error) {
    console.error('Error in logDigestStats:', error);
  }
}
