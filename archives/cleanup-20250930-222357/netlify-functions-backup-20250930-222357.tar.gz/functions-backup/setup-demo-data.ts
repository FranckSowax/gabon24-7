import { createClient } from '@supabase/supabase-js'

const supabaseUrl = process.env.SUPABASE_URL!
const supabaseKey = process.env.SUPABASE_SERVICE_ROLE_KEY!
const supabase = createClient(supabaseUrl, supabaseKey)

export const handler = async (event: any, context: any) => {
  // Enable CORS
  const headers = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'Content-Type',
    'Access-Control-Allow-Methods': 'POST, OPTIONS',
    'Content-Type': 'application/json',
  }

  if (event.httpMethod === 'OPTIONS') {
    return { statusCode: 200, headers, body: '' }
  }

  if (event.httpMethod === 'POST') {
    try {
      console.log('🔄 Setting up demo data with real uploaded images...')

      // First, delete old Unsplash demo slides
      const { error: deleteError } = await supabase
        .from('promotional_slides')
        .delete()
        .like('image_url', '%unsplash.com%')

      if (deleteError) {
        console.error('Error deleting old slides:', deleteError)
      }

      // Get or create a Business package
      let { data: businessPackage } = await supabase
        .from('ad_packages')
        .select('id')
        .eq('name', 'Business')
        .single()

      if (!businessPackage) {
        const { data: newPackage, error: packageError } = await supabase
          .from('ad_packages')
          .insert({
            name: 'Business',
            description: 'Forfait standard pour entreprises moyennes',
            duration_days: 15,
            max_slides: 5,
            price_fcfa: 50000,
            is_active: true
          })
          .select('id')
          .single()

        if (packageError) {
          throw packageError
        }
        businessPackage = newPackage
      }

      // Create a new approved campaign
      const { data: campaign, error: campaignError } = await supabase
        .from('ad_campaigns')
        .insert({
          company_name: 'TechSolutions Gabon',
          contact_email: 'contact@techsolutions.ga',
          contact_phone: '+241 01 23 45 67',
          package_id: businessPackage.id,
          start_date: new Date().toISOString(),
          end_date: new Date(Date.now() + 15 * 24 * 60 * 60 * 1000).toISOString(),
          total_amount: 50000,
          payment_status: 'paid',
          is_active: true,
          admin_approved: true
        })
        .select('id')
        .single()

      if (campaignError) {
        throw campaignError
      }

      // Insert slides with real uploaded images
      const { error: slidesError } = await supabase
        .from('promotional_slides')
        .insert([
          {
            campaign_id: campaign.id,
            title: 'Solutions Digitales Innovantes',
            description: 'Transformez votre entreprise avec nos solutions technologiques sur mesure',
            image_url: '/campaign-1756915033515-f12a7a26-3f8a-48b7-b6f6-b24679d45d71.jpg',
            link_url: 'https://techsolutions.ga',
            cta_text: 'Découvrir nos services',
            display_order: 1,
            is_active: true,
            admin_approved: true
          },
          {
            campaign_id: campaign.id,
            title: 'Formation & Consulting IT',
            description: 'Accompagnement personnalisé pour vos projets de transformation digitale',
            image_url: '/campaign-1756914954249-9c338a73-a4d8-4427-81d2-dcf5a60bd536.jpg',
            link_url: 'https://techsolutions.ga/formation',
            cta_text: 'Nous contacter',
            display_order: 2,
            is_active: true,
            admin_approved: true
          },
          {
            campaign_id: campaign.id,
            title: 'Support Technique 24/7',
            description: 'Une équipe d\'experts à votre service pour tous vos besoins techniques',
            image_url: '/campaign-1756914717568-d8b4e252-3891-49bb-8589-08e08efc596d.jpg',
            link_url: 'https://techsolutions.ga/support',
            cta_text: 'Support immédiat',
            display_order: 3,
            is_active: true,
            admin_approved: true
          }
        ])

      if (slidesError) {
        throw slidesError
      }

      console.log('✅ Demo data setup completed successfully')

      return {
        statusCode: 200,
        headers,
        body: JSON.stringify({
          success: true,
          message: 'Demo data setup completed',
          campaign_id: campaign.id
        })
      }
    } catch (error) {
      console.error('❌ Error setting up demo data:', error)
      return {
        statusCode: 500,
        headers,
        body: JSON.stringify({
          success: false,
          error: error instanceof Error ? error.message : 'Unknown error occurred'
        })
      }
    }
  }

  return {
    statusCode: 405,
    headers,
    body: JSON.stringify({ success: false, error: 'Method not allowed' })
  }
}
