exports.handler = async (event, context) => {
  // Headers CORS
  const headers = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'Content-Type',
    'Access-Control-Allow-Methods': 'GET, OPTIONS',
    'Content-Type': 'application/json'
  };

  // Gestion des requêtes OPTIONS (preflight)
  if (event.httpMethod === 'OPTIONS') {
    return {
      statusCode: 200,
      headers,
      body: ''
    };
  }

  if (event.httpMethod !== 'GET') {
    return {
      statusCode: 405,
      headers,
      body: JSON.stringify({ error: 'Method Not Allowed' })
    };
  }

  try {
    // Extraire la ville depuis l'URL
    const pathSegments = event.path.split('/');
    const city = pathSegments[pathSegments.length - 1] || 'libreville';
    
    console.log(`🌤️ Récupération météo pour: ${city}`);

    // Données météo simulées pour le Gabon
    const weatherData = {
      libreville: {
        temperature: 28,
        weather_description: "Partiellement nuageux",
        humidity: 75,
        wind_speed: 12,
        icon: "partly-cloudy"
      },
      "port-gentil": {
        temperature: 26,
        weather_description: "Ensoleillé",
        humidity: 80,
        wind_speed: 8,
        icon: "sunny"
      },
      franceville: {
        temperature: 24,
        weather_description: "Nuageux",
        humidity: 70,
        wind_speed: 6,
        icon: "cloudy"
      },
      oyem: {
        temperature: 22,
        weather_description: "Pluvieux",
        humidity: 85,
        wind_speed: 10,
        icon: "rainy"
      }
    };

    const cityData = weatherData[city.toLowerCase()] || weatherData.libreville;

    return {
      statusCode: 200,
      headers,
      body: JSON.stringify({
        success: true,
        city: city,
        data: cityData,
        fallback: {
          temperature: 25,
          weather_description: "Données météo non disponibles",
          humidity: 70,
          wind_speed: 8,
          icon: "unknown"
        },
        timestamp: new Date().toISOString()
      })
    };

  } catch (error) {
    console.error('❌ Erreur dans weather function:', error);
    
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({
        success: false,
        error: 'Erreur serveur',
        message: error.message
      })
    };
  }
};
