const fetch = require('node-fetch');
const cheerio = require('cheerio');

// Fonction pour extraire l'image principale d'un article Le Confidentiel
async function extractLeConfidentielImage(articleUrl) {
  try {
    console.log(`🎯 [LE-CONFIDENTIEL] Extraction image depuis: ${articleUrl}`);
    
    // Headers pour contourner les protections
    const headers = {
      'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',
      'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
      'Accept-Language': 'fr-FR,fr;q=0.9,en;q=0.8',
      'Accept-Encoding': 'gzip, deflate',
      'DNT': '1',
      'Connection': 'keep-alive',
      'Upgrade-Insecure-Requests': '1',
      'Referer': 'https://leconfidentiel.ga/'
    };
    
    const response = await fetch(articleUrl, { 
      headers,
      timeout: 10000,
      follow: 10
    });
    
    if (!response.ok) {
      console.error(`❌ [LE-CONFIDENTIEL] Erreur HTTP ${response.status}: ${articleUrl}`);
      return null;
    }
    
    const html = await response.text();
    const $ = cheerio.load(html);
    
    console.log(`📄 [LE-CONFIDENTIEL] Page chargée (${html.length} chars)`);
    
    // Sélecteurs CSS pour trouver l'image principale
    const imageSelectors = [
      // Meta Open Graph (priorité)
      'meta[property="og:image"]',
      'meta[name="twitter:image"]',
      
      // Images WordPress typiques
      '.wp-post-image',
      '.featured-image img',
      '.post-featured img',
      '.entry-image img',
      '.post-image img',
      
      // Images dans le contenu de l'article
      '.entry-content img:first-child',
      '.post-content img:first-child',
      '.article-content img:first-child',
      '.content img:first-child',
      'article img:first-child',
      
      // Images génériques
      '.featured img',
      '.thumbnail img',
      '.post-thumbnail img',
      '.attachment-post-thumbnail',
      '.size-full',
      
      // Sélecteurs spécifiques au layout du site
      '.single-post-image img',
      '.post-header img'
    ];

    let imageUrl = null;
    let extractionMethod = '';

    // Essayer chaque sélecteur jusqu'à trouver une image valide
    for (const selector of imageSelectors) {
      const element = $(selector).first();
      
      if (element.length > 0) {
        if (selector.includes('meta')) {
          // Pour les meta tags
          imageUrl = element.attr('content');
          extractionMethod = `Meta tag: ${selector}`;
        } else {
          // Pour les balises img
          imageUrl = element.attr('src') || element.attr('data-src') || element.attr('data-lazy-src');
          extractionMethod = `Image selector: ${selector}`;
        }
        
        if (imageUrl) {
          // Nettoyer et valider l'URL
          imageUrl = imageUrl.trim();
          
          // Convertir en URL absolue si nécessaire
          if (imageUrl.startsWith('/')) {
            imageUrl = 'https://leconfidentiel.ga' + imageUrl;
          } else if (imageUrl.startsWith('./')) {
            imageUrl = articleUrl.replace(/\/[^\/]*$/, '/') + imageUrl.substring(2);
          } else if (imageUrl.startsWith('www.')) {
            imageUrl = 'https://' + imageUrl;
          }
          
          // Vérifier que c'est une vraie image (pas une icon/logo/placeholder)
          const isValidImage = 
            imageUrl.match(/\.(jpg|jpeg|png|gif|webp)(\?.*)?$/i) &&
            !imageUrl.includes('icon') &&
            !imageUrl.includes('logo') &&
            !imageUrl.includes('avatar') &&
            !imageUrl.includes('placeholder') &&
            !imageUrl.includes('default') &&
            !imageUrl.includes('favicon') &&
            imageUrl.length > 20; // URLs trop courtes probablement pas valides
          
          if (isValidImage) {
            console.log(`✅ [LE-CONFIDENTIEL] Image trouvée via ${extractionMethod}: ${imageUrl}`);
            return imageUrl;
          }
        }
      }
    }

    // Si aucune image trouvée via les sélecteurs, chercher dans le texte
    const articleText = $('.entry-content, .post-content, .content, article').text();
    console.log(`📝 [LE-CONFIDENTIEL] Contenu article (${articleText.length} chars): ${articleText.substring(0, 200)}...`);

    console.warn(`⚠️ [LE-CONFIDENTIEL] Aucune image trouvée pour: ${articleUrl}`);
    return null;

  } catch (error) {
    console.error(`❌ [LE-CONFIDENTIEL] Erreur extraction image: ${error.message}`);
    return null;
  }
}

// Export pour utilisation dans d'autres fonctions
module.exports = { extractLeConfidentielImage };

// Handler Netlify pour test direct
exports.handler = async (event, context) => {
  const headers = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'Content-Type',
    'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
  };

  if (event.httpMethod === 'OPTIONS') {
    return { statusCode: 200, headers, body: '' };
  }

  try {
    const { url } = JSON.parse(event.body || '{}') || event.queryStringParameters || {};
    
    if (!url) {
      return {
        statusCode: 400,
        headers,
        body: JSON.stringify({ error: 'URL parameter required' })
      };
    }
    
    const extractedImage = await extractLeConfidentielImage(url);
    
    return {
      statusCode: 200,
      headers,
      body: JSON.stringify({
        success: !!extractedImage,
        imageUrl: extractedImage,
        originalUrl: url,
        message: extractedImage ? 'Image extraite avec succès' : 'Aucune image trouvée'
      })
    };
    
  } catch (error) {
    console.error('Erreur dans le handler:', error);
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({ 
        error: 'Erreur serveur', 
        message: error.message 
      })
    };
  }
};
