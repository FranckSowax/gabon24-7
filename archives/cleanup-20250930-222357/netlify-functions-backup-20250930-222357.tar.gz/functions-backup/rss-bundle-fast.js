const Parser = require('rss-parser');
const parser = new Parser();
const { createClient } = require('@supabase/supabase-js');
const fetch = require('node-fetch');
const cheerio = require('cheerio');

// Import des extracteurs d'images spécialisés
const { extractGabonActuImage } = require('./gabonactu-image-extractor');
const { extractLeConfidentielImage } = require('./leconfidentiel-image-extractor');

// Configuration
const supabaseUrl = process.env.SUPABASE_URL;
const supabaseKey = process.env.SUPABASE_SERVICE_ROLE_KEY;

const supabase = createClient(supabaseUrl, supabaseKey);

// Bundle RSS.app URL unique
const BUNDLE_URL = 'https://rss.app/feeds/_SntJgjZXkqIWrDHq.xml';

// Fonction pour extraire le domaine et déterminer la source
function extractSourceFromLink(link) {
  try {
    const url = new URL(link);
    const domain = url.hostname.replace('www.', '');
    
    // Map des domaines vers noms de sources
    const sourceMap = {
      'gabonreview.com': 'Gabon Review',
      'infogabon.ga': 'Info Gabon',
      'lalibreville.com': 'La Libreville',
      'gabon24.com': 'Gabon 24',
      'union.sonapresse.com': 'L\'Union',
      'gabon-eco.com': 'Gabon Eco',
      'actualite-gabon.com': 'Actualité Gabon',
      'sciencesetavenir.fr': 'Sciences et Avenir',
      'directinfosgabon.com': 'Direct Infos Gabon',
      'gabonactu.com': 'Gabon Actu',
      'africaintelligence.fr': 'Africa Intelligence',
      'gabon24.tv': 'Gabon 24 TV',
      'focusgroupemedia.com': 'Focus Groupe Media',
      'gabonmediatime.com': 'Gabon Media Time',
      'facebook.com': 'Facebook',
      'echosdeleco.com': 'Echos de l\'Eco',
      'agpgabon.ga': 'AGP Gabon',
      'leconfidentiel.ga': 'Le Confidentiel'
    };
    
    return sourceMap[domain] || domain;
  } catch (error) {
    return 'Source inconnue';
  }
}

// Fonction pour extraire image spécifique pour Gabon Actu
async function extractGabonActuImageFromArticle(articleUrl) {
  try {
    const fetch = require('node-fetch');
    const cheerio = require('cheerio');
    
    console.log(`🔍 [GABON-ACTU] Extraction image depuis: ${articleUrl}`);
    
    const response = await fetch(articleUrl, {
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
        'Referer': 'https://gabonactu.com/',
      },
      timeout: 8000
    });

    if (!response.ok) return null;

    const html = await response.text();
    const $ = cheerio.load(html);

    // Sélecteurs pour images d'articles Gabon Actu
    const selectors = [
      '.wp-post-image',
      '.post-thumbnail img',
      '.featured-image img',
      '.entry-content img:first',
      'meta[property="og:image"]',
      '.post-header img',
      'article img:first'
    ];

    for (const selector of selectors) {
      const element = $(selector).first();
      if (element.length > 0) {
        let imageUrl = selector.includes('meta') 
          ? element.attr('content')
          : element.attr('src') || element.attr('data-src');
        
        if (imageUrl) {
          if (imageUrl.startsWith('/')) {
            imageUrl = 'https://gabonactu.com' + imageUrl;
          }
          
          if (imageUrl.match(/\.(jpg|jpeg|png|gif|webp)(\?.*)?$/i) &&
              !imageUrl.includes('icon') && !imageUrl.includes('logo')) {
            console.log(`✅ [GABON-ACTU] Image extraite: ${imageUrl}`);
            return `/.netlify/functions/image-proxy?url=${encodeURIComponent(imageUrl)}`;
          }
        }
      }
    }
    return null;
  } catch (error) {
    console.error(`❌ [GABON-ACTU] Erreur extraction: ${error.message}`);
    return null;
  }
}

// Fonction pour extraire image spécifique pour Facebook Gabon 24
async function extractFacebookGabon24ImageFromPost(facebookUrl) {
  try {
    const fetch = require('node-fetch');
    const cheerio = require('cheerio');
    
    console.log(`🔍 [GABON24-FB] Extraction image depuis: ${facebookUrl}`);
    
    // Headers pour contourner les restrictions Facebook
    const headers = {
      'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
      'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
      'Referer': 'https://www.facebook.com/',
      'Accept-Language': 'fr-FR,fr;q=0.9,en;q=0.8',
    };

    // Essayer d'abord l'URL mobile pour contourner les restrictions
    const mobileUrl = facebookUrl.replace('www.facebook.com', 'm.facebook.com');
    
    const response = await fetch(mobileUrl, {
      headers: {
        ...headers,
        'User-Agent': 'Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac OS X) AppleWebKit/605.1.15'
      },
      timeout: 10000
    });

    if (!response.ok) {
      // Fallback avec user-agent bot Facebook
      const botResponse = await fetch(facebookUrl, {
        headers: {
          'User-Agent': 'facebookexternalhit/1.1',
          'Accept': 'text/html'
        },
        timeout: 8000
      });
      
      if (botResponse.ok) {
        const html = await botResponse.text();
        const $ = cheerio.load(html);
        const ogImage = $('meta[property="og:image"]').attr('content');
        
        if (ogImage && ogImage.includes('fbcdn.net')) {
          console.log(`✅ [GABON24-FB] Image Open Graph: ${ogImage}`);
          return `/.netlify/functions/image-proxy?url=${encodeURIComponent(ogImage)}`;
        }
      }
      return null;
    }

    const html = await response.text();
    const $ = cheerio.load(html);

    // Stratégies d'extraction pour Facebook mobile
    const strategies = [
      () => $('meta[property="og:image"]').attr('content'),
      () => $('meta[name="twitter:image"]').attr('content'),
      () => $('div[data-ft] img').first().attr('src'),
      () => $('.story_body_container img').first().attr('src'),
      () => $('.userContentWrapper img').first().attr('src')
    ];

    for (const strategy of strategies) {
      try {
        const imageUrl = strategy();
        if (imageUrl && 
            (imageUrl.includes('fbcdn.net') || imageUrl.includes('scontent')) &&
            imageUrl.match(/\.(jpg|jpeg|png|gif|webp)(\?.*)?$/i) &&
            !imageUrl.includes('profile') && 
            !imageUrl.includes('safe_image')) {
          
          console.log(`✅ [GABON24-FB] Image extraite: ${imageUrl}`);
          return `/.netlify/functions/image-proxy?url=${encodeURIComponent(imageUrl)}`;
        }
      } catch (e) {
        continue;
      }
    }

    return null;
  } catch (error) {
    console.error(`❌ [GABON24-FB] Erreur extraction: ${error.message}`);
    return null;
  }
}

// Fonction pour traiter l'image avec proxy si nécessaire
async function processImageUrl(imageUrl, link, source) {
  // Extraction spéciale pour Gabon Actu - toujours extraire depuis l'article
  if (source === 'Gabon Actu' && link.includes('gabonactu.com')) {
    console.log(`🎯 [GABON-ACTU] Extraction spécialisée pour: ${link}`);
    const extractedImage = await extractGabonActuImageFromArticle(link);
    if (extractedImage) {
      // L'image extraite doit être proxifiée pour éviter les restrictions CORS
      return `/.netlify/functions/image-proxy?url=${encodeURIComponent(extractedImage)}`;
    }
  }
  
  // Extraction spéciale pour Facebook Gabon 24 - toujours extraire depuis le post
  if (source === 'Gabon 24' && link.includes('facebook.com')) {
    console.log(`🎯 [GABON24-FB] Extraction spécialisée pour: ${link}`);
    const extractedImage = await extractFacebookGabon24ImageFromPost(link);
    if (extractedImage) {
      // L'image extraite de Facebook doit être proxifiée
      return `/.netlify/functions/image-proxy?url=${encodeURIComponent(extractedImage)}`;
    }
  }
  
  // Extraction spéciale pour Le Confidentiel - toujours extraire depuis l'article
  if (source === 'Le Confidentiel' && link.includes('leconfidentiel.ga')) {
    console.log(`🎯 [LE-CONFIDENTIEL] Extraction spécialisée pour: ${link}`);
    const extractedImage = await extractLeConfidentielImage(link);
    if (extractedImage) {
      // L'image extraite doit être proxifiée pour éviter les restrictions CORS
      return `/.netlify/functions/image-proxy?url=${encodeURIComponent(extractedImage)}`;
    }
  }
  
  if (!imageUrl) return null;
  
  try {
    const articleUrl = new URL(link);
    const imageUrlObj = new URL(imageUrl);
    
    // Détecter les images Unsplash problématiques pour InfosGabon, Gabon Actu et Le Confidentiel
    if (imageUrlObj.hostname.includes('unsplash.com')) {
      if (source === 'Info Gabon' || source === 'Gabon Actu' || source === 'Direct Infos Gabon' || source === 'Le Confidentiel') {
        console.warn(`🚨 Image Unsplash détectée pour ${source}: ${imageUrl} - article: ${link}`);
        // Pour Gabon Actu, essayer l'extraction spécialisée
        if (source === 'Gabon Actu') {
          const extractedImage = await extractGabonActuImageFromArticle(link);
          if (extractedImage) {
            return `/.netlify/functions/image-proxy?url=${encodeURIComponent(extractedImage)}`;
          }
        }
        // Pour Facebook Gabon 24, essayer l'extraction spécialisée
        if (source === 'Gabon 24' && link.includes('facebook.com')) {
          const extractedImage = await extractFacebookGabon24ImageFromPost(link);
          if (extractedImage) {
            return `/.netlify/functions/image-proxy?url=${encodeURIComponent(extractedImage)}`;
          }
        }
        // Pour Le Confidentiel, essayer l'extraction spécialisée
        if (source === 'Le Confidentiel') {
          const extractedImage = await extractLeConfidentielImage(link);
          if (extractedImage) {
            return `/.netlify/functions/image-proxy?url=${encodeURIComponent(extractedImage)}`;
          }
        }
        return null;
      }
    }
    
    // Si l'image vient d'Info Gabon, utiliser le proxy
    if (articleUrl.hostname.includes('infogabon') && imageUrlObj.hostname.includes('infogabon')) {
      return `/.netlify/functions/image-proxy?url=${encodeURIComponent(imageUrl)}`;
    }
    
    // Si l'image vient de Gabon Actu, utiliser le proxy
    if (articleUrl.hostname.includes('gabonactu') && imageUrlObj.hostname.includes('gabonactu')) {
      return `/.netlify/functions/image-proxy?url=${encodeURIComponent(imageUrl)}`;
    }
    
    // Si l'image vient de Le Confidentiel, utiliser le proxy
    if (articleUrl.hostname.includes('leconfidentiel') && imageUrlObj.hostname.includes('leconfidentiel')) {
      return `/.netlify/functions/image-proxy?url=${encodeURIComponent(imageUrl)}`;
    }
    
    return imageUrl;
  } catch (error) {
    console.log('⚠️ URL image invalide:', imageUrl);
    return null;
  }
}

exports.handler = async (event, context) => {
  const startTime = Date.now();
  
  try {
    console.log('⚡ Synchronisation RSS Bundle RAPIDE démarrée (sans IA)');
    console.log('📡 Bundle URL:', BUNDLE_URL);

    // Étape 1: Parser le bundle RSS.app
    const feed = await parser.parseURL(BUNDLE_URL);
    console.log(`📄 Bundle parsé: ${feed.items.length} articles trouvés`);

    let newArticles = 0;
    let processedArticles = 0;
    const errors = [];
    
    // Traiter tous les articles rapidement (pas de limite car pas d'IA)
    console.log(`⚡ Traitement rapide de ${feed.items.length} articles`);

    // Étape 2: Traiter chaque article du bundle RAPIDEMENT
    for (const item of feed.items) {
      try {
        processedArticles++;
        
        // Vérifier si l'article existe déjà (requête rapide)
        const { data: existingArticle } = await supabase
          .from('articles')
          .select('id')
          .eq('link', item.link)
          .single();

        if (existingArticle) {
          continue; // Article déjà existant
        }

        // Extraire les données de l'article RAPIDEMENT
        const title = item.title || 'Titre non disponible';
        const content = item.contentSnippet || item.content || item.summary || '';
        const pubDate = item.pubDate ? new Date(item.pubDate).toISOString() : new Date().toISOString();
        const source = extractSourceFromLink(item.link);
        const processedImageUrl = await processImageUrl(item.enclosure?.url, item.link, source);
        const imageUrl = processedImageUrl || item.enclosure?.url || null;

        // Insérer l'article dans Supabase
        const { data: insertedArticle, error: insertError } = await supabase
          .from('articles')
          .insert({
            title: title,
            content: content,
            link: item.link,
            published_at: pubDate,
            source: source,
            image_url: imageUrl,
            summary: item.contentSnippet || item.content?.substring(0, 300) || ''
          })
          .select('id')
          .single();

        if (insertError) {
          console.error('❌ Erreur insertion article:', insertError.message);
          errors.push(`Erreur insertion: ${insertError.message}`);
        } else {
          newArticles++;
          console.log(`⚡ Article ajouté: ${title.substring(0, 50)}...`);
          
          // Ajouter à la queue pour résumé IA différé
          if (insertedArticle?.id) {
            try {
              await supabase
                .from('pending_ai_summaries')
                .insert({
                  article_id: insertedArticle.id,
                  priority: 1, // Priorité normale
                  status: 'pending',
                  created_at: new Date().toISOString()
                });
            } catch (queueError) {
              console.warn('⚠️ Erreur ajout queue IA:', queueError.message);
            }
          }
        }

        // Pas de délai - traitement ultra rapide
        
        // Arrêt précoce si on approche du timeout Netlify (après 15 secondes)
        const elapsed = Date.now() - startTime;
        if (elapsed > 15000) { // 15 secondes max pour être sûr
          console.log(`⏰ Arrêt précoce après ${elapsed}ms pour éviter timeout`);
          break;
        }

      } catch (articleError) {
        console.error('❌ Erreur traitement article:', articleError.message);
        errors.push(`Erreur article: ${articleError.message}`);
      }
    }

    // Étape 3: Log de synchronisation
    const duration = Date.now() - startTime;
    const { error: logError } = await supabase
      .from('sync_logs')
      .insert({
        sync_type: 'bundle-fast',
        feeds_processed: 1,
        articles_extracted: newArticles,
        success_count: 1,
        error_count: errors.length,
        errors: errors,
        duration_ms: duration,
        ai_summaries_generated: 0, // Pas d'IA dans la version rapide
        created_at: new Date().toISOString(),
      });

    if (logError) {
      console.error('❌ Erreur log:', logError.message);
    }

    const result = {
      success: true,
      bundle_url: BUNDLE_URL,
      total_items: feed.items.length,
      new_articles: newArticles,
      processed_articles: processedArticles,
      ai_summaries_generated: 0,
      duration_ms: duration,
      errors: errors,
      mode: 'fast',
      timestamp: new Date().toISOString()
    };

    console.log('⚡ Synchronisation RSS Bundle RAPIDE terminée:', result);

    return {
      statusCode: 200,
      headers: {
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
        'Access-Control-Allow-Headers': 'Content-Type',
      },
      body: JSON.stringify(result)
    };

  } catch (error) {
    console.error('❌ Erreur critique RSS Bundle RAPIDE:', error);
    
    const errorResult = {
      success: false,
      error: error.message,
      duration_ms: Date.now() - startTime,
      mode: 'fast',
      timestamp: new Date().toISOString()
    };

    return {
      statusCode: 500,
      headers: {
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*',
      },
      body: JSON.stringify(errorResult)
    };
  }
};
