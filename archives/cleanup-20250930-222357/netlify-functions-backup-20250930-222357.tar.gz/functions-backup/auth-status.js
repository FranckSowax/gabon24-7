exports.handler = async (event, context) => {
  const headers = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'Content-Type',
    'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
    'Access-Control-Allow-Credentials': 'true'
  }

  if (event.httpMethod === 'OPTIONS') {
    return {
      statusCode: 200,
      headers,
      body: ''
    }
  }

  if (event.httpMethod !== 'GET') {
    return {
      statusCode: 405,
      headers,
      body: JSON.stringify({ error: 'Method not allowed' })
    }
  }

  try {
    // Pour cette démo, on simule un statut de connexion
    // Dans une vraie implémentation, on vérifierait les cookies/tokens de session
    
    // Vérifier s'il y a un token d'authentification dans les cookies ou headers
    const cookies = event.headers.cookie || ''
    const authToken = cookies.includes('auth_token') || 
                     event.headers.authorization || 
                     event.headers['x-auth-token']

    // Pour la démo, on considère l'utilisateur comme connecté s'il y a un token
    // ou on peut simuler un état de connexion aléatoire pour les tests
    const isLoggedIn = !!authToken || Math.random() > 0.7 // 30% de chance d'être "connecté" pour les tests

    return {
      statusCode: 200,
      headers,
      body: JSON.stringify({
        success: true,
        isLoggedIn: isLoggedIn,
        message: isLoggedIn ? 'Utilisateur connecté' : 'Utilisateur non connecté'
      })
    }

  } catch (error) {
    console.error('Erreur lors de la vérification du statut de connexion:', error)
    
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({
        success: false,
        error: 'Erreur serveur lors de la vérification de connexion',
        isLoggedIn: false
      })
    }
  }
}
