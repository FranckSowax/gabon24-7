const { createClient } = require('@supabase/supabase-js');

// Configuration Supabase avec validation
const supabaseUrl = process.env.SUPABASE_URL;
const supabaseServiceKey = process.env.SUPABASE_SERVICE_ROLE_KEY;

if (!supabaseUrl || !supabaseServiceKey) {
  console.error('❌ Variables d\'environnement manquantes:', {
    SUPABASE_URL: !!supabaseUrl,
    SUPABASE_SERVICE_ROLE_KEY: !!supabaseServiceKey
  });
}

const supabase = createClient(supabaseUrl, supabaseServiceKey);

exports.handler = async (event, context) => {
  // Headers CORS
  const headers = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'Content-Type',
    'Access-Control-Allow-Methods': 'POST, OPTIONS',
    'Cache-Control': 'no-cache, no-store, must-revalidate',
    'Pragma': 'no-cache',
    'Expires': '0',
    'Content-Type': 'application/json'
  };

  // Gestion des requêtes OPTIONS (preflight)
  if (event.httpMethod === 'OPTIONS') {
    return {
      statusCode: 200,
      headers,
      body: ''
    };
  }

  if (event.httpMethod !== 'POST') {
    return {
      statusCode: 405,
      headers,
      body: JSON.stringify({
        success: false,
        error: 'Méthode non autorisée'
      })
    };
  }

  try {
    const { articleId, title, url, source } = JSON.parse(event.body || '{}');

    if (!articleId) {
      return {
        statusCode: 400,
        headers,
        body: JSON.stringify({
          success: false,
          error: 'ID d\'article requis'
        })
      };
    }

    console.log(`📊 Tracking vue pour article: ${articleId} - ${title}`);

    // Incrémenter le compteur de vues dans la table articles - approche simple
    const { data: article, error: fetchError } = await supabase
      .from('articles')
      .select('view_count')
      .eq('id', articleId)
      .single();

    if (fetchError) {
      console.error('❌ Erreur lors de la récupération de l\'article:', fetchError);
      throw fetchError;
    }

    const newViewCount = (article?.view_count || 0) + 1;

    const { error: updateError } = await supabase
      .from('articles')
      .update({ 
        view_count: newViewCount,
        last_viewed_at: new Date().toISOString()
      })
      .eq('id', articleId);

    if (updateError) {
      console.error('❌ Erreur lors de la mise à jour des vues:', updateError);
      throw updateError;
    }

    // Enregistrer la vue dans la table article_views pour les statistiques détaillées
    const { error: viewError } = await supabase
      .from('article_views')
      .insert({
        article_id: articleId,
        viewed_at: new Date().toISOString(),
        user_agent: event.headers['user-agent'] || 'Unknown',
        ip_address: event.headers['x-forwarded-for'] || event.headers['x-real-ip'] || 'Unknown',
        referrer: event.headers.referer || 'Direct'
      });

    if (viewError) {
      console.warn('⚠️ Erreur lors de l\'enregistrement de la vue détaillée:', viewError);
      // Ne pas faire échouer la requête si l'enregistrement détaillé échoue
    }

    console.log(`✅ Vue trackée avec succès. Nouvelles vues: ${newViewCount}`);

    return {
      statusCode: 200,
      headers,
      body: JSON.stringify({
        success: true,
        articleId,
        viewCount: newViewCount,
        message: 'Vue trackée avec succès'
      })
    };

  } catch (error) {
    console.error('❌ Erreur dans track-view function:', error);
    
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({
        success: false,
        error: 'Erreur serveur',
        message: error.message
      })
    };
  }
};
