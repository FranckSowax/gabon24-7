const fetch = require('node-fetch');

exports.handler = async (event, context) => {
  // Headers CORS
  const headers = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'Content-Type',
    'Access-Control-Allow-Methods': 'GET, OPTIONS',
  };

  // Gestion des requêtes OPTIONS (preflight)
  if (event.httpMethod === 'OPTIONS') {
    return {
      statusCode: 200,
      headers,
      body: ''
    };
  }

  if (event.httpMethod !== 'GET') {
    return {
      statusCode: 405,
      headers,
      body: JSON.stringify({ error: 'Method Not Allowed' })
    };
  }

  try {
    const { url } = event.queryStringParameters || {};
    
    if (!url) {
      return {
        statusCode: 400,
        headers,
        body: JSON.stringify({ error: 'URL parameter is required' })
      };
    }

    // Décoder l'URL
    const imageUrl = decodeURIComponent(url);
    
    console.log(`[IMAGE-PROXY] Processing URL: ${imageUrl}`);
    
    // Vérifier que c'est une URL absolue
    if (!imageUrl.startsWith('http://') && !imageUrl.startsWith('https://')) {
      console.error(`[IMAGE-PROXY] Invalid URL - not absolute: ${imageUrl}`);
      return {
        statusCode: 400,
        headers,
        body: JSON.stringify({ error: 'Only absolute URLs are supported' })
      };
    }
    
    // Détecter et prévenir la récursion infinie
    if (imageUrl.includes('/.netlify/functions/image-proxy')) {
      console.error(`[IMAGE-PROXY] RECURSION DETECTED: ${imageUrl}`);
      return {
        statusCode: 400,
        headers,
        body: JSON.stringify({ error: 'Recursive proxy call detected - URL already contains image-proxy' })
      };
    }
    
    // Vérifier que c'est une URL d'image valide
    if (!imageUrl.match(/\.(jpg|jpeg|png|gif|webp)(\?.*)?$/i) && 
        !imageUrl.includes('gabonmediatime.com') && 
        !imageUrl.includes('fbcdn.net') &&
        !imageUrl.includes('infosgabon.com') &&
        !imageUrl.includes('directinfosgabon.com') &&
        !imageUrl.includes('gabonactu.com') &&
        !imageUrl.includes('unsplash.com')) {
      console.error(`[IMAGE-PROXY] Invalid image URL format: ${imageUrl}`);
      return {
        statusCode: 400,
        headers,
        body: JSON.stringify({ error: 'Invalid image URL format' })
      };
    }

    // Headers pour contourner les protections anti-hotlinking
    const fetchHeaders = {
      'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',
      'Accept': 'image/webp,image/apng,image/*,*/*;q=0.8',
      'Accept-Language': 'fr-FR,fr;q=0.9,en;q=0.8',
      'Cache-Control': 'no-cache',
      'Pragma': 'no-cache',
    };

    // Ajouter le referrer approprié selon le domaine
    if (imageUrl.includes('gabonmediatime.com')) {
      fetchHeaders['Referer'] = 'https://gabonmediatime.com/';
    } else if (imageUrl.includes('fbcdn.net')) {
      fetchHeaders['Referer'] = 'https://www.facebook.com/';
      // Headers spécifiques pour Facebook
      fetchHeaders['Accept'] = 'image/avif,image/webp,image/apng,image/svg+xml,image/*,*/*;q=0.8';
      fetchHeaders['Sec-Fetch-Dest'] = 'image';
      fetchHeaders['Sec-Fetch-Mode'] = 'no-cors';
      fetchHeaders['Sec-Fetch-Site'] = 'cross-site';
    } else if (imageUrl.includes('infosgabon.com')) {
      fetchHeaders['Referer'] = 'https://infosgabon.com/';
    } else if (imageUrl.includes('directinfosgabon.com')) {
      fetchHeaders['Referer'] = 'https://directinfosgabon.com/';
    } else if (imageUrl.includes('gabonactu.com')) {
      fetchHeaders['Referer'] = 'https://gabonactu.com/';
    }
    
    // Détection des images Unsplash problématiques
    if (imageUrl.includes('unsplash.com')) {
      console.warn(`[IMAGE-PROXY] Unsplash image detected - potential fallback issue: ${imageUrl}`);
    }

    console.log(`Fetching image: ${imageUrl}`);
    
    const response = await fetch(imageUrl, {
      headers: fetchHeaders,
      timeout: 10000
    });

    if (!response.ok) {
      console.error(`Failed to fetch image: ${response.status} ${response.statusText}`);
      
      // Pour les erreurs 403 sur Facebook, retourner une image placeholder
      if (response.status === 403 && imageUrl.includes('fbcdn.net')) {
        console.log(`Returning placeholder for blocked Facebook image`);
        return {
          statusCode: 302,
          headers: {
            ...headers,
            'Location': `https://picsum.photos/800/400?random=${Math.random()}`
          }
        };
      }
      
      return {
        statusCode: response.status,
        headers,
        body: JSON.stringify({ 
          error: 'Failed to fetch image',
          status: response.status,
          statusText: response.statusText
        })
      };
    }

    const contentType = response.headers.get('content-type') || 'image/jpeg';
    const imageBuffer = await response.buffer();

    return {
      statusCode: 200,
      headers: {
        ...headers,
        'Content-Type': contentType,
        'Cache-Control': 'public, max-age=3600', // Cache pendant 1 heure
      },
      body: imageBuffer.toString('base64'),
      isBase64Encoded: true
    };

  } catch (error) {
    console.error('Error in image proxy:', error);
    
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({
        error: 'Internal server error',
        message: error.message
      })
    };
  }
};
