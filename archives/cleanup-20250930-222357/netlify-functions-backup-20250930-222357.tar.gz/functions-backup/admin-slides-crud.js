const { createClient } = require('@supabase/supabase-js')

const supabaseUrl = process.env.SUPABASE_URL
const supabaseKey = process.env.SUPABASE_SERVICE_ROLE_KEY
const supabase = createClient(supabaseUrl, supabaseKey)

exports.handler = async (event, context) => {
  // Enable CORS
  const headers = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'Content-Type, Authorization',
    'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS',
    'Content-Type': 'application/json',
  }

  if (event.httpMethod === 'OPTIONS') {
    return { statusCode: 200, headers, body: '' }
  }

  try {
    // Extract slide ID from path if present
    const pathParts = event.path.split('/')
    const slideId = pathParts.length > 3 ? pathParts[pathParts.length - 1] : null

    switch (event.httpMethod) {
      case 'GET':
        return await handleGetSlides(headers)
      
      case 'POST':
        return await handleCreateSlide(event.body, headers)
      
      case 'PUT':
        if (!slideId) {
          return {
            statusCode: 400,
            headers,
            body: JSON.stringify({ success: false, error: 'Slide ID required' })
          }
        }
        return await handleUpdateSlide(slideId, event.body, headers)
      
      case 'DELETE':
        if (!slideId) {
          return {
            statusCode: 400,
            headers,
            body: JSON.stringify({ success: false, error: 'Slide ID required' })
          }
        }
        return await handleDeleteSlide(slideId, headers)
      
      default:
        return {
          statusCode: 405,
          headers,
          body: JSON.stringify({ success: false, error: 'Method not allowed' })
        }
    }
  } catch (error) {
    console.error('Error in admin-slides-crud:', error)
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({
        success: false,
        error: 'Internal server error'
      })
    }
  }
}

async function handleGetSlides(headers) {
  const { data: slides, error } = await supabase
    .from('promotional_slides')
    .select(`
      *,
      ad_campaigns (
        id,
        company_name,
        campaign_title
      )
    `)
    .order('display_order', { ascending: true })

  if (error) {
    console.error('Error fetching slides:', error)
    throw error
  }

  return {
    statusCode: 200,
    headers,
    body: JSON.stringify({
      success: true,
      slides: slides || []
    })
  }
}

async function handleCreateSlide(body, headers) {
  const slideData = JSON.parse(body || '{}')
  
  const { data: newSlide, error } = await supabase
    .from('promotional_slides')
    .insert({
      campaign_id: slideData.campaign_id || null,
      title: slideData.title,
      description: slideData.description,
      image_url: slideData.image_url,
      mobile_image_url: slideData.mobile_image_url,
      link_url: slideData.link_url,
      cta_text: slideData.cta_text || 'En savoir plus',
      display_order: slideData.display_order || 0,
      is_active: slideData.is_active !== undefined ? slideData.is_active : true,
      admin_approved: slideData.admin_approved !== undefined ? slideData.admin_approved : false
    })
    .select()
    .single()

  if (error) {
    console.error('Error creating slide:', error)
    throw error
  }

  return {
    statusCode: 201,
    headers,
    body: JSON.stringify({
      success: true,
      slide: newSlide,
      message: 'Slide created successfully'
    })
  }
}

async function handleUpdateSlide(slideId, body, headers) {
  const slideData = JSON.parse(body || '{}')
  
  const updateData = {}
  if (slideData.title !== undefined) updateData.title = slideData.title
  if (slideData.description !== undefined) updateData.description = slideData.description
  if (slideData.image_url !== undefined) updateData.image_url = slideData.image_url
  if (slideData.mobile_image_url !== undefined) updateData.mobile_image_url = slideData.mobile_image_url
  if (slideData.link_url !== undefined) updateData.link_url = slideData.link_url
  if (slideData.cta_text !== undefined) updateData.cta_text = slideData.cta_text
  if (slideData.display_order !== undefined) updateData.display_order = slideData.display_order
  if (slideData.is_active !== undefined) updateData.is_active = slideData.is_active
  if (slideData.admin_approved !== undefined) updateData.admin_approved = slideData.admin_approved
  if (slideData.campaign_id !== undefined) updateData.campaign_id = slideData.campaign_id

  const { data: updatedSlide, error } = await supabase
    .from('promotional_slides')
    .update(updateData)
    .eq('id', slideId)
    .select()
    .single()

  if (error) {
    console.error('Error updating slide:', error)
    throw error
  }

  return {
    statusCode: 200,
    headers,
    body: JSON.stringify({
      success: true,
      slide: updatedSlide,
      message: 'Slide updated successfully'
    })
  }
}

async function handleDeleteSlide(slideId, headers) {
  const { error } = await supabase
    .from('promotional_slides')
    .delete()
    .eq('id', slideId)

  if (error) {
    console.error('Error deleting slide:', error)
    throw error
  }

  return {
    statusCode: 200,
    headers,
    body: JSON.stringify({
      success: true,
      message: 'Slide deleted successfully'
    })
  }
}
