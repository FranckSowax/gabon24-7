const { createClient } = require('@supabase/supabase-js')

const supabaseUrl = process.env.SUPABASE_URL
const supabaseKey = process.env.SUPABASE_SERVICE_ROLE_KEY
const supabase = createClient(supabaseUrl, supabaseKey)

exports.handler = async (event, context) => {
  // Enable CORS
  const headers = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'Content-Type',
    'Access-Control-Allow-Methods': 'GET, OPTIONS',
    'Content-Type': 'application/json',
  }

  if (event.httpMethod === 'OPTIONS') {
    return { statusCode: 200, headers, body: '' }
  }

  if (event.httpMethod === 'GET') {
    try {
      // Get the most recent article to determine last update time
      const { data: articles, error } = await supabase
        .from('articles')
        .select('created_at')
        .order('created_at', { ascending: false })
        .limit(1)

      if (error) {
        console.error('Error fetching last update:', error)
        throw error
      }

      let lastUpdateFormatted = 'Jamais'
      
      if (articles && articles.length > 0) {
        const lastUpdate = new Date(articles[0].created_at)
        const now = new Date()
        const diffMs = now.getTime() - lastUpdate.getTime()
        const diffMinutes = Math.floor(diffMs / (1000 * 60))
        const diffHours = Math.floor(diffMinutes / 60)
        const diffDays = Math.floor(diffHours / 24)

        if (diffMinutes < 1) {
          lastUpdateFormatted = 'À l\'instant'
        } else if (diffMinutes < 60) {
          lastUpdateFormatted = `Il y a ${diffMinutes} min`
        } else if (diffHours < 24) {
          lastUpdateFormatted = `Il y a ${diffHours}h`
        } else if (diffDays === 1) {
          lastUpdateFormatted = 'Hier'
        } else if (diffDays < 7) {
          lastUpdateFormatted = `Il y a ${diffDays} jours`
        } else {
          lastUpdateFormatted = lastUpdate.toLocaleDateString('fr-FR', {
            day: 'numeric',
            month: 'short',
            hour: '2-digit',
            minute: '2-digit'
          })
        }
      }

      return {
        statusCode: 200,
        headers,
        body: JSON.stringify({
          success: true,
          lastUpdateFormatted,
          lastUpdate: articles && articles.length > 0 ? articles[0].created_at : null
        })
      }
    } catch (error) {
      console.error('Error:', error)
      return {
        statusCode: 500,
        headers,
        body: JSON.stringify({
          success: false,
          error: error instanceof Error ? error.message : 'Unknown error occurred'
        })
      }
    }
  }

  return {
    statusCode: 405,
    headers,
    body: JSON.stringify({ success: false, error: 'Method not allowed' })
  }
}
