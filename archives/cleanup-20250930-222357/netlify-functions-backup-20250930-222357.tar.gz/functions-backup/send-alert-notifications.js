const { createClient } = require('@supabase/supabase-js');

// Environment variables
const supabaseUrl = process.env.SUPABASE_URL;
const supabaseServiceKey = process.env.SUPABASE_SERVICE_ROLE_KEY;
const brevoApiKey = process.env.BREVO_API_KEY; // For email notifications
const whapiApiKey = process.env.WHAPI_API_KEY; // For WhatsApp notifications

exports.handler = async (event, context) => {
  // CORS headers
  const headers = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'Content-Type, Authorization',
    'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
    'Content-Type': 'application/json'
  };

  if (event.httpMethod === 'OPTIONS') {
    return { statusCode: 200, headers };
  }

  if (event.httpMethod !== 'POST') {
    return {
      statusCode: 405,
      headers,
      body: JSON.stringify({ error: 'Method not allowed' })
    };
  }

  try {
    const { frequency = 'immediate', userId = null } = JSON.parse(event.body || '{}');
    
    // Initialize Supabase
    const supabase = createClient(supabaseUrl, supabaseServiceKey);

    // Get pending notifications based on frequency
    const notifications = await getPendingNotifications(supabase, frequency, userId);
    
    if (notifications.length === 0) {
      return {
        statusCode: 200,
        headers,
        body: JSON.stringify({
          success: true,
          sent: 0,
          message: 'No notifications to send'
        })
      };
    }

    let emailsSent = 0;
    let whatsappSent = 0;
    const errors = [];

    // Group notifications by user and alert
    const groupedNotifications = groupNotificationsByUserAndAlert(notifications);

    for (const { user, alert, matches } of groupedNotifications) {
      try {
        // Prepare notification content
        const content = await prepareNotificationContent(supabase, alert, matches);
        
        // Send email if enabled
        if (alert.delivery_channels.email && user.email) {
          const emailResult = await sendEmailNotification({
            to: user.email,
            alertName: alert.name,
            content,
            frequency: alert.delivery_frequency
          });
          
          if (emailResult.success) {
            emailsSent++;
          } else {
            errors.push(`Email failed for ${user.email}: ${emailResult.error}`);
          }
        }

        // Send WhatsApp if enabled
        if (alert.delivery_channels.whatsapp && user.phone_number) {
          const whatsappResult = await sendWhatsAppNotification({
            to: user.phone_number,
            alertName: alert.name,
            content,
            frequency: alert.delivery_frequency
          });
          
          if (whatsappResult.success) {
            whatsappSent++;
          } else {
            errors.push(`WhatsApp failed for ${user.phone_number}: ${whatsappResult.error}`);
          }
        }

        // Mark matches as notified
        const matchIds = matches.map(m => m.id);
        await supabase
          .from('alert_matches')
          .update({ 
            notification_sent: true,
            notification_channels: alert.delivery_channels
          })
          .in('id', matchIds);

        // Update usage stats
        await updateUsageStats(supabase, user.id, alert.id, matches.length);

      } catch (error) {
        console.error(`Error processing notifications for user ${user.id}:`, error);
        errors.push(`Processing failed for user ${user.id}: ${error.message}`);
      }
    }

    return {
      statusCode: 200,
      headers,
      body: JSON.stringify({
        success: true,
        emailsSent,
        whatsappSent,
        errors: errors.length > 0 ? errors : undefined,
        message: `Sent ${emailsSent} emails and ${whatsappSent} WhatsApp messages`
      })
    };

  } catch (error) {
    console.error('Error in send-alert-notifications function:', error);
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({ 
        error: 'Internal server error',
        message: error.message 
      })
    };
  }
};

async function getPendingNotifications(supabase, frequency, userId) {
  let query = supabase
    .from('alert_matches')
    .select(`
      *,
      user_alerts!inner (
        id, name, user_id, delivery_frequency, delivery_channels, 
        profiles!inner (email, phone_number, full_name)
      ),
      articles!inner (id, title, description, url, source, created_at)
    `)
    .eq('notification_sent', false)
    .eq('user_alerts.is_active', true);

  // Filter by delivery frequency
  if (frequency !== 'all') {
    query = query.eq('user_alerts.delivery_frequency', frequency);
  }

  // Filter by specific user if provided
  if (userId) {
    query = query.eq('user_alerts.user_id', userId);
  }

  // For non-immediate notifications, only get matches older than 30 minutes
  if (frequency !== 'immediate') {
    const thirtyMinutesAgo = new Date(Date.now() - 30 * 60 * 1000).toISOString();
    query = query.lte('created_at', thirtyMinutesAgo);
  }

  const { data, error } = await query.order('created_at', { ascending: false });
  
  if (error) throw error;
  return data || [];
}

function groupNotificationsByUserAndAlert(notifications) {
  const grouped = new Map();

  for (const notification of notifications) {
    const alert = notification.user_alerts;
    const user = alert.profiles;
    const key = `${user.id}-${alert.id}`;

    if (!grouped.has(key)) {
      grouped.set(key, {
        user: {
          id: alert.user_id,
          email: user.email,
          phone_number: user.phone_number,
          full_name: user.full_name
        },
        alert: {
          id: alert.id,
          name: alert.name,
          delivery_frequency: alert.delivery_frequency,
          delivery_channels: alert.delivery_channels
        },
        matches: []
      });
    }

    grouped.get(key).matches.push({
      id: notification.id,
      confidence_score: notification.confidence_score,
      matched_keywords: notification.matched_keywords,
      article: notification.articles
    });
  }

  return Array.from(grouped.values());
}

async function prepareNotificationContent(supabase, alert, matches) {
  const articles = matches.map(match => ({
    title: match.article.title,
    description: match.article.description,
    url: match.article.url,
    source: match.article.source,
    publishedAt: match.article.created_at,
    matchedKeywords: match.matched_keywords,
    confidence: Math.round(match.confidence_score * 100)
  }));

  return {
    alertName: alert.name,
    matchCount: matches.length,
    articles: articles.slice(0, 10), // Limit to 10 articles per notification
    summary: `${matches.length} nouvelle${matches.length > 1 ? 's' : ''} correspondance${matches.length > 1 ? 's' : ''} pour votre alerte "${alert.name}"`
  };
}

async function sendEmailNotification({ to, alertName, content, frequency }) {
  if (!brevoApiKey) {
    console.warn('Brevo API key not configured, skipping email notification');
    return { success: false, error: 'Email service not configured' };
  }

  try {
    // Generate HTML email content
    const htmlContent = generateEmailHTML(content);
    
    const emailData = {
      sender: {
        name: "Gabon 24/7 Veille",
        email: "veille@gabon24-7.com"
      },
      to: [{ email: to }],
      subject: `🔔 ${content.summary}`,
      htmlContent: htmlContent
    };

    const response = await fetch('https://api.brevo.com/v3/smtp/email', {
      method: 'POST',
      headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/json',
        'api-key': brevoApiKey
      },
      body: JSON.stringify(emailData)
    });

    if (!response.ok) {
      const errorData = await response.text();
      throw new Error(`Brevo API error: ${response.status} - ${errorData}`);
    }

    return { success: true };

  } catch (error) {
    console.error('Error sending email:', error);
    return { success: false, error: error.message };
  }
}

async function sendWhatsAppNotification({ to, alertName, content, frequency }) {
  if (!whapiApiKey) {
    console.warn('Whapi API key not configured, skipping WhatsApp notification');
    return { success: false, error: 'WhatsApp service not configured' };
  }

  try {
    // Generate WhatsApp message text
    const messageText = generateWhatsAppMessage(content);
    
    const messageData = {
      typing_time: 0,
      to: to,
      body: messageText
    };

    const response = await fetch('https://gate.whapi.cloud/messages/text', {
      method: 'POST',
      headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${whapiApiKey}`
      },
      body: JSON.stringify(messageData)
    });

    if (!response.ok) {
      const errorData = await response.text();
      throw new Error(`Whapi API error: ${response.status} - ${errorData}`);
    }

    return { success: true };

  } catch (error) {
    console.error('Error sending WhatsApp:', error);
    return { success: false, error: error.message };
  }
}

function generateEmailHTML(content) {
  return `
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <style>
    body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
    .container { max-width: 600px; margin: 0 auto; padding: 20px; }
    .header { background: linear-gradient(135deg, #f97316 0%, #dc2626 100%); color: white; padding: 30px; border-radius: 10px 10px 0 0; text-align: center; }
    .content { background: #f9fafb; padding: 20px; }
    .article { background: white; padding: 15px; margin: 10px 0; border-radius: 8px; border-left: 4px solid #f97316; }
    .keywords { display: flex; flex-wrap: wrap; gap: 5px; margin-top: 10px; }
    .keyword { background: #fed7aa; color: #9a3412; padding: 2px 8px; border-radius: 12px; font-size: 12px; }
    .footer { text-align: center; padding: 20px; color: #6b7280; font-size: 12px; }
    .button { display: inline-block; padding: 12px 24px; background: #f97316; color: white; text-decoration: none; border-radius: 6px; margin: 10px 0; }
    .confidence { background: #dbeafe; color: #1e40af; padding: 2px 6px; border-radius: 8px; font-size: 11px; font-weight: bold; }
  </style>
</head>
<body>
  <div class="container">
    <div class="header">
      <h1>🔔 ${content.alertName}</h1>
      <p>${content.summary}</p>
    </div>
      
    <div class="content">
      ${content.articles.map(article => `
        <div class="article">
          <h3>${article.title}</h3>
          <p style="color: #6b7280; font-size: 14px;">
            ${article.source} • ${new Date(article.publishedAt).toLocaleDateString('fr-FR')}
            <span class="confidence">${article.confidence}% de correspondance</span>
          </p>
          <p>${article.description || ''}</p>
          <div class="keywords">
            ${article.matchedKeywords.map(kw => `<span class="keyword">${kw}</span>`).join('')}
          </div>
          <a href="${article.url}" class="button" target="_blank">Lire l'article</a>
        </div>
      `).join('')}
    </div>
      
    <div class="footer">
      <p>Vous recevez cet email car vous avez créé une alerte sur Gabon 24/7</p>
      <p><a href="${process.env.NEXT_PUBLIC_APP_URL || 'https://gabon24-7.netlify.app'}/admin/veille">Gérer mes alertes</a></p>
    </div>
  </div>
</body>
</html>
  `;
}

function generateWhatsAppMessage(content) {
  let message = `🔔 *${content.alertName}*\n\n`;
  message += `${content.summary}\n\n`;
  
  content.articles.slice(0, 5).forEach((article, index) => {
    message += `*${index + 1}. ${article.title}*\n`;
    message += `📰 ${article.source}\n`;
    message += `🎯 ${article.confidence}% de correspondance\n`;
    if (article.description) {
      message += `${article.description.substring(0, 100)}...\n`;
    }
    message += `🔗 ${article.url}\n\n`;
  });
  
  if (content.articles.length > 5) {
    message += `... et ${content.articles.length - 5} autres articles\n\n`;
  }
  
  message += `Gérer vos alertes: ${process.env.NEXT_PUBLIC_APP_URL || 'https://gabon24-7.netlify.app'}/admin/veille`;
  
  return message;
}

async function updateUsageStats(supabase, userId, alertId, notificationCount) {
  try {
    const today = new Date().toISOString().split('T')[0];

    await supabase
      .from('alert_usage_stats')
      .upsert({
        user_id: userId,
        alert_id: alertId,
        date: today,
        notifications_sent: notificationCount
      }, {
        onConflict: 'user_id,alert_id,date',
        ignoreDuplicates: false
      });
  } catch (error) {
    console.error('Error updating usage stats:', error);
  }
}
