const fetch = require('node-fetch');
const cheerio = require('cheerio');

// Fonction pour extraire l'image d'un post Facebook de Gabon 24
async function extractFacebookGabon24Image(facebookUrl) {
  if (!facebookUrl || !facebookUrl.includes('facebook.com')) {
    return null;
  }

  // Vérifier si c'est bien un post de tvgabon24
  if (!facebookUrl.includes('tvgabon24') && !facebookUrl.includes('Gabon24')) {
    return null;
  }

  try {
    console.log(`🔍 [GABON24-FB] Extraction image depuis: ${facebookUrl}`);
    
    // Headers pour contourner les restrictions Facebook
    const headers = {
      'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
      'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8',
      'Accept-Language': 'fr-FR,fr;q=0.9,en;q=0.8',
      'Accept-Encoding': 'gzip, deflate, br',
      'Referer': 'https://www.facebook.com/',
      'Origin': 'https://www.facebook.com',
      'Sec-Fetch-Dest': 'document',
      'Sec-Fetch-Mode': 'navigate',
      'Sec-Fetch-Site': 'same-origin',
      'Sec-Ch-Ua': '"Not_A Brand";v="8", "Chromium";v="120", "Google Chrome";v="120"',
      'Sec-Ch-Ua-Mobile': '?0',
      'Sec-Ch-Ua-Platform': '"Windows"',
      'Cache-Control': 'no-cache'
    };

    // Essayer d'accéder à la page Facebook
    const response = await fetch(facebookUrl, {
      headers,
      timeout: 15000,
      redirect: 'follow'
    });

    if (!response.ok) {
      console.warn(`⚠️ [GABON24-FB] Erreur HTTP ${response.status} pour ${facebookUrl}`);
      
      // Si accès bloqué, essayer l'URL mobile
      if (response.status === 403 || response.status === 429) {
        const mobileUrl = facebookUrl.replace('www.facebook.com', 'm.facebook.com');
        console.log(`🔄 [GABON24-FB] Tentative avec URL mobile: ${mobileUrl}`);
        
        const mobileResponse = await fetch(mobileUrl, {
          headers: {
            ...headers,
            'User-Agent': 'Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/15.0 Mobile/15E148 Safari/604.1'
          },
          timeout: 10000
        });
        
        if (!mobileResponse.ok) {
          return null;
        }
        
        const mobileHtml = await mobileResponse.text();
        return extractImageFromHtml(mobileHtml, facebookUrl, true);
      }
      
      return null;
    }

    const html = await response.text();
    return extractImageFromHtml(html, facebookUrl, false);

  } catch (error) {
    console.error(`❌ [GABON24-FB] Erreur extraction: ${error.message}`);
    
    // Fallback: essayer d'extraire depuis les meta tags Open Graph uniquement
    try {
      return await extractOpenGraphImage(facebookUrl);
    } catch (fallbackError) {
      console.error(`❌ [GABON24-FB] Fallback échoué: ${fallbackError.message}`);
      return null;
    }
  }
}

// Extraire image depuis le HTML Facebook
function extractImageFromHtml(html, originalUrl, isMobile = false) {
  const $ = cheerio.load(html);
  
  console.log(`📄 [GABON24-FB] Analyse HTML (mobile: ${isMobile})`);

  // Stratégies d'extraction pour Facebook
  const strategies = [
    // 1. Meta tags Open Graph (plus fiable)
    () => {
      const ogImage = $('meta[property="og:image"]').attr('content');
      if (ogImage && isValidFacebookImage(ogImage)) {
        console.log(`✅ [GABON24-FB] Image Open Graph: ${ogImage}`);
        return ogImage;
      }
      return null;
    },

    // 2. Meta Twitter
    () => {
      const twitterImage = $('meta[name="twitter:image"]').attr('content');
      if (twitterImage && isValidFacebookImage(twitterImage)) {
        console.log(`✅ [GABON24-FB] Image Twitter: ${twitterImage}`);
        return twitterImage;
      }
      return null;
    },

    // 3. Images dans le contenu du post (version desktop)
    () => {
      if (isMobile) return null;
      
      const contentImages = [
        'div[data-pagelet="FeedUnit_0"] img',
        '[role="article"] img',
        '[data-testid="post_message"] img',
        'div[data-ft] img'
      ];

      for (const selector of contentImages) {
        const img = $(selector).first();
        const src = img.attr('src') || img.attr('data-src');
        if (src && isValidFacebookImage(src)) {
          console.log(`✅ [GABON24-FB] Image contenu desktop: ${src}`);
          return src;
        }
      }
      return null;
    },

    // 4. Images dans le contenu mobile
    () => {
      if (!isMobile) return null;
      
      const mobileSelectors = [
        'div[data-ft] img',
        '.story_body_container img',
        '.userContentWrapper img',
        'div[id^="m_story"] img'
      ];

      for (const selector of mobileSelectors) {
        const img = $(selector).first();
        const src = img.attr('src') || img.attr('data-src');
        if (src && isValidFacebookImage(src)) {
          console.log(`✅ [GABON24-FB] Image contenu mobile: ${src}`);
          return src;
        }
      }
      return null;
    },

    // 5. Recherche générique d'images Facebook
    () => {
      const allImages = $('img').toArray();
      
      for (const img of allImages) {
        const src = $(img).attr('src') || $(img).attr('data-src');
        if (src && isValidFacebookImage(src) && !isProfileOrIcon(src)) {
          console.log(`✅ [GABON24-FB] Image générique: ${src}`);
          return src;
        }
      }
      return null;
    }
  ];

  // Essayer chaque stratégie
  for (let i = 0; i < strategies.length; i++) {
    try {
      const result = strategies[i]();
      if (result) {
        return `/.netlify/functions/image-proxy?url=${encodeURIComponent(result)}`;
      }
    } catch (error) {
      console.warn(`⚠️ [GABON24-FB] Stratégie ${i + 1} échouée: ${error.message}`);
    }
  }

  return null;
}

// Fallback pour extraire uniquement les meta tags
async function extractOpenGraphImage(url) {
  console.log(`🔄 [GABON24-FB] Tentative fallback Open Graph pour: ${url}`);
  
  try {
    const response = await fetch(url, {
      headers: {
        'User-Agent': 'facebookexternalhit/1.1',
        'Accept': 'text/html'
      },
      timeout: 8000
    });

    if (response.ok) {
      const html = await response.text();
      const $ = cheerio.load(html);
      
      const ogImage = $('meta[property="og:image"]').attr('content');
      if (ogImage && isValidFacebookImage(ogImage)) {
        console.log(`✅ [GABON24-FB] Fallback réussi: ${ogImage}`);
        return `/.netlify/functions/image-proxy?url=${encodeURIComponent(ogImage)}`;
      }
    }
  } catch (error) {
    console.warn(`⚠️ [GABON24-FB] Fallback échoué: ${error.message}`);
  }
  
  return null;
}

// Valider qu'une image Facebook est valide
function isValidFacebookImage(imageUrl) {
  if (!imageUrl || typeof imageUrl !== 'string') return false;
  
  return (
    (imageUrl.includes('fbcdn.net') || 
     imageUrl.includes('scontent') || 
     imageUrl.includes('facebook.com')) &&
    imageUrl.match(/\.(jpg|jpeg|png|gif|webp)(\?.*)?$/i) &&
    !isProfileOrIcon(imageUrl) &&
    imageUrl.length > 30
  );
}

// Éviter les photos de profil et icônes
function isProfileOrIcon(imageUrl) {
  const excludePatterns = [
    'profile',
    'avatar',
    'icon',
    'logo',
    'safe_image',
    'default',
    'placeholder',
    '/s40x40/',
    '/s60x60/',
    '/s50x50/',
    'p40x40',
    'p50x50',
    'p60x60',
    'mini_',
    'thumb_'
  ];
  
  return excludePatterns.some(pattern => imageUrl.toLowerCase().includes(pattern));
}

// Export pour utilisation dans d'autres fonctions
module.exports = { extractFacebookGabon24Image };

// Handler Netlify pour test direct
exports.handler = async (event, context) => {
  const headers = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'Content-Type',
    'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
  };

  if (event.httpMethod === 'OPTIONS') {
    return { statusCode: 200, headers, body: '' };
  }

  try {
    const { url } = JSON.parse(event.body || '{}') || event.queryStringParameters || {};
    
    if (!url) {
      return {
        statusCode: 400,
        headers,
        body: JSON.stringify({ error: 'URL parameter required' })
      };
    }

    const imageUrl = await extractFacebookGabon24Image(url);
    
    return {
      statusCode: 200,
      headers,
      body: JSON.stringify({
        success: true,
        facebookUrl: url,
        imageUrl: imageUrl,
        timestamp: new Date().toISOString()
      })
    };

  } catch (error) {
    console.error('Error in facebook-gabon24-image-extractor:', error);
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({
        success: false,
        error: error.message
      })
    };
  }
};
