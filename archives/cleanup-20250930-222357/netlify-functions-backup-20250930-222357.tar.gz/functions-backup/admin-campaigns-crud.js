const { createClient } = require('@supabase/supabase-js')

const supabaseUrl = process.env.SUPABASE_URL
const supabaseKey = process.env.SUPABASE_SERVICE_ROLE_KEY
const supabase = createClient(supabaseUrl, supabaseKey)

exports.handler = async (event, context) => {
  // Enable CORS
  const headers = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'Content-Type, Authorization',
    'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS',
    'Content-Type': 'application/json',
  }

  if (event.httpMethod === 'OPTIONS') {
    return { statusCode: 200, headers, body: '' }
  }

  try {
    // Extract campaign ID from path if present
    const pathParts = event.path.split('/')
    const campaignId = pathParts.length > 3 ? pathParts[pathParts.length - 1] : null

    switch (event.httpMethod) {
      case 'GET':
        return await handleGetCampaigns(headers)
      
      case 'POST':
        return await handleCreateCampaign(event.body, headers)
      
      case 'PUT':
        if (!campaignId) {
          return {
            statusCode: 400,
            headers,
            body: JSON.stringify({ success: false, error: 'Campaign ID required' })
          }
        }
        return await handleUpdateCampaign(campaignId, event.body, headers)
      
      case 'DELETE':
        if (!campaignId) {
          return {
            statusCode: 400,
            headers,
            body: JSON.stringify({ success: false, error: 'Campaign ID required' })
          }
        }
        return await handleDeleteCampaign(campaignId, headers)
      
      default:
        return {
          statusCode: 405,
          headers,
          body: JSON.stringify({ success: false, error: 'Method not allowed' })
        }
    }
  } catch (error) {
    console.error('Error in admin-campaigns-crud:', error)
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({
        success: false,
        error: 'Internal server error'
      })
    }
  }
}

async function handleGetCampaigns(headers) {
  const { data: campaigns, error } = await supabase
    .from('ad_campaigns')
    .select(`
      *,
      promotional_slides (
        id,
        title,
        description,
        image_url,
        mobile_image_url,
        view_count,
        click_count,
        is_active,
        admin_approved,
        cta_text,
        display_order
      )
    `)
    .order('created_at', { ascending: false })

  if (error) {
    console.error('Error fetching campaigns:', error)
    throw error
  }

  return {
    statusCode: 200,
    headers,
    body: JSON.stringify({
      success: true,
      campaigns: campaigns || []
    })
  }
}

async function handleCreateCampaign(body, headers) {
  const campaignData = JSON.parse(body || '{}')
  
  const { data: newCampaign, error } = await supabase
    .from('ad_campaigns')
    .insert({
      company_name: campaignData.company_name,
      contact_email: campaignData.contact_email,
      contact_phone: campaignData.contact_phone,
      campaign_title: campaignData.campaign_title,
      campaign_description: campaignData.campaign_description,
      start_date: campaignData.start_date,
      end_date: campaignData.end_date,
      budget_amount: campaignData.budget_amount,
      payment_status: campaignData.payment_status || 'pending',
      is_active: campaignData.is_active !== undefined ? campaignData.is_active : true,
      admin_approved: campaignData.admin_approved !== undefined ? campaignData.admin_approved : false,
      status: campaignData.status || 'draft'
    })
    .select()
    .single()

  if (error) {
    console.error('Error creating campaign:', error)
    throw error
  }

  return {
    statusCode: 201,
    headers,
    body: JSON.stringify({
      success: true,
      campaign: newCampaign,
      message: 'Campaign created successfully'
    })
  }
}

async function handleUpdateCampaign(campaignId, body, headers) {
  const campaignData = JSON.parse(body || '{}')
  
  const updateData = {}
  if (campaignData.company_name !== undefined) updateData.company_name = campaignData.company_name
  if (campaignData.contact_email !== undefined) updateData.contact_email = campaignData.contact_email
  if (campaignData.contact_phone !== undefined) updateData.contact_phone = campaignData.contact_phone
  if (campaignData.campaign_title !== undefined) updateData.campaign_title = campaignData.campaign_title
  if (campaignData.campaign_description !== undefined) updateData.campaign_description = campaignData.campaign_description
  if (campaignData.start_date !== undefined) updateData.start_date = campaignData.start_date
  if (campaignData.end_date !== undefined) updateData.end_date = campaignData.end_date
  if (campaignData.budget_amount !== undefined) updateData.budget_amount = campaignData.budget_amount
  if (campaignData.payment_status !== undefined) updateData.payment_status = campaignData.payment_status
  if (campaignData.is_active !== undefined) updateData.is_active = campaignData.is_active
  if (campaignData.admin_approved !== undefined) updateData.admin_approved = campaignData.admin_approved
  if (campaignData.status !== undefined) updateData.status = campaignData.status

  const { data: updatedCampaign, error } = await supabase
    .from('ad_campaigns')
    .update(updateData)
    .eq('id', campaignId)
    .select()
    .single()

  if (error) {
    console.error('Error updating campaign:', error)
    throw error
  }

  return {
    statusCode: 200,
    headers,
    body: JSON.stringify({
      success: true,
      campaign: updatedCampaign,
      message: 'Campaign updated successfully'
    })
  }
}

async function handleDeleteCampaign(campaignId, headers) {
  const { error } = await supabase
    .from('ad_campaigns')
    .delete()
    .eq('id', campaignId)

  if (error) {
    console.error('Error deleting campaign:', error)
    throw error
  }

  return {
    statusCode: 200,
    headers,
    body: JSON.stringify({
      success: true,
      message: 'Campaign deleted successfully'
    })
  }
}
