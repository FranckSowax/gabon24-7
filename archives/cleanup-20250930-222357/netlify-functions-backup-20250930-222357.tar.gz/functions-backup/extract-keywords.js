const { createClient } = require('@supabase/supabase-js');

// Environment variables
const supabaseUrl = process.env.SUPABASE_URL;
const supabaseServiceKey = process.env.SUPABASE_SERVICE_ROLE_KEY;
const openaiApiKey = process.env.OPENAI_API_KEY;

exports.handler = async (event, context) => {
  // CORS headers
  const headers = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'Content-Type, Authorization',
    'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
    'Content-Type': 'application/json'
  };

  if (event.httpMethod === 'OPTIONS') {
    return { statusCode: 200, headers };
  }

  if (event.httpMethod !== 'POST') {
    return {
      statusCode: 405,
      headers,
      body: JSON.stringify({ error: 'Method not allowed' })
    };
  }

  try {
    const { alertId, userKeywords } = JSON.parse(event.body);

    if (!alertId || !userKeywords || !Array.isArray(userKeywords)) {
      return {
        statusCode: 400,
        headers,
        body: JSON.stringify({ error: 'alertId and userKeywords array are required' })
      };
    }

    // Initialize Supabase
    const supabase = createClient(supabaseUrl, supabaseServiceKey);

    // Enhanced keyword extraction using OpenAI
    const extractedKeywords = await extractKeywordsWithAI(userKeywords);
    const semanticKeywords = await generateSemanticKeywords(userKeywords, extractedKeywords);

    // Update alert with extracted keywords
    const { error: updateError } = await supabase
      .from('user_alerts')
      .update({
        extracted_keywords: extractedKeywords,
        semantic_keywords: semanticKeywords,
        updated_at: new Date().toISOString()
      })
      .eq('id', alertId);

    if (updateError) throw updateError;

    // Log API usage for optimization
    await logApiUsage(supabase, alertId, 'keyword_extraction');

    return {
      statusCode: 200,
      headers,
      body: JSON.stringify({
        success: true,
        extractedKeywords,
        semanticKeywords,
        message: 'Keywords extracted and updated successfully'
      })
    };

  } catch (error) {
    console.error('Error in extract-keywords function:', error);
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({ 
        error: 'Internal server error',
        message: error.message 
      })
    };
  }
};

async function extractKeywordsWithAI(userKeywords) {
  if (!openaiApiKey) {
    console.warn('OpenAI API key not configured, returning original keywords');
    return userKeywords;
  }

  try {
    const prompt = `
Analyse ces mots-clés pour la surveillance d'actualités gabonaises et enrichis-les avec des variantes, synonymes et termes connexes pertinents :

Mots-clés originaux: ${userKeywords.join(', ')}

Instructions:
- Ajoute des synonymes et variantes orthographiques
- Inclus des termes connexes spécifiques au contexte gabonais
- Considère les acronymes et abréviations courantes
- Évite les termes trop génériques
- Maximum 15 mots-clés au total

Réponds uniquement avec une liste de mots-clés séparés par des virgules.
`;

    const response = await fetch('https://api.openai.com/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${openaiApiKey}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        model: 'gpt-3.5-turbo',
        messages: [
          {
            role: 'system', 
            content: 'Tu es un expert en surveillance média et actualité gabonaise. Tu enrichis les mots-clés pour améliorer la détection d\'articles pertinents.'
          },
          { role: 'user', content: prompt }
        ],
        max_tokens: 150,
        temperature: 0.3
      })
    });

    if (!response.ok) {
      throw new Error(`OpenAI API error: ${response.status}`);
    }

    const data = await response.json();
    const extractedText = data.choices[0]?.message?.content?.trim() || '';
    
    // Parse keywords from response
    const keywords = extractedText
      .split(',')
      .map(kw => kw.trim())
      .filter(kw => kw.length > 1)
      .slice(0, 15);

    return keywords.length > 0 ? keywords : userKeywords;

  } catch (error) {
    console.error('Error extracting keywords with AI:', error);
    return userKeywords; // Fallback to original keywords
  }
}

async function generateSemanticKeywords(userKeywords, extractedKeywords) {
  if (!openaiApiKey) {
    return [];
  }

  try {
    const allKeywords = [...new Set([...userKeywords, ...extractedKeywords])];
    
    const prompt = `
Génère des mots-clés sémantiques pour améliorer la détection d'articles liés à ces sujets dans le contexte gabonais :

Mots-clés de base: ${allKeywords.join(', ')}

Génère des termes sémantiquement liés qui pourraient apparaître dans des articles connexes:
- Concepts liés (institutions, personnalités, lieux)
- Termes techniques du domaine
- Expressions courantes au Gabon
- Noms propres pertinents
- Maximum 10 termes

Réponds uniquement avec une liste séparée par des virgules.
`;

    const response = await fetch('https://api.openai.com/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${openaiApiKey}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        model: 'gpt-3.5-turbo',
        messages: [
          { role: 'system', content: 'Tu es un expert en analyse sémantique pour les médias gabonais.' },
          { role: 'user', content: prompt }
        ],
        max_tokens: 100,
        temperature: 0.4
      })
    });

    if (!response.ok) {
      throw new Error(`OpenAI API error: ${response.status}`);
    }

    const data = await response.json();
    const semanticText = data.choices[0]?.message?.content?.trim() || '';
    
    const semanticKeywords = semanticText
      .split(',')
      .map(kw => kw.trim())
      .filter(kw => kw.length > 1)
      .slice(0, 10);

    return semanticKeywords;

  } catch (error) {
    console.error('Error generating semantic keywords:', error);
    return [];
  }
}

async function logApiUsage(supabase, alertId, operation) {
  try {
    // Get alert owner
    const { data: alert } = await supabase
      .from('user_alerts')
      .select('user_id')
      .eq('id', alertId)
      .single();

    if (!alert) return;

    const today = new Date().toISOString().split('T')[0];

    // Update or insert usage stats
    const { error } = await supabase
      .from('alert_usage_stats')
      .upsert({
        user_id: alert.user_id,
        alert_id: alertId,
        date: today,
        api_calls_count: 1
      }, {
        onConflict: 'user_id,alert_id,date',
        ignoreDuplicates: false
      });

    if (error) {
      console.error('Error logging API usage:', error);
    }
  } catch (error) {
    console.error('Error in logApiUsage:', error);
  }
}
