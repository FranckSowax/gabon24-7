const { createClient } = require('@supabase/supabase-js')

const supabaseUrl = process.env.SUPABASE_URL
const supabaseServiceKey = process.env.SUPABASE_SERVICE_ROLE_KEY
const openaiApiKey = process.env.OPENAI_API_KEY
const deepseekApiKey = process.env.DEEPSEEK_API_KEY

console.log('🔍 Environment variables check:')
console.log('SUPABASE_URL:', supabaseUrl ? 'SET' : 'MISSING')
console.log('SUPABASE_SERVICE_ROLE_KEY:', supabaseServiceKey ? 'SET' : 'MISSING')
console.log('OPENAI_API_KEY:', openaiApiKey ? `SET (${openaiApiKey.substring(0, 7)}...)` : 'MISSING')
console.log('DEEPSEEK_API_KEY:', deepseekApiKey ? `SET (${deepseekApiKey.substring(0, 7)}...)` : 'MISSING')

const supabase = createClient(supabaseUrl, supabaseServiceKey)

exports.handler = async (event, context) => {
  // Set CORS headers
  const headers = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'Content-Type',
    'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
    'Content-Type': 'application/json'
  }

  // Handle preflight requests
  if (event.httpMethod === 'OPTIONS') {
    return {
      statusCode: 200,
      headers,
      body: ''
    }
  }

  if (event.httpMethod !== 'POST') {
    return {
      statusCode: 405,
      headers,
      body: JSON.stringify({ error: 'Method not allowed' })
    }
  }

  try {
    console.log('📨 Raw event body:', event.body)
    const requestData = JSON.parse(event.body)
    console.log('📋 Parsed request data:', requestData)
    const { article, secteur, budget, userId } = requestData

    console.log('📥 Received data:', { 
      article: article?.title, 
      secteur: secteur?.nom,
      budget: budget,
      userId: userId 
    })
    
    if (!article || !article.title) {
      console.log('❌ Missing article or title')
      return {
        statusCode: 400,
        headers,
        body: JSON.stringify({ error: 'Article title is required' })
      }
    }

    if (!secteur || !secteur.nom) {
      console.log('❌ Missing secteur')
      return {
        statusCode: 400,
        headers,
        body: JSON.stringify({ error: 'Secteur is required' })
      }
    }

    if (!budget) {
      console.log('❌ Missing budget')
      return {
        statusCode: 400,
        headers,
        body: JSON.stringify({ error: 'Budget level is required' })
      }
    }

    if (!userId) {
      console.log('❌ Missing userId')
      return {
        statusCode: 400,
        headers,
        body: JSON.stringify({ error: 'User ID is required' })
      }
    }

    // Check user credit balance before processing
    console.log('💳 Checking user credit balance...')
    const creditResponse = await fetch(`${process.env.URL}/.netlify/functions/credit-manager`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        action: 'checkBalance',
        userId: userId
      })
    })

    if (!creditResponse.ok) {
      console.log('❌ Error checking credit balance')
      return {
        statusCode: 500,
        headers,
        body: JSON.stringify({ error: 'Error checking credit balance' })
      }
    }

    const creditData = await creditResponse.json()
    console.log('💰 Credit balance:', creditData.available_balance)

    // Service costs 10 credits for opportunities generation
    const REQUIRED_CREDITS = 10
    if (creditData.available_balance < REQUIRED_CREDITS) {
      console.log(`❌ Insufficient credits: ${creditData.available_balance} < ${REQUIRED_CREDITS}`)
      return {
        statusCode: 402, // Payment Required
        headers,
        body: JSON.stringify({ 
          error: 'Crédits insuffisants', 
          message: `Cette analyse nécessite ${REQUIRED_CREDITS} crédits. Votre solde actuel est de ${creditData.available_balance} crédits.`,
          required_credits: REQUIRED_CREDITS,
          current_balance: creditData.available_balance,
          need_to_purchase: REQUIRED_CREDITS - creditData.available_balance
        })
      }
    }

    // Check available AI APIs
    console.log('🔑 AI API Keys status:')
    console.log('OpenAI:', openaiApiKey ? `AVAILABLE (${openaiApiKey.length} chars)` : 'NOT FOUND')
    console.log('DeepSeek:', deepseekApiKey ? `AVAILABLE (${deepseekApiKey.length} chars)` : 'NOT FOUND')
    
    // Check if any AI API is available
    const hasOpenAI = openaiApiKey && openaiApiKey.trim() !== '' && openaiApiKey !== 'undefined' && openaiApiKey !== 'null'
    const hasDeepSeek = deepseekApiKey && deepseekApiKey.trim() !== '' && deepseekApiKey !== 'undefined' && deepseekApiKey !== 'null'
    
    if (!hasOpenAI && !hasDeepSeek) {
      console.log('⚠️ Using DEMO data - No AI API keys configured')
      const demoOpportunities = generateDemoOpportunities(article, secteur, budget)
      return {
        statusCode: 200,
        headers,
        body: JSON.stringify(demoOpportunities)
      }
    }

    // Try OpenAI first, fallback to DeepSeek if needed
    let opportunities
    try {
      if (hasOpenAI) {
        console.log('🤖 Calling OpenAI for opportunities generation...')
        opportunities = await generateOpportunitiesWithAI(article, secteur, budget, 'openai')
      } else if (hasDeepSeek) {
        console.log('🤖 Calling DeepSeek for opportunities generation...')
        opportunities = await generateOpportunitiesWithAI(article, secteur, budget, 'deepseek')
      }
    } catch (error) {
      console.log('❌ Primary AI failed, trying fallback...')
      if (hasOpenAI && hasDeepSeek) {
        try {
          console.log('🔄 Trying DeepSeek as fallback...')
          opportunities = await generateOpportunitiesWithAI(article, secteur, budget, 'deepseek')
        } catch (fallbackError) {
          console.log('❌ All AI APIs failed, using demo data')
          const demoOpportunities = generateDemoOpportunities(article, secteur, budget)
          return {
            statusCode: 200,
            headers,
            body: JSON.stringify(demoOpportunities)
          }
        }
      } else {
        throw error
      }
    }

    console.log('✅ AI opportunities generation completed')

    // Consume credits after successful AI analysis
    console.log('💳 Consuming credits after successful analysis...')
    try {
      const consumeResponse = await fetch(`${process.env.URL}/.netlify/functions/credit-manager`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          action: 'consumeCredits',
          userId: userId,
          serviceName: 'generate_opportunities',
          amount: REQUIRED_CREDITS,
          referenceId: `opportunity_${Date.now()}`,
          openaiUsage: {
            model: hasOpenAI ? 'gpt-4o-mini' : 'deepseek-chat',
            prompt_tokens: 500, // Estimated
            completion_tokens: 300, // Estimated
            total_tokens: 800,
            estimated_cost: 0.05 // Estimated in XAF
          }
        })
      })

      if (consumeResponse.ok) {
        console.log('✅ Credits consumed successfully')
      } else {
        console.log('⚠️ Warning: Credit consumption failed, but analysis was successful')
      }
    } catch (creditError) {
      console.log('⚠️ Warning: Credit consumption error:', creditError.message)
    }

    return {
      statusCode: 200,
      headers,
      body: JSON.stringify(opportunities)
    }

  } catch (error) {
    console.error('❌ Error generating opportunities:', error)
    
    // Fallback to demo data
    console.log('🔄 Falling back to DEMO data due to error')
    const demoOpportunities = generateDemoOpportunities(
      { title: 'Article par défaut' }, 
      { nom: 'Secteur par défaut' }, 
      'micro'
    )
    
    return {
      statusCode: 200,
      headers,
      body: JSON.stringify(demoOpportunities)
    }
  }
}

async function generateOpportunitiesWithAI(article, secteur, budget, provider = 'openai') {
  console.log(`🚀 Starting ${provider.toUpperCase()} opportunities generation...`)
  
  const budgetInfo = {
    micro: { range: '0-500K XAF', description: 'Micro-entrepreneur individuel' },
    petit: { range: '500K-2M XAF', description: 'Petite entreprise familiale' },
    moyen: { range: '2M-10M XAF', description: 'Entreprise de taille moyenne' },
    confortable: { range: '10M+ XAF', description: 'Grande entreprise/investissement' }
  }

  const prompt = `Tu es un expert business gabonais. Génère 3 opportunités d'affaires spécifiques pour le budget ${budget.toUpperCase()}.

**CONTEXTE GABONAIS :**
Population: 2.3M, Mobile: 85%, Internet: 62%
Économie: Pétrole, bois, manganèse, agriculture

**SECTEUR CHOISI :** ${secteur.nom}
**BUDGET :** ${budgetInfo[budget].range} (${budgetInfo[budget].description})

**ARTICLE ANALYSÉ :**
Titre: ${article.title}
Contenu: ${article.summary || article.content || 'Contenu non disponible'}

Réponds en JSON strict:
{
  "opportunites": [
    {
      "titre": "Nom de l'opportunité",
      "description": "Description adaptée au budget ${budget}",
      "investissement_initial": "Montant précis en XAF",
      "revenus_mensuels": "Estimation en XAF/mois",
      "actions_immediates": ["Action 1", "Action 2", "Action 3"],
      "ressources_necessaires": ["Ressource 1", "Ressource 2"],
      "delai_lancement": "X semaines/mois",
      "score_faisabilite": 8
    }
  ]
}

IMPORTANT: Réponds UNIQUEMENT avec le JSON, sans texte avant ou après.`

  try {
    const apiKey = provider === 'openai' ? openaiApiKey : deepseekApiKey
    const apiUrl = provider === 'openai' 
      ? 'https://api.openai.com/v1/chat/completions'
      : 'https://api.deepseek.com/v1/chat/completions'
    const model = provider === 'openai' ? 'gpt-4o-mini' : 'deepseek-chat'
    
    console.log(`📡 Making request to ${provider.toUpperCase()} API...`)
    const controller = new AbortController()
    const timeoutId = setTimeout(() => controller.abort(), 25000) // 25 second timeout
    
    const response = await fetch(apiUrl, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${apiKey}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        model: model,
        messages: [
          {
            role: 'system',
            content: 'Expert business gabonais. Réponds en JSON strict uniquement.'
          },
          {
            role: 'user',
            content: prompt
          }
        ],
        max_tokens: 600,
        temperature: 0.5
      }),
      signal: controller.signal
    })
    
    clearTimeout(timeoutId)

    console.log('📊 AI API response status:', response.status)
    if (!response.ok) {
      throw new Error(`AI API error: ${response.status}`)
    }

    const data = await response.json()
    console.log('🎯 AI response received, parsing content...')
    const content = data.choices[0].message.content

    // Parse the JSON response
    console.log('🔍 Raw AI content:', content.substring(0, 200) + '...')
    
    try {
      const jsonMatch = content.match(/\{[\s\S]*\}/)
      if (jsonMatch) {
        let jsonString = jsonMatch[0]
        
        // Clean up common JSON formatting issues
        jsonString = jsonString
          .replace(/,(\s*[}\]])/g, '$1') // Remove trailing commas
          .replace(/([{,]\s*)(\w+):/g, '$1"$2":') // Add quotes to unquoted keys
          .replace(/:\s*'([^']*)'/g, ': "$1"') // Replace single quotes with double quotes
          .replace(/\n/g, ' ') // Remove newlines
          .replace(/\t/g, ' ') // Remove tabs
          .replace(/\s+/g, ' ') // Normalize whitespace
        
        const opportunitiesData = JSON.parse(jsonString)
        console.log('✅ Successfully parsed AI response')
        
        return {
          id: `opportunities_${Date.now()}`,
          secteur: secteur.nom,
          budget: budget,
          ...opportunitiesData
        }
      } else {
        console.error('❌ No JSON found in AI response:', content)
        throw new Error('No JSON found in AI response')
      }
    } catch (parseError) {
      console.error('❌ JSON parsing failed:', parseError.message)
      console.error('🔍 Content that failed to parse:', content)
      throw new Error(`JSON parsing failed: ${parseError.message}`)
    }

  } catch (error) {
    console.error('❌ AI API error:', error)
    throw error
  }
}

function generateDemoOpportunities(article, secteur, budget) {
  console.log('🎭 Generating DEMO opportunities data for:', { 
    article: article.title, 
    secteur: secteur.nom, 
    budget 
  })

  const budgetInfo = {
    micro: { range: '0-500K XAF', investment: '250,000 XAF', revenue: '50,000 XAF/mois' },
    petit: { range: '500K-2M XAF', investment: '1,200,000 XAF', revenue: '200,000 XAF/mois' },
    moyen: { range: '2M-10M XAF', investment: '5,000,000 XAF', revenue: '800,000 XAF/mois' },
    confortable: { range: '10M+ XAF', investment: '15,000,000 XAF', revenue: '2,500,000 XAF/mois' }
  }

  return {
    id: `demo_opportunities_${Date.now()}`,
    secteur: secteur.nom,
    budget: budget,
    opportunites: [
      {
        titre: `Opportunité ${secteur.nom} - Budget ${budget.toUpperCase()}`,
        description: `Solution d'affaires adaptée au budget ${budget} dans le secteur ${secteur.nom}, basée sur l'analyse de l'article "${article.title}".`,
        investissement_initial: budgetInfo[budget].investment,
        revenus_mensuels: budgetInfo[budget].revenue,
        actions_immediates: [
          "Étude de marché locale",
          "Identification des partenaires",
          "Préparation du business plan"
        ],
        ressources_necessaires: [
          "Capital de démarrage",
          "Expertise sectorielle",
          "Réseau commercial"
        ],
        delai_lancement: budget === 'micro' ? '4-6 semaines' : budget === 'petit' ? '2-3 mois' : '3-6 mois',
        score_faisabilite: 7
      },
      {
        titre: `Solution Digitale ${secteur.nom}`,
        description: `Approche numérique pour le secteur ${secteur.nom} avec un budget ${budget}, tirant parti des opportunités identifiées.`,
        investissement_initial: budgetInfo[budget].investment,
        revenus_mensuels: budgetInfo[budget].revenue,
        actions_immediates: [
          "Développement MVP",
          "Tests utilisateurs",
          "Stratégie marketing digital"
        ],
        ressources_necessaires: [
          "Compétences techniques",
          "Plateforme digitale",
          "Marketing en ligne"
        ],
        delai_lancement: budget === 'micro' ? '6-8 semaines' : budget === 'petit' ? '3-4 mois' : '4-8 mois',
        score_faisabilite: 8
      },
      {
        titre: `Service Local ${secteur.nom}`,
        description: `Service de proximité dans le secteur ${secteur.nom}, optimisé pour le budget ${budget} et les besoins locaux gabonais.`,
        investissement_initial: budgetInfo[budget].investment,
        revenus_mensuels: budgetInfo[budget].revenue,
        actions_immediates: [
          "Analyse des besoins locaux",
          "Formation équipe",
          "Lancement pilote"
        ],
        ressources_necessaires: [
          "Personnel qualifié",
          "Équipements de base",
          "Local commercial"
        ],
        delai_lancement: budget === 'micro' ? '3-4 semaines' : budget === 'petit' ? '1-2 mois' : '2-4 mois',
        score_faisabilite: 9
      }
    ]
  }
}
