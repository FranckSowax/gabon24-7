const { createClient } = require('@supabase/supabase-js');

// Environment variables
const supabaseUrl = process.env.SUPABASE_URL;
const supabaseServiceKey = process.env.SUPABASE_SERVICE_ROLE_KEY;
const openaiApiKey = process.env.OPENAI_API_KEY;

exports.handler = async (event, context) => {
  // CORS headers
  const headers = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'Content-Type, Authorization',
    'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
    'Content-Type': 'application/json'
  };

  if (event.httpMethod === 'OPTIONS') {
    return { statusCode: 200, headers };
  }

  if (event.httpMethod !== 'POST') {
    return {
      statusCode: 405,
      headers,
      body: JSON.stringify({ error: 'Method not allowed' })
    };
  }

  try {
    const { articleIds } = JSON.parse(event.body || '{}');
    
    // Initialize Supabase
    const supabase = createClient(supabaseUrl, supabaseServiceKey);

    let articlesToProcess = [];

    if (articleIds && Array.isArray(articleIds)) {
      // Process specific articles
      const { data: articles, error } = await supabase
        .from('articles')
        .select('*')
        .in('id', articleIds)
        .eq('is_published', true);

      if (error) throw error;
      articlesToProcess = articles || [];
    } else {
      // Process recent articles (last 2 hours)
      const twoHoursAgo = new Date(Date.now() - 2 * 60 * 60 * 1000).toISOString();
      
      const { data: articles, error } = await supabase
        .from('articles')
        .select('*')
        .eq('is_published', true)
        .gte('created_at', twoHoursAgo)
        .order('created_at', { ascending: false })
        .limit(50);

      if (error) throw error;
      articlesToProcess = articles || [];
    }

    if (articlesToProcess.length === 0) {
      return {
        statusCode: 200,
        headers,
        body: JSON.stringify({
          success: true,
          processed: 0,
          matches: 0,
          message: 'No articles to process'
        })
      };
    }

    // Get all active alerts
    const { data: alerts, error: alertsError } = await supabase
      .from('user_alerts')
      .select('*')
      .eq('is_active', true);

    if (alertsError) throw alertsError;

    if (!alerts || alerts.length === 0) {
      return {
        statusCode: 200,
        headers,
        body: JSON.stringify({
          success: true,
          processed: articlesToProcess.length,
          matches: 0,
          message: 'No active alerts found'
        })
      };
    }

    let totalMatches = 0;
    const processedArticles = [];

    // Process each article against all alerts
    for (const article of articlesToProcess) {
      const articleMatches = await processArticleMatching(supabase, article, alerts);
      totalMatches += articleMatches.length;
      processedArticles.push({
        articleId: article.id,
        title: article.title,
        matches: articleMatches.length
      });

      // Store matches in database
      if (articleMatches.length > 0) {
        const { error: matchError } = await supabase
          .from('alert_matches')
          .insert(articleMatches);

        if (matchError) {
          console.error('Error storing matches:', matchError);
        }
      }
    }

    // Update last_processed_at for matched alerts
    const matchedAlertIds = [...new Set(
      processedArticles.flatMap(article => 
        alerts.filter(alert => 
          processedArticles.some(pa => pa.articleId === article.id && pa.matches > 0)
        ).map(alert => alert.id)
      )
    )];

    if (matchedAlertIds.length > 0) {
      await supabase
        .from('user_alerts')
        .update({ last_processed_at: new Date().toISOString() })
        .in('id', matchedAlertIds);
    }

    return {
      statusCode: 200,
      headers,
      body: JSON.stringify({
        success: true,
        processed: articlesToProcess.length,
        matches: totalMatches,
        articles: processedArticles,
        message: `Processed ${articlesToProcess.length} articles, found ${totalMatches} matches`
      })
    };

  } catch (error) {
    console.error('Error in process-alert-matching function:', error);
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({ 
        error: 'Internal server error',
        message: error.message 
      })
    };
  }
};

async function processArticleMatching(supabase, article, alerts) {
  const matches = [];

  for (const alert of alerts) {
    const matchResult = await matchArticleWithAlert(article, alert);
    
    if (matchResult.isMatch) {
      // Check if match already exists
      const { data: existingMatch } = await supabase
        .from('alert_matches')
        .select('id')
        .eq('alert_id', alert.id)
        .eq('article_id', article.id)
        .single();

      if (!existingMatch) {
        matches.push({
          alert_id: alert.id,
          article_id: article.id,
          matched_keywords: matchResult.matchedKeywords,
          confidence_score: matchResult.confidence,
          matching_type: matchResult.type,
          created_at: new Date().toISOString()
        });
      }
    }
  }

  return matches;
}

async function matchArticleWithAlert(article, alert) {
  const articleContent = `${article.title} ${article.description || ''} ${article.content || ''}`.toLowerCase();
  
  // Combine all keywords for matching
  const allKeywords = [
    ...(alert.keywords || []),
    ...(alert.extracted_keywords || []),
    ...(alert.semantic_keywords || [])
  ].map(kw => kw.toLowerCase());

  // Remove duplicates
  const uniqueKeywords = [...new Set(allKeywords)];
  
  // Check category matching
  let categoryMatch = false;
  if (alert.categories && alert.categories.length > 0 && article.category) {
    categoryMatch = alert.categories.some(cat => 
      cat.toLowerCase() === article.category.toLowerCase()
    );
  }

  // Check source matching
  let sourceMatch = false;
  if (alert.sources && alert.sources.length > 0 && article.source) {
    sourceMatch = alert.sources.some(source => 
      article.source.toLowerCase().includes(source.toLowerCase())
    );
  }

  // Exact keyword matching
  const exactMatches = uniqueKeywords.filter(keyword => 
    articleContent.includes(keyword)
  );

  // Calculate base confidence
  let confidence = 0;
  let matchType = 'none';
  let matchedKeywords = [];

  if (exactMatches.length > 0) {
    confidence = Math.min(0.9, (exactMatches.length / uniqueKeywords.length) * 0.8 + 0.1);
    matchType = 'exact';
    matchedKeywords = exactMatches;

    // Boost confidence for category match
    if (categoryMatch) {
      confidence = Math.min(0.95, confidence + 0.1);
    }

    // Boost confidence for source match
    if (sourceMatch) {
      confidence = Math.min(0.98, confidence + 0.05);
    }
  }

  // Enhanced semantic matching with AI (if available and needed)
  if (confidence < 0.6 && openaiApiKey && uniqueKeywords.length > 0) {
    const aiMatch = await performAIMatching(articleContent, uniqueKeywords, alert);
    if (aiMatch.confidence > confidence) {
      confidence = aiMatch.confidence;
      matchType = 'ai_enhanced';
      matchedKeywords = aiMatch.keywords;
    }
  }

  // Minimum confidence threshold
  const isMatch = confidence >= 0.4;

  return {
    isMatch,
    confidence: Math.round(confidence * 100) / 100,
    type: matchType,
    matchedKeywords: matchedKeywords.slice(0, 10) // Limit to 10 keywords
  };
}

async function performAIMatching(articleContent, keywords, alert) {
  if (!openaiApiKey) {
    return { confidence: 0, keywords: [] };
  }

  try {
    const prompt = `
Analyse si cet article est pertinent pour une alerte de surveillance avec ces mots-clés :

Article: "${articleContent.substring(0, 500)}..."
Mots-clés de l'alerte: ${keywords.join(', ')}
Nom de l'alerte: ${alert.name}

Évalue la pertinence sur une échelle de 0 à 1 et identifie les concepts correspondants.

Réponds au format JSON:
{
  "confidence": 0.X,
  "matched_concepts": ["concept1", "concept2"],
  "reasoning": "explication courte"
}
`;

    const response = await fetch('https://api.openai.com/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${openaiApiKey}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        model: 'gpt-3.5-turbo',
        messages: [
          {
            role: 'system', 
            content: 'Tu es un expert en analyse de contenu qui évalue la pertinence d\'articles pour des alertes de surveillance média.'
          },
          { role: 'user', content: prompt }
        ],
        max_tokens: 150,
        temperature: 0.2
      })
    });

    if (!response.ok) {
      throw new Error(`OpenAI API error: ${response.status}`);
    }

    const data = await response.json();
    const aiResponse = data.choices[0]?.message?.content?.trim() || '{}';
    
    try {
      const parsed = JSON.parse(aiResponse);
      return {
        confidence: Math.min(0.9, Math.max(0, parsed.confidence || 0)),
        keywords: parsed.matched_concepts || []
      };
    } catch (parseError) {
      console.error('Error parsing AI response:', parseError);
      return { confidence: 0, keywords: [] };
    }

  } catch (error) {
    console.error('Error in AI matching:', error);
    return { confidence: 0, keywords: [] };
  }
}
