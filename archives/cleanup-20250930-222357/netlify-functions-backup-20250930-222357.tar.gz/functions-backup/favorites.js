const { createClient } = require('@supabase/supabase-js')

const supabaseUrl = process.env.SUPABASE_URL
const supabaseServiceKey = process.env.SUPABASE_SERVICE_ROLE_KEY

if (!supabaseUrl || !supabaseServiceKey) {
  console.error('❌ Variables d\'environnement Supabase manquantes')
}

const supabase = createClient(supabaseUrl, supabaseServiceKey)

exports.handler = async (event, context) => {
  // Headers CORS
  const headers = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'Content-Type, Authorization',
    'Access-Control-Allow-Methods': 'GET, POST, DELETE, OPTIONS',
    'Content-Type': 'application/json'
  }

  // Gérer les requêtes OPTIONS (preflight)
  if (event.httpMethod === 'OPTIONS') {
    return {
      statusCode: 200,
      headers,
      body: ''
    }
  }

  try {
    // Vérifier l'authentification
    const authHeader = event.headers.authorization
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      return {
        statusCode: 401,
        headers,
        body: JSON.stringify({ error: 'Token d\'authentification requis' })
      }
    }

    const token = authHeader.replace('Bearer ', '')
    
    // Vérifier le token avec Supabase Auth
    const { data: { user }, error: authError } = await supabase.auth.getUser(token)
    
    if (authError || !user) {
      return {
        statusCode: 401,
        headers,
        body: JSON.stringify({ error: 'Token invalide ou expiré' })
      }
    }

    const userId = user.id
    const method = event.httpMethod
    const body = event.body ? JSON.parse(event.body) : {}

    switch (method) {
      case 'GET':
        // Récupérer les favoris de l'utilisateur
        const { data: favorites, error: getFavError } = await supabase
          .from('user_favorites')
          .select('*')
          .eq('user_id', userId)
          .order('created_at', { ascending: false })

        if (getFavError) {
          console.error('Erreur récupération favoris:', getFavError)
          return {
            statusCode: 500,
            headers,
            body: JSON.stringify({ error: 'Erreur lors de la récupération des favoris' })
          }
        }

        return {
          statusCode: 200,
          headers,
          body: JSON.stringify({ favorites })
        }

      case 'POST':
        // Ajouter un article aux favoris
        const { articleId, articleTitle, articleUrl, articleSource, articleImageUrl } = body

        if (!articleId || !articleTitle) {
          return {
            statusCode: 400,
            headers,
            body: JSON.stringify({ error: 'articleId et articleTitle sont requis' })
          }
        }

        // Vérifier si l'article n'est pas déjà en favoris
        const { data: existingFav } = await supabase
          .from('user_favorites')
          .select('id')
          .eq('user_id', userId)
          .eq('article_id', articleId)
          .single()

        if (existingFav) {
          return {
            statusCode: 409,
            headers,
            body: JSON.stringify({ error: 'Article déjà en favoris' })
          }
        }

        // Ajouter aux favoris
        const { data: newFavorite, error: addError } = await supabase
          .from('user_favorites')
          .insert({
            user_id: userId,
            article_id: articleId,
            article_title: articleTitle,
            article_url: articleUrl,
            article_source: articleSource,
            article_image_url: articleImageUrl
          })
          .select()
          .single()

        if (addError) {
          console.error('Erreur ajout favori:', addError)
          return {
            statusCode: 500,
            headers,
            body: JSON.stringify({ error: 'Erreur lors de l\'ajout aux favoris' })
          }
        }

        return {
          statusCode: 201,
          headers,
          body: JSON.stringify({ favorite: newFavorite, message: 'Article ajouté aux favoris' })
        }

      case 'DELETE':
        // Supprimer un article des favoris
        const { articleId: deleteArticleId } = body

        if (!deleteArticleId) {
          return {
            statusCode: 400,
            headers,
            body: JSON.stringify({ error: 'articleId requis' })
          }
        }

        const { error: deleteError } = await supabase
          .from('user_favorites')
          .delete()
          .eq('user_id', userId)
          .eq('article_id', deleteArticleId)

        if (deleteError) {
          console.error('Erreur suppression favori:', deleteError)
          return {
            statusCode: 500,
            headers,
            body: JSON.stringify({ error: 'Erreur lors de la suppression du favori' })
          }
        }

        return {
          statusCode: 200,
          headers,
          body: JSON.stringify({ message: 'Article supprimé des favoris' })
        }

      default:
        return {
          statusCode: 405,
          headers,
          body: JSON.stringify({ error: 'Méthode non autorisée' })
        }
    }

  } catch (error) {
    console.error('Erreur fonction favorites:', error)
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({ error: 'Erreur interne du serveur' })
    }
  }
}
