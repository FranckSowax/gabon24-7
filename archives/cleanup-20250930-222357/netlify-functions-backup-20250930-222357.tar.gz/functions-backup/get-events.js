const { createClient } = require('@supabase/supabase-js');

exports.handler = async (event, context) => {
  // Configuration Supabase
  const supabaseUrl = process.env.SUPABASE_URL;
  const supabaseServiceKey = process.env.SUPABASE_SERVICE_ROLE_KEY;

  if (!supabaseUrl || !supabaseServiceKey) {
    console.error('❌ Variables d\'environnement manquantes');
    return {
      statusCode: 500,
      headers: {
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Headers': 'Content-Type',
        'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        success: false,
        error: 'Configuration manquante'
      })
    };
  }

  const supabase = createClient(supabaseUrl, supabaseServiceKey);
  const headers = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'Content-Type',
    'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
    'Content-Type': 'application/json'
  };

  if (event.httpMethod === 'OPTIONS') {
    return { statusCode: 200, headers, body: '' };
  }

  try {
    // Récupérer les événements depuis les articles avec catégorie 'événements'
    console.log('🔍 Recherche des événements...');
    
    const { data: events, error } = await supabase
      .from('articles')
      .select(`
        id,
        title,
        summary,
        image_urls,
        url,
        published_at
      `)
      .eq('category', 'événements')
      .order('published_at', { ascending: false })
      .limit(10);
    
    console.log('📊 Résultats de la requête:', { 
      count: events?.length || 0, 
      error: error?.message || 'aucune erreur',
      sampleImageUrls: events?.slice(0, 3).map(e => ({ title: e.title, image_urls: e.image_urls }))
    });

    if (error) {
      console.error('❌ Erreur Supabase:', error);
      return {
        statusCode: 500,
        headers,
        body: JSON.stringify({
          success: false,
          error: 'Erreur lors de la récupération des événements'
        })
      };
    }

    // Transformer les données pour correspondre au format attendu par le frontend
    const transformedEvents = events.map(event => {
      // Extraire la première image depuis le tableau image_urls
      let imageUrl = null;
      if (event.image_urls && Array.isArray(event.image_urls) && event.image_urls.length > 0) {
        imageUrl = event.image_urls[0];
      }
      
      return {
        id: event.id,
        title: event.title,
        description: event.summary || '',
        image_url: imageUrl,
        url: event.url,
        published_at: event.published_at,
        location: null,
        date: event.published_at
      };
    });

    return {
      statusCode: 200,
      headers,
      body: JSON.stringify({
        success: true,
        events: transformedEvents,
        total: transformedEvents.length,
        timestamp: new Date().toISOString()
      })
    };

  } catch (error) {
    console.error('❌ Erreur handler get-events:', error);
    
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({
        success: false,
        error: 'Erreur lors de la récupération des événements',
        message: error.message,
        events: []
      })
    };
  }
};

// Fonction pour extraire la localisation depuis le contenu
function extractLocationFromContent(content) {
  if (!content) return null;
  
  // Rechercher des patterns de localisation
  const locationPatterns = [
    /(?:à|au|aux|chez)\s+([^.,\n]+)/i,
    /(?:lieu|adresse|location):\s*([^.,\n]+)/i,
    /(?:Libreville|Port-Gentil|Franceville|Oyem|Moanda|Lambaréné)/i
  ];
  
  for (const pattern of locationPatterns) {
    const match = content.match(pattern);
    if (match) {
      return match[1] ? match[1].trim() : match[0].trim();
    }
  }
  
  return null;
}
