const fetch = require('node-fetch');

exports.handler = async (event, context) => {
  const headers = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'Content-Type',
    'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
  };

  if (event.httpMethod === 'OPTIONS') {
    return { statusCode: 200, headers, body: '' };
  }

  const openaiApiKey = process.env.OPENAI_API_KEY;
  
  if (!openaiApiKey) {
    return {
      statusCode: 400,
      headers,
      body: JSON.stringify({ error: 'OpenAI API key not configured' })
    };
  }

  // Liste des modèles à tester
  const modelsToTest = [
    'gpt-3.5-turbo',
    'gpt-4o-mini',
    'gpt-4o',
    'gpt-4-turbo',
    'gpt-4',
    'gpt-5',
    'gpt-5-mini',
    'gpt-5-nano',
    'gpt-4o-nano',
    'o1-preview',
    'o1-mini'
  ];

  const results = {
    available: [],
    unavailable: [],
    errors: [],
    timestamp: new Date().toISOString()
  };

  console.log('🧪 Testing OpenAI model availability...');

  for (const model of modelsToTest) {
    try {
      console.log(`🔍 Testing model: ${model}`);
      
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), 10000); // 10 second timeout
      
      const response = await fetch('https://api.openai.com/v1/chat/completions', {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${openaiApiKey}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          model: model,
          messages: [
            {
              role: 'user',
              content: 'Test'
            }
          ],
          max_tokens: 5,
          temperature: 0.1
        }),
        signal: controller.signal
      });
      
      clearTimeout(timeoutId);

      if (response.ok) {
        console.log(`✅ ${model}: AVAILABLE`);
        results.available.push({
          model,
          status: 'available',
          statusCode: response.status
        });
      } else {
        const errorData = await response.json().catch(() => ({}));
        console.log(`❌ ${model}: UNAVAILABLE - ${response.status} - ${errorData.error?.message || 'Unknown error'}`);
        
        results.unavailable.push({
          model,
          status: 'unavailable',
          statusCode: response.status,
          error: errorData.error?.message || 'Unknown error',
          errorType: errorData.error?.type
        });
      }
      
    } catch (error) {
      console.log(`💥 ${model}: ERROR - ${error.message}`);
      results.errors.push({
        model,
        status: 'error',
        error: error.message
      });
    }
    
    // Petit délai entre les tests pour éviter rate limiting
    await new Promise(resolve => setTimeout(resolve, 500));
  }

  // Essayer aussi de lister les modèles disponibles via l'API models
  try {
    console.log('📋 Fetching available models list...');
    const modelsResponse = await fetch('https://api.openai.com/v1/models', {
      headers: {
        'Authorization': `Bearer ${openaiApiKey}`,
      }
    });
    
    if (modelsResponse.ok) {
      const modelsData = await modelsResponse.json();
      results.allModels = modelsData.data.map(model => ({
        id: model.id,
        created: model.created,
        owned_by: model.owned_by
      })).sort((a, b) => a.id.localeCompare(b.id));
      
      console.log(`📊 Found ${results.allModels.length} total models`);
    }
  } catch (error) {
    console.log(`❌ Error fetching models list: ${error.message}`);
    results.modelsListError = error.message;
  }

  console.log(`✅ Test completed: ${results.available.length} available, ${results.unavailable.length} unavailable, ${results.errors.length} errors`);

  return {
    statusCode: 200,
    headers,
    body: JSON.stringify(results, null, 2)
  };
};
