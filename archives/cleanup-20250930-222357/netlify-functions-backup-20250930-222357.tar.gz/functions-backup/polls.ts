import { createClient } from '@supabase/supabase-js'

const supabaseUrl = process.env.SUPABASE_URL!
const supabaseKey = process.env.SUPABASE_SERVICE_ROLE_KEY!
const supabase = createClient(supabaseUrl, supabaseKey)

export const handler = async (event: any, context: any) => {
  // Enable CORS
  const headers = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'Content-Type',
    'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
    'Content-Type': 'application/json',
  }

  if (event.httpMethod === 'OPTIONS') {
    return { statusCode: 200, headers, body: '' }
  }

  if (event.httpMethod === 'GET') {
    try {
      // Get today's polls
      const today = new Date()
      const startOfDay = new Date(today.getFullYear(), today.getMonth(), today.getDate())
      const endOfDay = new Date(today.getFullYear(), today.getMonth(), today.getDate() + 1)
      
      const { data: polls, error } = await supabase
        .from('polls')
        .select('*')
        .gte('created_at', startOfDay.toISOString())
        .lt('created_at', endOfDay.toISOString())
        .order('created_at', { ascending: false })
        .limit(5)
      
      if (error) {
        console.error('Error fetching polls:', error)
        return {
          statusCode: 500,
          headers,
          body: JSON.stringify({ success: false, error: error.message })
        }
      }

      // If no polls exist, create a default one
      if (!polls || polls.length === 0) {
        const defaultQuestion = "Quelle mesure pourrait le mieux lutter contre le chômage des jeunes au Gabon ?"
        
        const { data: newPoll, error: createError } = await supabase
          .from('polls')
          .insert({
            question: defaultQuestion,
            poll_type: 'mcq',
            options: ['Formation professionnelle renforcée', 'Création d\'entreprises facilitée', 'Secteur numérique et tech'],
            is_active: true,
            expires_at: new Date(Date.now() + 24 * 60 * 60 * 1000).toISOString()
          })
          .select()
          .single()
        
        if (createError) {
          console.error('Error creating default poll:', createError)
          return {
            statusCode: 500,
            headers,
            body: JSON.stringify({ success: false, error: createError.message })
          }
        }
        
        return {
          statusCode: 200,
          headers,
          body: JSON.stringify({ success: true, polls: [newPoll] })
        }
      }

      return {
        statusCode: 200,
        headers,
        body: JSON.stringify({ success: true, polls })
      }
    } catch (error) {
      console.error('Error:', error)
      return {
        statusCode: 500,
        headers,
        body: JSON.stringify({ success: false, error: 'Internal server error' })
      }
    }
  }

  return {
    statusCode: 405,
    headers,
    body: JSON.stringify({ success: false, error: 'Method not allowed' })
  }
}
