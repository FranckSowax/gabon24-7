const { createClient } = require('@supabase/supabase-js')

const supabaseUrl = process.env.SUPABASE_URL
const supabaseKey = process.env.SUPABASE_SERVICE_ROLE_KEY
const supabase = createClient(supabaseUrl, supabaseKey)

exports.handler = async (event, context) => {
  // Set CORS headers
  const headers = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'Content-Type',
    'Access-Control-Allow-Methods': 'GET, POST, OPTIONS'
  };

  // Handle preflight requests
  if (event.httpMethod === 'OPTIONS') {
    return {
      statusCode: 200,
      headers,
      body: ''
    };
  }

  // Allow both GET and POST methods
  if (event.httpMethod !== 'POST' && event.httpMethod !== 'GET') {
    return {
      statusCode: 405,
      headers,
      body: JSON.stringify({ error: 'Method not allowed' })
    };
  }

  try {
    console.log('🎉 Création des événements de démonstration...')

      // Supprimer les anciens événements de démo
      await supabase
        .from('events')
        .delete()
        .like('title', '%Gabon 24/7%')

      // Créer des événements réalistes
      const now = new Date()
      const tomorrow = new Date(now.getTime() + 24 * 60 * 60 * 1000)
      const nextWeek = new Date(now.getTime() + 7 * 24 * 60 * 60 * 1000)
      const nextMonth = new Date(now.getTime() + 30 * 24 * 60 * 60 * 1000)

      const events = [
        {
          title: 'Sommet de la CEEAC à Malabo',
          description: 'Réunion extraordinaire des chefs d\'État de la Communauté économique des États de l\'Afrique centrale pour discuter des enjeux régionaux.',
          location: 'Malabo, Guinée Équatoriale',
          event_date: tomorrow.toISOString(),
          image_url: '/images/369309819_1696052364152294_5673051963922538250_n.jpg',
          category: 'Politique',
          is_featured: true
        },
        {
          title: 'Forum Économique Gabon-France',
          description: 'Rencontre d\'affaires entre entrepreneurs gabonais et français pour renforcer les partenariats économiques.',
          location: 'Libreville, Gabon',
          event_date: nextWeek.toISOString(),
          image_url: '/images/MOOV-PLAY-FACEBOOK-SITE-GT•1903X574.jpg',
          category: 'Économie',
          is_featured: true
        },
        {
          title: 'Festival de Musique Traditionnelle',
          description: 'Célébration de la richesse culturelle gabonaise avec des artistes locaux et internationaux.',
          location: 'Port-Gentil, Gabon',
          event_date: nextMonth.toISOString(),
          image_url: '/images/369309819_1696052364152294_5673051963922538250_n.jpg',
          category: 'Culture',
          is_featured: false
        },
        {
          title: 'Conférence sur l\'Environnement',
          description: 'Débats sur la préservation de la forêt équatoriale et le développement durable au Gabon.',
          location: 'Franceville, Gabon',
          event_date: new Date(now.getTime() + 14 * 24 * 60 * 60 * 1000).toISOString(),
          image_url: '/images/369309819_1696052364152294_5673051963922538250_n.jpg',
          category: 'Environnement',
          is_featured: true
        }
      ]

      const { data: insertedEvents, error } = await supabase
        .from('events')
        .insert(events)
        .select()

      if (error) {
        throw error
      }

      console.log(`✅ ${insertedEvents.length} événements créés avec succès`)

      return {
        statusCode: 200,
        headers,
        body: JSON.stringify({
          success: true,
          message: `${insertedEvents.length} événements créés avec succès`,
          events: insertedEvents
        })
      }
    } catch (error) {
      console.error('❌ Erreur création événements:', error)
      return {
        statusCode: 500,
        headers,
        body: JSON.stringify({
          success: false,
          error: error instanceof Error ? error.message : 'Unknown error occurred'
        })
      }
    }
  } catch (error) {
    console.error('❌ Erreur lors de la création des événements:', error)
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({
        success: false,
        error: error instanceof Error ? error.message : 'Unknown error occurred'
      })
    }
  }
}
