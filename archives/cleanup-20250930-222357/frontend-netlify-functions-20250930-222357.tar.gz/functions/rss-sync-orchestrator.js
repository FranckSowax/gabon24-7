const { createClient } = require('@supabase/supabase-js');

// Configuration Supabase
const supabaseUrl = process.env.SUPABASE_URL;
const supabaseServiceKey = process.env.SUPABASE_SERVICE_ROLE_KEY;

if (!supabaseUrl || !supabaseServiceKey) {
  console.error('❌ Variables d\'environnement manquantes');
}

const supabase = createClient(supabaseUrl, supabaseServiceKey);

// Fonction pour déclencher un batch de synchronisation
async function triggerBatch(offset, batchSize = 2) {
  try {
    const response = await fetch(`https://gabon24-7.netlify.app/.netlify/functions/rss-sync-batch?offset=${offset}&batch_size=${batchSize}`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({})
    });
    
    if (!response.ok) {
      throw new Error(`HTTP ${response.status}: ${response.statusText}`);
    }
    
    return await response.json();
  } catch (error) {
    console.error(`❌ Erreur batch offset ${offset}:`, error);
    return { success: false, error: error.message };
  }
}

// Orchestrateur principal
exports.handler = async (event, context) => {
  context.callbackWaitsForEmptyEventLoop = false;
  
  const headers = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'Content-Type',
    'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
    'Content-Type': 'application/json'
  };

  if (event.httpMethod === 'OPTIONS') {
    return { statusCode: 200, headers, body: '' };
  }

  try {
    console.log('🚀 Orchestrateur RSS démarré - traitement de TOUS les flux');
    
    // Compter le nombre total de flux actifs
    const { count: totalFeeds } = await supabase
      .from('rss_feeds')
      .select('*', { count: 'exact', head: true })
      .eq('status', 'active');
    
    console.log(`📊 Total de ${totalFeeds} flux RSS actifs à traiter`);
    
    const batchSize = 2; // 2 flux par batch pour éviter les timeouts
    const batches = Math.ceil(totalFeeds / batchSize);
    
    let totalNewArticles = 0;
    const batchResults = [];
    
    // Traiter tous les batches séquentiellement
    for (let i = 0; i < batches; i++) {
      const offset = i * batchSize;
      console.log(`🔄 Traitement batch ${i + 1}/${batches} (offset: ${offset})`);
      
      const batchResult = await triggerBatch(offset, batchSize);
      
      if (batchResult.success) {
        totalNewArticles += batchResult.totalNewArticles || 0;
        batchResults.push({
          batchNumber: i + 1,
          offset: offset,
          newArticles: batchResult.totalNewArticles || 0,
          processed: batchResult.batch?.processed || 0,
          status: 'success'
        });
        console.log(`✅ Batch ${i + 1} terminé: ${batchResult.totalNewArticles || 0} nouveaux articles`);
      } else {
        batchResults.push({
          batchNumber: i + 1,
          offset: offset,
          newArticles: 0,
          processed: 0,
          status: 'error',
          error: batchResult.error
        });
        console.error(`❌ Batch ${i + 1} échoué: ${batchResult.error}`);
      }
      
      // Petite pause entre les batches
      if (i < batches - 1) {
        await new Promise(resolve => setTimeout(resolve, 2000));
      }
    }
    
    return {
      statusCode: 200,
      headers,
      body: JSON.stringify({
        success: true,
        message: `Synchronisation complète terminée: ${totalNewArticles} nouveaux articles`,
        summary: {
          totalFeeds: totalFeeds,
          totalBatches: batches,
          batchSize: batchSize,
          totalNewArticles: totalNewArticles,
          successfulBatches: batchResults.filter(b => b.status === 'success').length,
          failedBatches: batchResults.filter(b => b.status === 'error').length
        },
        batchResults: batchResults,
        timestamp: new Date().toISOString()
      })
    };
    
  } catch (error) {
    console.error('❌ Erreur orchestrateur RSS:', error);
    
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({
        success: false,
        error: 'Erreur orchestrateur RSS',
        message: error.message
      })
    };
  }
};
