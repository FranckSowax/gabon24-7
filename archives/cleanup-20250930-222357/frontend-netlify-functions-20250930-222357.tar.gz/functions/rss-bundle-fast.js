const Parser = require('rss-parser');
const { createClient } = require('@supabase/supabase-js');

// Configuration
const supabaseUrl = process.env.SUPABASE_URL;
const supabaseKey = process.env.SUPABASE_SERVICE_ROLE_KEY;

const parser = new Parser();
const supabase = createClient(supabaseUrl, supabaseKey);

// Bundle RSS.app URL unique
const BUNDLE_URL = 'https://rss.app/feeds/_SntJgjZXkqIWrDHq.xml';

// Fonction pour extraire le domaine et déterminer la source
function extractSourceFromLink(link) {
  try {
    const url = new URL(link);
    const domain = url.hostname.replace('www.', '');
    
    // Map des domaines vers noms de sources
    const sourceMap = {
      'gabonreview.com': 'Gabon Review',
      'infogabon.ga': 'Info Gabon',
      'lalibreville.com': 'La Libreville',
      'gabon24.com': 'Gabon 24',
      'union.sonapresse.com': 'L\'Union',
      'gabon-eco.com': 'Gabon Eco',
      'actualite-gabon.com': 'Actualité Gabon',
      'sciencesetavenir.fr': 'Sciences et Avenir',
      'directinfosgabon.com': 'Direct Infos Gabon',
      'gabonactu.com': 'Gabon Actu',
      'africaintelligence.fr': 'Africa Intelligence',
      'gabon24.tv': 'Gabon 24 TV',
      'focusgroupemedia.com': 'Focus Groupe Media',
      'gabonmediatime.com': 'Gabon Media Time',
      'facebook.com': 'Facebook',
      'echosdeleco.com': 'Echos de l\'Eco',
      'agpgabon.ga': 'AGP Gabon'
    };
    
    return sourceMap[domain] || domain;
  } catch (error) {
    return 'Source inconnue';
  }
}

// Fonction pour traiter l'image avec proxy si nécessaire
function processImageUrl(imageUrl, link) {
  if (!imageUrl) return null;
  
  try {
    const articleUrl = new URL(link);
    const imageUrlObj = new URL(imageUrl);
    
    // Si l'image vient d'Info Gabon, utiliser le proxy
    if (articleUrl.hostname.includes('infogabon') && imageUrlObj.hostname.includes('infogabon')) {
      return `/.netlify/functions/image-proxy?url=${encodeURIComponent(imageUrl)}`;
    }
    
    return imageUrl;
  } catch (error) {
    console.log('⚠️ URL image invalide:', imageUrl);
    return null;
  }
}

exports.handler = async (event, context) => {
  const startTime = Date.now();
  
  try {
    console.log('⚡ Synchronisation RSS Bundle RAPIDE démarrée (sans IA)');
    console.log('📡 Bundle URL:', BUNDLE_URL);

    // Étape 1: Parser le bundle RSS.app
    const feed = await parser.parseURL(BUNDLE_URL);
    console.log(`📄 Bundle parsé: ${feed.items.length} articles trouvés`);

    let newArticles = 0;
    let processedArticles = 0;
    const errors = [];
    
    // Traiter tous les articles rapidement (pas de limite car pas d'IA)
    console.log(`⚡ Traitement rapide de ${feed.items.length} articles`);

    // Étape 2: Traiter chaque article du bundle RAPIDEMENT
    for (const item of feed.items) {
      try {
        processedArticles++;
        
        // Vérifier si l'article existe déjà (requête rapide)
        const { data: existingArticle } = await supabase
          .from('articles')
          .select('id')
          .eq('link', item.link)
          .single();

        if (existingArticle) {
          continue; // Article déjà existant
        }

        // Extraire les données de l'article RAPIDEMENT
        const title = item.title || 'Titre non disponible';
        const content = item.contentSnippet || item.content || item.summary || '';
        const pubDate = item.pubDate ? new Date(item.pubDate).toISOString() : new Date().toISOString();
        const source = extractSourceFromLink(item.link);
        const imageUrl = processImageUrl(item.enclosure?.url || item.image?.url, item.link);

        // Insérer l'article dans Supabase
        const { data: insertedArticle, error: insertError } = await supabase
          .from('articles')
          .insert({
            title: item.title,
            content: item.contentSnippet || item.content || '',
            link: item.link,
            published_at: pubDate,
            source: source,
            image_url: imageUrl,
            summary: item.contentSnippet || item.content?.substring(0, 300) || ''
          })
          .select('id')
          .single();

        if (insertError) {
          console.error('❌ Erreur insertion article:', insertError.message);
          errors.push(`Erreur insertion: ${insertError.message}`);
        } else {
          newArticles++;
          console.log(`⚡ Article ajouté: ${title.substring(0, 50)}...`);
          
          // Ajouter à la queue pour résumé IA différé
          if (insertedArticle?.id) {
            try {
              await supabase
                .from('pending_ai_summaries')
                .insert({
                  article_id: insertedArticle.id,
                  priority: 1, // Priorité normale
                  status: 'pending',
                  created_at: new Date().toISOString()
                });
            } catch (queueError) {
              console.warn('⚠️ Erreur ajout queue IA:', queueError.message);
            }
          }
        }

        // Pas de délai - traitement ultra rapide
        
        // Arrêt précoce si on approche du timeout Netlify (après 15 secondes)
        const elapsed = Date.now() - startTime;
        if (elapsed > 15000) { // 15 secondes max pour être sûr
          console.log(`⏰ Arrêt précoce après ${elapsed}ms pour éviter timeout`);
          break;
        }

      } catch (articleError) {
        console.error('❌ Erreur traitement article:', articleError.message);
        errors.push(`Erreur article: ${articleError.message}`);
      }
    }

    // Étape 3: Log de synchronisation
    const duration = Date.now() - startTime;
    const { error: logError } = await supabase
      .from('sync_logs')
      .insert({
        sync_type: 'bundle-fast',
        feeds_processed: 1,
        articles_extracted: newArticles,
        success_count: 1,
        error_count: errors.length,
        errors: errors,
        duration_ms: duration,
        ai_summaries_generated: 0, // Pas d'IA dans la version rapide
        created_at: new Date().toISOString(),
      });

    if (logError) {
      console.error('❌ Erreur log:', logError.message);
    }

    const result = {
      success: true,
      bundle_url: BUNDLE_URL,
      total_items: feed.items.length,
      new_articles: newArticles,
      processed_articles: processedArticles,
      ai_summaries_generated: 0,
      duration_ms: duration,
      errors: errors,
      mode: 'fast',
      timestamp: new Date().toISOString()
    };

    console.log('⚡ Synchronisation RSS Bundle RAPIDE terminée:', result);

    return {
      statusCode: 200,
      headers: {
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
        'Access-Control-Allow-Headers': 'Content-Type',
      },
      body: JSON.stringify(result)
    };

  } catch (error) {
    console.error('❌ Erreur critique RSS Bundle RAPIDE:', error);
    
    const errorResult = {
      success: false,
      error: error.message,
      duration_ms: Date.now() - startTime,
      mode: 'fast',
      timestamp: new Date().toISOString()
    };

    return {
      statusCode: 500,
      headers: {
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*',
      },
      body: JSON.stringify(errorResult)
    };
  }
};
