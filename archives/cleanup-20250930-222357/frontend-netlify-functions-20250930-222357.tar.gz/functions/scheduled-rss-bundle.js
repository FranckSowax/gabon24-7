// Fonction programmée pour synchronisation RSS Bundle
const bundleSyncFunction = require('./rss-sync-bundle');

exports.handler = async (event, context) => {
  console.log('📅 Synchronisation RSS Bundle programmée démarrée');
  
  // Simuler un événement POST pour la fonction bundle
  const simulatedEvent = {
    httpMethod: 'POST',
    headers: {
      'Content-Type': 'application/json'
    }
  };
  
  try {
    const result = await bundleSyncFunction.handler(simulatedEvent, context);
    const parsedResult = JSON.parse(result.body);
    
    console.log('✅ Synchronisation RSS Bundle terminée:', parsedResult);
    return result;
  } catch (error) {
    console.error('❌ Erreur synchronisation RSS Bundle:', error);
    return {
      statusCode: 500,
      headers: {
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*',
      },
      body: JSON.stringify({
        success: false,
        error: error.message,
        timestamp: new Date().toISOString()
      })
    };
  }
};
