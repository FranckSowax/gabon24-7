// Fonction manuelle pour tester le bundle RSS.app
const bundleSyncFunction = require('./rss-sync-bundle');

exports.handler = async (event, context) => {
  console.log('🧪 Test manuel RSS Bundle démarré');
  
  // Headers CORS
  const headers = {
    'Content-Type': 'application/json',
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type',
  };

  // Handle OPTIONS request (CORS preflight)
  if (event.httpMethod === 'OPTIONS') {
    return {
      statusCode: 200,
      headers,
      body: JSON.stringify({ message: 'CORS preflight OK' })
    };
  }

  try {
    // Appeler la fonction bundle
    const result = await bundleSyncFunction.handler(event, context);
    return result;
  } catch (error) {
    console.error('❌ Erreur test manuel RSS Bundle:', error);
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({
        success: false,
        error: error.message,
        timestamp: new Date().toISOString()
      })
    };
  }
};
