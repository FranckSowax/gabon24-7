// Fonction programmée pour synchronisation RSS optimisée
const optimizedSyncFunction = require('./rss-sync-optimized');

exports.handler = async (event, context) => {
  console.log('📅 Synchronisation RSS programmée démarrée');
  
  // Simuler un événement POST
  const simulatedEvent = {
    httpMethod: 'POST'
  };
  
  try {
    const result = await optimizedSyncFunction.handler(simulatedEvent, context);
    const parsedResult = JSON.parse(result.body);
    
    console.log('✅ Synchronisation RSS terminée:', parsedResult);
    return result;
  } catch (error) {
    console.error('❌ Erreur synchronisation RSS:', error);
    return {
      statusCode: 500,
      body: JSON.stringify({
        success: false,
        error: error.message
      })
    };
  }
};
