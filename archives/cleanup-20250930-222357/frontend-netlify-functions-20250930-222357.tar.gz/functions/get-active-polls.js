const { createClient } = require('@supabase/supabase-js')

const supabase = createClient(
  process.env.SUPABASE_URL,
  process.env.SUPABASE_SERVICE_ROLE_KEY
)

exports.handler = async (event, context) => {
  const nowIso = new Date().toISOString()
  const headers = {
    'Content-Type': 'application/json',
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'Content-Type',
    'Access-Control-Allow-Methods': 'GET, POST, OPTIONS'
  }

  // Handle OPTIONS request for CORS
  if (event.httpMethod === 'OPTIONS') {
    return {
      statusCode: 200,
      headers,
      body: ''
    }
  }

  try {
    console.log('🔍 Récupération des sondages actifs et archivés...')
    
    // Récupérer tous les sondages actifs et publiés
    const { data: activePolls, error: activeError } = await supabase
      .from('polls')
      .select('*')
      .eq('status', 'published')
      .eq('is_active', true)
      .gte('expires_at', nowIso)
      .order('created_at', { ascending: false })
      .limit(20)

    if (activeError) {
      console.error('❌ Erreur Supabase lors de la récupération des sondages actifs:', activeError)
      return {
        statusCode: 500,
        headers,
        body: JSON.stringify({ 
          success: false, 
          error: 'Erreur lors de la récupération des sondages actifs',
          details: activeError.message 
        })
      }
    }

    // Récupérer tous les sondages archivés
    const { data: archivedPolls, error: archivedError } = await supabase
      .from('polls')
      .select('*')
      .eq('status', 'archived')
      .eq('is_active', false)
      .order('created_at', { ascending: false })
      .limit(50)

    if (archivedError) {
      console.error('❌ Erreur Supabase lors de la récupération des sondages archivés:', archivedError)
      // Continue sans les sondages archivés si erreur
    }

    console.log(`✅ ${activePolls?.length || 0} sondages actifs et ${archivedPolls?.length || 0} sondages archivés récupérés`)
    
    return {
      statusCode: 200,
      headers,
      body: JSON.stringify({
        success: true,
        activePolls: activePolls || [],
        archivedPolls: archivedPolls || [],
        activeCount: activePolls?.length || 0,
        archivedCount: archivedPolls?.length || 0
      })
    }

  } catch (error) {
    console.error('❌ Erreur dans get-active-polls:', error)
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({ 
        success: false, 
        error: 'Erreur serveur',
        details: error.message 
      })
    }
  }
}
