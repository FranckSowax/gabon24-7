const { createClient } = require('@supabase/supabase-js')

const supabaseUrl = process.env.SUPABASE_URL
const supabaseServiceKey = process.env.SUPABASE_SERVICE_ROLE_KEY
const openaiApiKey = process.env.OPENAI_API_KEY
const deepseekApiKey = process.env.DEEPSEEK_API_KEY

console.log('🔍 Environment variables check:')
console.log('SUPABASE_URL:', supabaseUrl ? 'SET' : 'MISSING')
console.log('SUPABASE_SERVICE_ROLE_KEY:', supabaseServiceKey ? 'SET' : 'MISSING')
console.log('OPENAI_API_KEY:', openaiApiKey ? `SET (${openaiApiKey.substring(0, 7)}...)` : 'MISSING')
console.log('DEEPSEEK_API_KEY:', deepseekApiKey ? `SET (${deepseekApiKey.substring(0, 7)}...)` : 'MISSING')

const supabase = createClient(supabaseUrl, supabaseServiceKey)

exports.handler = async (event, context) => {
  // Set CORS headers
  const headers = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'Content-Type',
    'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
    'Content-Type': 'application/json'
  }

  // Handle preflight requests
  if (event.httpMethod === 'OPTIONS') {
    return {
      statusCode: 200,
      headers,
      body: ''
    }
  }

  if (event.httpMethod !== 'POST') {
    return {
      statusCode: 405,
      headers,
      body: JSON.stringify({ error: 'Method not allowed' })
    }
  }

  try {
    console.log('📨 Raw event body:', event.body)
    const requestData = JSON.parse(event.body)
    console.log('📋 Parsed request data:', requestData)
    
    // Handle both formats: { article: {...} } and { title, summary, url }
    let article
    if (requestData.article) {
      article = requestData.article
    } else {
      article = {
        title: requestData.title,
        summary: requestData.summary,
        url: requestData.url
      }
    }

    console.log('📥 Received article data:', article)
    
    if (!article || !article.title) {
      console.log('❌ Missing article or title')
      return {
        statusCode: 400,
        headers,
        body: JSON.stringify({ error: 'Article title is required' })
      }
    }
    
    // Handle missing summary/content gracefully
    if (!article.summary && !article.content) {
      console.log('⚠️ No summary or content, using title only')
      article.summary = article.title
    }

    // Check available AI APIs
    console.log('🔑 AI API Keys status:')
    console.log('OpenAI:', openaiApiKey ? `AVAILABLE (${openaiApiKey.length} chars)` : 'NOT FOUND')
    console.log('DeepSeek:', deepseekApiKey ? `AVAILABLE (${deepseekApiKey.length} chars)` : 'NOT FOUND')
    console.log('🔍 Raw OpenAI value:', JSON.stringify(openaiApiKey))
    console.log('🔍 Raw DeepSeek value:', JSON.stringify(deepseekApiKey))
    console.log('📝 Article to analyze:', { title: article.title, source: article.source })
    
    // Check if any AI API is available
    const hasOpenAI = openaiApiKey && openaiApiKey.trim() !== '' && openaiApiKey !== 'undefined' && openaiApiKey !== 'null'
    const hasDeepSeek = deepseekApiKey && deepseekApiKey.trim() !== '' && deepseekApiKey !== 'undefined' && deepseekApiKey !== 'null'
    
    if (!hasOpenAI && !hasDeepSeek) {
      console.log('⚠️ Using DEMO data - No AI API keys configured')
      const demoOpportunity = generateDemoOpportunity(article)
      return {
        statusCode: 200,
        headers,
        body: JSON.stringify(demoOpportunity)
      }
    }

    // Try OpenAI first, fallback to DeepSeek if needed
    let opportunity
    try {
      if (hasOpenAI) {
        console.log('🤖 Calling OpenAI for analysis...')
        opportunity = await analyzeWithAI(article, 'openai')
      } else if (hasDeepSeek) {
        console.log('🤖 Calling DeepSeek for analysis...')
        opportunity = await analyzeWithAI(article, 'deepseek')
      }
    } catch (error) {
      console.log('❌ Primary AI failed, trying fallback...')
      if (hasOpenAI && hasDeepSeek) {
        try {
          console.log('🔄 Trying DeepSeek as fallback...')
          opportunity = await analyzeWithAI(article, 'deepseek')
        } catch (fallbackError) {
          console.log('❌ All AI APIs failed, using demo data')
          const demoOpportunity = generateDemoOpportunity(article)
          return {
            statusCode: 200,
            headers,
            body: JSON.stringify(demoOpportunity)
          }
        }
      } else {
        throw error
      }
    }
    console.log('✅ OpenAI analysis completed:', { title: opportunity.title, confidence: opportunity.confidence_score })

    // Save the analysis to database
    const { data: savedOpportunity, error: dbError } = await supabase
      .from('opportunity_analyses')
      .insert([{
        article_title: article.title,
        article_summary: article.summary,
        article_source: article.source,
        article_url: article.url,
        opportunity_title: opportunity.title,
        opportunity_description: opportunity.description,
        category: opportunity.category,
        potential_revenue: opportunity.potential_revenue,
        investment_required: opportunity.investment_required,
        timeline: opportunity.timeline,
        market_size: opportunity.market_size,
        confidence_score: opportunity.confidence_score,
        analysis_data: opportunity
      }])
      .select()
      .single()

    if (dbError) {
      console.error('Database error:', dbError)
      // Continue without saving to DB
    }

    return {
      statusCode: 200,
      headers,
      body: JSON.stringify(opportunity)
    }

  } catch (error) {
    console.error('❌ Error analyzing opportunity:', error)
    
    // Return demo data as fallback
    const article = JSON.parse(event.body).article
    console.log('🔄 Falling back to DEMO data due to error')
    const demoOpportunity = generateDemoOpportunity(article)
    
    return {
      statusCode: 200,
      headers,
      body: JSON.stringify(demoOpportunity)
    }
  }
}

async function analyzeWithAI(article, provider = 'openai') {
  console.log(`🚀 Starting ${provider.toUpperCase()} analysis...`)
  const prompt = `Tu es un expert multidisciplinaire en développement d'affaires au Gabon. Analyse cette actualité pour identifier des opportunités business concrètes.

**CONTEXTE GABONAIS :**
Population: 2.3M, Mobile: 85%, Internet: 62%
Économie: Pétrole, bois, manganèse, agriculture
Défis: Diversification, emploi jeunes, infrastructures

**EXPERTISE :**
Tech, Commerce, Agriculture, Finance, Tourisme, Éducation, Santé, Transport

**MISSION :**
1. Identifier problématique centrale
2. Analyser secteurs impactés  
3. Proposer 3-4 secteurs d'opportunités maximum

Réponds en JSON strict:
{
  "analyse_contextuelle": {
    "secteur_principal": "Secteur",
    "problematique_centrale": "Problème identifié",
    "acteurs_impactes": "Acteurs concernés",
    "urgence_score": 7,
    "ressources_disponibles": "Ressources"
  },
  "secteurs_opportunites": [
    {
      "nom": "Nom du secteur",
      "description": "Description courte du potentiel",
      "score_potentiel": 8
    }
  ]
}

**ARTICLE À ANALYSER :**
Titre: ${article.title}
Contenu: ${article.summary || article.content || 'Contenu non disponible'}
Source: ${article.source}

IMPORTANT: Réponds UNIQUEMENT avec le JSON demandé, sans texte avant ou après.`

  try {
    const apiKey = provider === 'openai' ? openaiApiKey : deepseekApiKey
    const apiUrl = provider === 'openai' 
      ? 'https://api.openai.com/v1/chat/completions'
      : 'https://api.deepseek.com/v1/chat/completions'
    const model = provider === 'openai' ? 'gpt-3.5-turbo' : 'deepseek-chat'
    
    console.log(`📡 Making request to ${provider.toUpperCase()} API...`)
    const controller = new AbortController()
    const timeoutId = setTimeout(() => controller.abort(), 25000) // 25 second timeout
    
    const response = await fetch(apiUrl, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${apiKey}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        model: model,
        messages: [
          {
            role: 'system',
            content: 'Expert business gabonais. Réponds en JSON strict uniquement.'
          },
          {
            role: 'user',
            content: prompt
          }
        ],
        max_tokens: 800,
        temperature: 0.5
      }),
      signal: controller.signal
    })
    
    clearTimeout(timeoutId)

    console.log('📊 OpenAI API response status:', response.status)
    if (!response.ok) {
      if (response.status === 429) {
        console.log('⏰ Rate limit hit - will retry with exponential backoff')
        // Wait 2 seconds and retry once
        await new Promise(resolve => setTimeout(resolve, 2000))
        
        console.log('🔄 Retrying AI request...')
        const retryResponse = await fetch(apiUrl, {
          method: 'POST',
          headers: {
            'Authorization': `Bearer ${apiKey}`,
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            model: model,
            messages: [
              {
                role: 'system',
                content: 'Expert business gabonais. Réponds en JSON strict uniquement.'
              },
              {
                role: 'user',
                content: prompt
              }
            ],
            max_tokens: 800,
            temperature: 0.5
          })
        })
        
        console.log('📊 Retry response status:', retryResponse.status)
        if (!retryResponse.ok) {
          throw new Error(`OpenAI API error after retry: ${retryResponse.status}`)
        }
        
        const retryData = await retryResponse.json()
        console.log('✅ Retry successful, parsing content...')
        const retryContent = retryData.choices[0].message.content
        
        // Parse the JSON response from retry
        const retryJsonMatch = retryContent.match(/\{[\s\S]*\}/)
        if (!retryJsonMatch) {
          throw new Error('Invalid JSON format in OpenAI response after retry')
        }
        
        return JSON.parse(retryJsonMatch[0])
      }
      throw new Error(`OpenAI API error: ${response.status}`)
    }

    const data = await response.json()
    console.log('🎯 OpenAI response received, parsing content...')
    const content = data.choices[0].message.content

    // Parse the JSON response with better error handling
    console.log('🔍 Raw OpenAI content:', content)
    
    try {
      // Try to extract JSON from the response
      const jsonMatch = content.match(/\{[\s\S]*\}/)
      if (jsonMatch) {
        let jsonString = jsonMatch[0]
        console.log('🔍 Extracted JSON string:', jsonString.substring(0, 200) + '...')
        
        // Clean up common JSON formatting issues
        jsonString = jsonString
          .replace(/,(\s*[}\]])/g, '$1') // Remove trailing commas
          .replace(/([{,]\s*)(\w+):/g, '$1"$2":') // Add quotes to unquoted keys
          .replace(/:\s*'([^']*)'/g, ': "$1"') // Replace single quotes with double quotes
          .replace(/\n/g, ' ') // Remove newlines
          .replace(/\t/g, ' ') // Remove tabs
          .replace(/\s+/g, ' ') // Normalize whitespace
        
        console.log('🧹 Cleaned JSON string:', jsonString.substring(0, 200) + '...')
        
        const opportunityData = JSON.parse(jsonString)
        console.log('✅ Successfully parsed OpenAI response')
        
        return {
          id: `analysis_${Date.now()}`,
          ...opportunityData
        }
      } else {
        console.error('❌ No JSON found in OpenAI response:', content)
        throw new Error('No JSON found in OpenAI response')
      }
    } catch (parseError) {
      console.error('❌ JSON parsing failed:', parseError.message)
      console.error('🔍 Content that failed to parse:', content)
      throw new Error(`JSON parsing failed: ${parseError.message}`)
    }

  } catch (error) {
    console.error('❌ OpenAI API error:', error)
    throw error
  }
}

function generateDemoOpportunity(article) {
  console.log('🎭 Generating DEMO analysis data for:', article.title)
  return {
    id: `demo_analysis_${Date.now()}`,
    analyse_contextuelle: {
      secteur_principal: "Secteur d'activité potentiel",
      problematique_centrale: "Une problématique a été identifiée dans cette actualité nécessitant une attention particulière.",
      acteurs_impactes: "Acteurs économiques locaux",
      urgence_score: 7,
      ressources_disponibles: "Ressources disponibles dans la région"
    },
    secteurs_opportunites: [
      {
        nom: "Technologies & Digital",
        description: "Solutions numériques adaptées au contexte gabonais",
        score_potentiel: 8
      },
      {
        nom: "Services Locaux",
        description: "Prestations de proximité pour les communautés",
        score_potentiel: 9
      },
      {
        nom: "Commerce & Distribution",
        description: "Optimisation des circuits commerciaux",
        score_potentiel: 7
      }
    ]
  }
}
