const fetch = require('node-fetch');

exports.handler = async (event, context) => {
  // Headers CORS
  const headers = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'Content-Type',
    'Access-Control-Allow-Methods': 'GET, OPTIONS',
  };

  // Gestion des requêtes OPTIONS (preflight)
  if (event.httpMethod === 'OPTIONS') {
    return {
      statusCode: 200,
      headers,
      body: ''
    };
  }

  if (event.httpMethod !== 'GET') {
    return {
      statusCode: 405,
      headers,
      body: JSON.stringify({ error: 'Method Not Allowed' })
    };
  }

  try {
    const { url } = event.queryStringParameters || {};
    
    if (!url) {
      return {
        statusCode: 400,
        headers,
        body: JSON.stringify({ error: 'URL parameter is required' })
      };
    }

    // Décoder l'URL
    const imageUrl = decodeURIComponent(url);
    
    // Vérifier que c'est une URL d'image valide
    if (!imageUrl.match(/\.(jpg|jpeg|png|gif|webp)(\?.*)?$/i) && 
        !imageUrl.includes('gabonmediatime.com') && 
        !imageUrl.includes('fbcdn.net') &&
        !imageUrl.includes('scontent') &&
        !imageUrl.includes('facebook.com') &&
        !imageUrl.includes('infosgabon.com') &&
        !imageUrl.includes('directinfosgabon.com') &&
        !imageUrl.includes('gabon24') &&
        !imageUrl.includes('tvgabon24') &&
        !imageUrl.includes('gabonactu.com') &&
        !imageUrl.includes('echosdeleco.com')) {
      return {
        statusCode: 400,
        headers,
        body: JSON.stringify({ error: 'Invalid image URL' })
      };
    }

    // Headers pour contourner les protections anti-hotlinking
    const fetchHeaders = {
      'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',
      'Accept': 'image/webp,image/apng,image/*,*/*;q=0.8',
      'Accept-Language': 'fr-FR,fr;q=0.9,en;q=0.8',
      'Cache-Control': 'no-cache',
      'Pragma': 'no-cache',
    };

    // Ajouter le referrer approprié selon le domaine
    if (imageUrl.includes('gabonmediatime.com')) {
      fetchHeaders['Referer'] = 'https://gabonmediatime.com/';
    } else if (imageUrl.includes('fbcdn.net') || imageUrl.includes('scontent') || imageUrl.includes('facebook.com')) {
      fetchHeaders['Referer'] = 'https://www.facebook.com/';
      // Headers spécifiques pour Facebook optimisés
      fetchHeaders['Accept'] = 'image/avif,image/webp,image/apng,image/svg+xml,image/*,*/*;q=0.8';
      fetchHeaders['Sec-Fetch-Dest'] = 'image';
      fetchHeaders['Sec-Fetch-Mode'] = 'no-cors';
      fetchHeaders['Sec-Fetch-Site'] = 'cross-site';
      fetchHeaders['Origin'] = 'https://www.facebook.com';
      // Headers additionnels pour contourner les restrictions Facebook
      fetchHeaders['Accept-Encoding'] = 'gzip, deflate, br';
      fetchHeaders['Connection'] = 'keep-alive';
      fetchHeaders['Upgrade-Insecure-Requests'] = '1';
    } else if (imageUrl.includes('infosgabon.com')) {
      fetchHeaders['Referer'] = 'https://infosgabon.com/';
    } else if (imageUrl.includes('directinfosgabon.com')) {
      fetchHeaders['Referer'] = 'https://directinfosgabon.com/';
    } else if (imageUrl.includes('gabon24') || imageUrl.includes('tvgabon24')) {
      fetchHeaders['Referer'] = 'https://www.facebook.com/tvgabon24/';
    } else if (imageUrl.includes('gabonactu.com')) {
      fetchHeaders['Referer'] = 'https://gabonactu.com/';
    } else if (imageUrl.includes('echosdeleco.com')) {
      fetchHeaders['Referer'] = 'https://echosdeleco.com/';
    }

    console.log(`Fetching image: ${imageUrl}`);
    
    const response = await fetch(imageUrl, {
      headers: fetchHeaders,
      timeout: 10000
    });

    if (!response.ok) {
      console.error(`Failed to fetch image: ${response.status} ${response.statusText}`);
      
      // Pour les erreurs 403/404 sur Facebook et autres médias gabonais, retourner une image placeholder
      if ((response.status === 403 || response.status === 404) && 
          (imageUrl.includes('fbcdn.net') || imageUrl.includes('facebook.com') || 
           imageUrl.includes('gabon24') || imageUrl.includes('tvgabon24'))) {
        console.log(`Returning placeholder for blocked ${imageUrl.includes('facebook') || imageUrl.includes('fbcdn') ? 'Facebook' : 'Gabon24'} image`);
        return {
          statusCode: 302,
          headers: {
            ...headers,
            'Location': `https://picsum.photos/800/400?random=${Date.now()}&text=Gabon24-7`
          }
        };
      }
      
      return {
        statusCode: response.status,
        headers,
        body: JSON.stringify({ 
          error: 'Failed to fetch image',
          status: response.status,
          statusText: response.statusText
        })
      };
    }

    const contentType = response.headers.get('content-type') || 'image/jpeg';
    const imageBuffer = await response.buffer();

    return {
      statusCode: 200,
      headers: {
        ...headers,
        'Content-Type': contentType,
        'Cache-Control': 'public, max-age=3600', // Cache pendant 1 heure
      },
      body: imageBuffer.toString('base64'),
      isBase64Encoded: true
    };

  } catch (error) {
    console.error('Error in image proxy:', error);
    
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({
        error: 'Internal server error',
        message: error.message
      })
    };
  }
};
