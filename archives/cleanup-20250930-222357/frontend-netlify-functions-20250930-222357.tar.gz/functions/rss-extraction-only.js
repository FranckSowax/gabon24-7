const { createClient } = require('@supabase/supabase-js');
const Parser = require('rss-parser');

// Configuration Supabase
const supabaseUrl = process.env.SUPABASE_URL;
const supabaseServiceKey = process.env.SUPABASE_SERVICE_ROLE_KEY;

if (!supabaseUrl || !supabaseServiceKey) {
  console.error('❌ Variables d\'environnement manquantes');
}

const supabase = createClient(supabaseUrl, supabaseServiceKey);
const parser = new Parser({
  timeout: 8000,
  headers: {
    'User-Agent': 'Gabon24-7 RSS Reader 1.0'
  }
});

// Fonction pour extraire l'image avec gestion proxy
function extractImageFromContent(content, description, feedName) {
  if (!content && !description) return null;
  
  const text = content || description || '';
  
  // Recherche d'images dans les balises img
  const imgMatch = text.match(/<img[^>]+src=["']([^"']+)["'][^>]*>/i);
  if (imgMatch) {
    let imageUrl = imgMatch[1];
    
    // Gestion proxy pour Info Gabon
    if (feedName && (feedName.toLowerCase().includes('info') || feedName.toLowerCase().includes('gabon'))) {
      if (imageUrl.startsWith('http') && !imageUrl.includes('gabon24-7.netlify.app')) {
        const encodedUrl = encodeURIComponent(imageUrl);
        imageUrl = `https://gabon24-7.netlify.app/.netlify/functions/image-proxy?url=${encodedUrl}`;
      }
    }
    
    return imageUrl;
  }
  
  return null;
}

// Extraction RSS pure (sans IA) par groupe
async function extractRSSByGroup(groupName) {
  try {
    console.log(`🚀 Extraction RSS Groupe ${groupName} démarrée...`);
    
    // Récupérer les flux du groupe spécifique
    const { data: feedGroups, error: groupError } = await supabase
      .from('rss_feed_groups')
      .select(`
        feed_id,
        processing_order,
        rss_feeds!inner(*)
      `)
      .eq('group_name', groupName)
      .eq('rss_feeds.status', 'active')
      .order('processing_order', { ascending: true });
    
    if (groupError) {
      throw groupError;
    }
    
    const feeds = feedGroups.map(fg => fg.rss_feeds);
    console.log(`📡 ${feeds.length} flux RSS du groupe ${groupName} à traiter`);
    
    let totalNewArticles = 0;
    let processedFeeds = 0;
    let errorCount = 0;
    const errors = [];
    const startTime = Date.now();
    
    // Traiter chaque flux séquentiellement avec timeout
    for (const feed of feeds) {
      try {
        console.log(`🔍 [${processedFeeds + 1}/${feeds.length}] ${feed.name}`);
        
        // Parser le flux RSS avec timeout
        let rssFeed;
        try {
          const feedTimeout = new Promise((_, reject) => 
            setTimeout(() => reject(new Error('Feed timeout after 7s')), 7000)
          );
          
          rssFeed = await Promise.race([
            parser.parseURL(feed.url),
            feedTimeout
          ]);
        } catch (parseError) {
          console.warn(`⚠️ Flux ignoré (${feed.name}): ${parseError.message}`);
          errors.push(`${feed.name}: ${parseError.message}`);
          errorCount++;
          processedFeeds++;
          continue;
        }
        
        let feedNewArticles = 0;
        
        // Traiter tous les articles récents (limite 15)
        const recentItems = (rssFeed.items || []).slice(0, 15);
        
        for (const item of recentItems) {
          try {
            const externalId = item.guid || item.link || `${feed.id}-${Date.now()}`;
            
            // Vérifier si l'article existe déjà
            const { data: existingArticle } = await supabase
              .from('articles')
              .select('id')
              .eq('feed_id', feed.id)
              .eq('external_id', externalId)
              .single();
            
            if (existingArticle) {
              continue;
            }
            
            // Extraire l'image
            const imageUrl = extractImageFromContent(item.content, item.contentSnippet, feed.name);
            
            // Insérer le nouvel article SANS résumé IA
            const { data: insertedArticle, error: insertError } = await supabase
              .from('articles')
              .insert({
                feed_id: feed.id,
                external_id: externalId,
                title: item.title,
                summary: item.contentSnippet || item.content?.substring(0, 500),
                ai_summary: null, // Sera traité plus tard
                content: item.content || item.contentSnippet,
                url: item.link,
                image_url: imageUrl,
                author: item.creator || item['dc:creator'] || 'Rédaction',
                published_at: item.pubDate ? new Date(item.pubDate).toISOString() : new Date().toISOString(),
                category: feed.category || 'actualités',
                is_published: true,
                view_count: 0
              })
              .select('id')
              .single();
            
            if (insertError) {
              console.error(`❌ Erreur insertion ${item.title}:`, insertError);
            } else {
              feedNewArticles++;
              totalNewArticles++;
              
              // Ajouter à la queue pour résumé IA
              await supabase
                .from('pending_ai_summaries')
                .upsert({
                  article_id: insertedArticle.id,
                  priority: 1, // Haute priorité pour nouveaux articles
                  status: 'pending'
                }, {
                  onConflict: 'article_id',
                  ignoreDuplicates: false
                });
            }
            
          } catch (articleError) {
            console.error(`❌ Erreur article:`, articleError);
          }
        }
        
        // Mettre à jour la date de dernière synchronisation
        await supabase
          .from('rss_feeds')
          .update({ last_fetch_at: new Date().toISOString() })
          .eq('id', feed.id);
        
        console.log(`✅ ${feed.name}: ${feedNewArticles} nouveaux articles`);
        processedFeeds++;
        
      } catch (feedError) {
        console.error(`❌ Erreur ${feed.name}:`, feedError);
        errors.push(`${feed.name}: ${feedError.message}`);
        errorCount++;
        processedFeeds++;
      }
      
      // Délai entre les flux
      if (processedFeeds < feeds.length) {
        await new Promise(resolve => setTimeout(resolve, 300));
      }
    }
    
    const duration = Date.now() - startTime;
    
    // Enregistrer les statistiques
    try {
      await supabase
        .from('sync_logs')
        .insert({
          sync_type: `extraction_group_${groupName.toLowerCase()}`,
          feeds_processed: processedFeeds,
          articles_extracted: totalNewArticles,
          success_count: processedFeeds - errorCount,
          error_count: errorCount,
          errors: errors,
          duration_ms: duration,
          created_at: new Date().toISOString()
        });
    } catch (logError) {
      console.error('❌ Erreur log:', logError);
    }
    
    return {
      success: true,
      group: groupName,
      totalNewArticles,
      processedFeeds,
      duration: Math.round(duration / 1000),
      errors: errorCount
    };
    
  } catch (error) {
    console.error('❌ Erreur extraction groupe:', error);
    throw error;
  }
}

// Handler Netlify
exports.handler = async (event, context) => {
  const headers = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'Content-Type',
    'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
    'Content-Type': 'application/json'
  };

  if (event.httpMethod === 'OPTIONS') {
    return { statusCode: 200, headers, body: '' };
  }

  try {
    // Déterminer le groupe à traiter (A ou B)
    const { group = 'A' } = event.queryStringParameters || {};
    
    if (!['A', 'B'].includes(group.toUpperCase())) {
      throw new Error('Groupe invalide. Utilisez A ou B.');
    }
    
    const result = await extractRSSByGroup(group.toUpperCase());
    
    return {
      statusCode: 200,
      headers,
      body: JSON.stringify({
        success: true,
        message: `Extraction groupe ${group} terminée: ${result.totalNewArticles} nouveaux articles`,
        ...result,
        timestamp: new Date().toISOString()
      })
    };
    
  } catch (error) {
    console.error('❌ Erreur handler:', error);
    
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({
        success: false,
        error: 'Erreur extraction RSS',
        message: error.message
      })
    };
  }
};
