const { createClient } = require('@supabase/supabase-js');
const Parser = require('rss-parser');

// Configuration Supabase
const supabaseUrl = process.env.SUPABASE_URL;
const supabaseServiceKey = process.env.SUPABASE_SERVICE_ROLE_KEY;

if (!supabaseUrl || !supabaseServiceKey) {
  console.error('❌ Variables d\'environnement manquantes');
}

const supabase = createClient(supabaseUrl, supabaseServiceKey);
const parser = new Parser({
  timeout: 12000,
  headers: {
    'User-Agent': 'Gabon24-7 RSS Reader 1.0'
  },
  customFields: {
    feed: [],
    item: []
  }
});

// Fonction pour extraire l'image depuis le contenu HTML
function extractImageFromContent(content, description) {
  if (!content && !description) return null;
  
  const text = content || description || '';
  
  // Recherche d'images dans les balises img
  const imgMatch = text.match(/<img[^>]+src=["']([^"']+)["'][^>]*>/i);
  if (imgMatch) {
    return imgMatch[1];
  }
  
  // Recherche d'URLs d'images directes
  const urlMatch = text.match(/(https?:\/\/[^\s]+\.(?:jpg|jpeg|png|gif|webp))/i);
  if (urlMatch) {
    return urlMatch[1];
  }
  
  return null;
}

// Synchronisation par batch d'un seul flux RSS
async function syncSingleFeed(feed) {
  try {
    console.log(`🔍 Synchronisation: ${feed.name}`);
    
    // Parser le flux RSS avec gestion d'erreur
    let rssFeed;
    try {
      rssFeed = await parser.parseURL(feed.url);
    } catch (parseError) {
      if (parseError.message.includes('Invalid character in entity name') || 
          parseError.message.includes('Status code 403')) {
        console.warn(`⚠️ Flux RSS ignoré (${feed.name}): ${parseError.message}`);
        return { feedName: feed.name, newArticles: 0, status: 'skipped', error: parseError.message };
      }
      throw parseError;
    }
    
    let feedNewArticles = 0;
    
    // Traiter TOUS les articles du flux
    for (const item of rssFeed.items || []) {
      try {
        const externalId = item.guid || item.link || `${feed.id}-${Date.now()}-${Math.random()}`;
        
        // Vérifier si l'article existe déjà
        const { data: existingArticle } = await supabase
          .from('articles')
          .select('id')
          .eq('feed_id', feed.id)
          .eq('external_id', externalId)
          .single();
        
        if (existingArticle) {
          continue;
        }
        
        // Extraire l'image
        const imageUrl = extractImageFromContent(item.content, item.contentSnippet);
        
        // Insérer le nouvel article avec UPSERT
        const { error: insertError } = await supabase
          .from('articles')
          .upsert({
            feed_id: feed.id,
            external_id: externalId,
            title: item.title,
            summary: item.contentSnippet || item.content?.substring(0, 500),
            ai_summary: null, // Pas de résumé IA pour éviter les timeouts
            content: item.content || item.contentSnippet,
            url: item.link,
            image_url: imageUrl,
            author: item.creator || item['dc:creator'] || 'Rédaction',
            published_at: item.pubDate ? new Date(item.pubDate).toISOString() : new Date().toISOString(),
            category: feed.category || 'actualités',
            is_published: true,
            view_count: 0
          }, {
            onConflict: 'feed_id,external_id',
            ignoreDuplicates: true
          });
        
        if (!insertError) {
          feedNewArticles++;
          console.log(`✅ Nouvel article: ${item.title}`);
        } else {
          console.error(`❌ Erreur insertion: ${insertError.message}`);
        }
        
      } catch (articleError) {
        console.error(`❌ Erreur traitement article:`, articleError);
      }
    }
    
    // Mettre à jour la date de dernière synchronisation
    await supabase
      .from('rss_feeds')
      .update({ last_fetch_at: new Date().toISOString() })
      .eq('id', feed.id);
    
    return { 
      feedName: feed.name, 
      newArticles: feedNewArticles, 
      status: 'success' 
    };
    
  } catch (feedError) {
    console.error(`❌ Erreur feed ${feed.name}:`, feedError);
    return { 
      feedName: feed.name, 
      newArticles: 0, 
      status: 'error', 
      error: feedError.message 
    };
  }
}

// Handler Netlify pour synchronisation par batch
exports.handler = async (event, context) => {
  context.callbackWaitsForEmptyEventLoop = false;
  
  const headers = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'Content-Type',
    'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
    'Content-Type': 'application/json'
  };

  if (event.httpMethod === 'OPTIONS') {
    return { statusCode: 200, headers, body: '' };
  }

  try {
    // Vérification des variables d'environnement
    if (!supabaseUrl || !supabaseServiceKey) {
      return {
        statusCode: 500,
        headers,
        body: JSON.stringify({
          success: false,
          error: 'Configuration manquante'
        })
      };
    }
    
    // Récupérer le paramètre batch_size (défaut: 2 flux par batch)
    const batchSize = parseInt(event.queryStringParameters?.batch_size || '2');
    const offset = parseInt(event.queryStringParameters?.offset || '0');
    
    console.log(`🔄 Synchronisation RSS par batch (taille: ${batchSize}, offset: ${offset})`);
    
    // Récupérer un batch de flux RSS actifs avec tri déterministe
    const { data: feeds, error: feedsError } = await supabase
      .from('rss_feeds')
      .select('*')
      .eq('status', 'active')
      .order('priority', { ascending: false })
      .order('id', { ascending: true }) // Tri secondaire par ID pour assurer la cohérence
      .range(offset, offset + batchSize - 1);
    
    if (feedsError) {
      throw feedsError;
    }
    
    console.log(`📡 ${feeds?.length || 0} flux RSS à synchroniser dans ce batch`);
    
    // Traiter chaque flux séquentiellement
    const results = [];
    let totalNewArticles = 0;
    
    for (const feed of feeds || []) {
      const result = await syncSingleFeed(feed);
      results.push(result);
      totalNewArticles += result.newArticles;
    }
    
    // Vérifier s'il y a d'autres batches à traiter
    const { count: totalFeeds } = await supabase
      .from('rss_feeds')
      .select('*', { count: 'exact', head: true })
      .eq('status', 'active');
    
    const hasMoreBatches = (offset + batchSize) < totalFeeds;
    
    return {
      statusCode: 200,
      headers,
      body: JSON.stringify({
        success: true,
        message: `Batch terminé: ${totalNewArticles} nouveaux articles`,
        batch: {
          size: batchSize,
          offset: offset,
          processed: feeds?.length || 0,
          totalFeeds: totalFeeds,
          hasMoreBatches: hasMoreBatches,
          nextOffset: hasMoreBatches ? offset + batchSize : null
        },
        results: results,
        totalNewArticles: totalNewArticles,
        timestamp: new Date().toISOString()
      })
    };
    
  } catch (error) {
    console.error('❌ Erreur handler RSS batch:', error);
    
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({
        success: false,
        error: 'Erreur synchronisation RSS batch',
        message: error.message
      })
    };
  }
};
