const { createClient } = require('@supabase/supabase-js');

const supabaseUrl = process.env.SUPABASE_URL;
const supabaseServiceKey = process.env.SUPABASE_SERVICE_ROLE_KEY;

if (!supabaseUrl || !supabaseServiceKey) {
  console.error('Missing Supabase environment variables');
}

const supabase = createClient(supabaseUrl, supabaseServiceKey);

exports.handler = async (event, context) => {
  // Headers CORS
  const headers = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'Content-Type',
    'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
    'Content-Type': 'application/json'
  };

  if (event.httpMethod === 'OPTIONS') {
    return { statusCode: 200, headers, body: '' };
  }

  if (event.httpMethod !== 'POST') {
    return {
      statusCode: 405,
      headers,
      body: JSON.stringify({ error: 'Method not allowed' })
    };
  }

  try {
    const { alert_id, test_mode = true } = JSON.parse(event.body || '{}');

    if (!alert_id) {
      return {
        statusCode: 400,
        headers,
        body: JSON.stringify({ error: 'alert_id is required' })
      };
    }

    // 1. Récupérer l'alerte
    const { data: alert, error: alertError } = await supabase
      .from('user_alerts')
      .select('*')
      .eq('id', alert_id)
      .single();

    if (alertError || !alert) {
      return {
        statusCode: 404,
        headers,
        body: JSON.stringify({ error: 'Alert not found' })
      };
    }

    // 2. Récupérer des articles récents pour tester
    const { data: articles, error: articlesError } = await supabase
      .from('articles')
      .select('id, title, summary, content, keywords, url, published_at')
      .order('published_at', { ascending: false })
      .limit(50);

    if (articlesError) {
      throw articlesError;
    }

    const matches = [];
    const keywords = alert.keywords || [];

    // 3. Analyser chaque article avec scoring amélioré
    for (const article of articles) {
      const title = (article.title || '').toLowerCase();
      const summary = (article.summary || '').toLowerCase();
      const content = (article.content || '').toLowerCase();
      const articleKeywords = (article.keywords || []).map(k => k.toLowerCase());
      
      const matchedKeywords = [];
      let totalScore = 0;

      // Vérifier chaque mot-clé de l'alerte
      for (const keyword of keywords) {
        const keywordLower = keyword.toLowerCase();
        let keywordScore = 0;
        
        // Recherche dans le titre (poids fort: 3x)
        if (title.includes(keywordLower)) {
          const titleOccurrences = (title.match(new RegExp(keywordLower, 'g')) || []).length;
          keywordScore += titleOccurrences * 0.3;
        }
        
        // Recherche dans le résumé (poids moyen: 2x)
        if (summary.includes(keywordLower)) {
          const summaryOccurrences = (summary.match(new RegExp(keywordLower, 'g')) || []).length;
          keywordScore += summaryOccurrences * 0.2;
        }
        
        // Recherche dans les keywords de l'article (poids fort: 3x)
        if (articleKeywords.some(ak => ak.includes(keywordLower))) {
          keywordScore += 0.3;
        }
        
        // Recherche dans le contenu complet (poids faible: 1x)
        if (content.includes(keywordLower)) {
          const contentOccurrences = (content.match(new RegExp(keywordLower, 'g')) || []).length;
          keywordScore += Math.min(contentOccurrences * 0.1, 0.2); // Max 0.2 pour le contenu
        }
        
        // Si le mot-clé correspond quelque part
        if (keywordScore > 0) {
          matchedKeywords.push(keyword);
          totalScore += keywordScore;
        }
      }

      // Si au moins un mot-clé correspond
      if (matchedKeywords.length > 0) {
        // Score de confiance basé sur le ratio de mots-clés correspondants et le score total
        const keywordRatio = matchedKeywords.length / keywords.length;
        const confidenceScore = Math.min(totalScore * keywordRatio, 0.95); // Max 0.95

        matches.push({
          article_id: article.id,
          article_title: article.title,
          article_url: article.url,
          matched_keywords: matchedKeywords,
          confidence_score: confidenceScore,
          published_at: article.published_at
        });

        // En mode test, ne pas créer les enregistrements en base
        if (!test_mode) {
          await supabase
            .from('alert_matches')
            .insert({
              alert_id: alert.id,
              article_id: article.id,
              matched_keywords: matchedKeywords,
              confidence_score: confidenceScore,
              matching_type: 'exact',
              notification_sent: false
            });
        }
      }
    }

    // Trier par score de confiance décroissant
    matches.sort((a, b) => b.confidence_score - a.confidence_score);

    return {
      statusCode: 200,
      headers,
      body: JSON.stringify({
        success: true,
        alert: {
          id: alert.id,
          name: alert.name,
          keywords: alert.keywords
        },
        total_articles_analyzed: articles.length,
        matches_found: matches.length,
        matches: matches.slice(0, 10), // Top 10 correspondances
        test_mode,
        notification_info: {
          email: alert.email_address || 'Non renseigné',
          whatsapp: alert.whatsapp_number || 'Non renseigné',
          email_enabled: alert.delivery_channels?.email || false,
          whatsapp_enabled: alert.delivery_channels?.whatsapp || false
        }
      })
    };

  } catch (error) {
    console.error('Error testing alert matching:', error);
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({ 
        error: 'Internal server error',
        details: error.message 
      })
    };
  }
};
