const { createClient } = require('@supabase/supabase-js');
const { enhancedExtractSourceFromLink } = require('./enhanced-source-extractor');

const supabaseUrl = process.env.SUPABASE_URL;
const supabaseServiceKey = process.env.SUPABASE_SERVICE_ROLE_KEY;
const supabase = createClient(supabaseUrl, supabaseServiceKey);

// Fonction pour mettre à jour les sources inconnues existantes
async function updateUnknownSources(batchSize = 10) {
  try {
    console.log('🔍 Recherche des articles avec sources inconnues...');
    
    // Récupérer les articles avec sources inconnues ou domaines bruts
    const { data: articles, error } = await supabase
      .from('articles')
      .select('id, url, title, content, summary')
      .or('source.is.null,source.eq.Source inconnue')
      .or('source.like.%.com,source.like.%.ga,source.like.%.net,source.like.%.org')
      .limit(batchSize)
      .order('created_at', { ascending: false });

    if (error) {
      console.error('❌ Erreur récupération articles:', error);
      return { success: false, error: error.message };
    }

    if (!articles || articles.length === 0) {
      return { 
        success: true, 
        message: 'Aucun article avec source inconnue trouvé',
        processed: 0 
      };
    }

    console.log(`📰 ${articles.length} articles à traiter`);
    
    let processed = 0;
    let updated = 0;
    const results = [];

    for (const article of articles) {
      try {
        console.log(`🔄 Traitement: ${article.title?.substring(0, 50)}...`);
        
        // Extraire la nouvelle source
        const newSource = await enhancedExtractSourceFromLink(
          article.url, 
          article.content || article.summary
        );
        
        if (newSource && newSource !== 'Source inconnue' && !newSource.includes('.com')) {
          // Mettre à jour l'article
          const { error: updateError } = await supabase
            .from('articles')
            .update({ source: newSource })
            .eq('id', article.id);
            
          if (!updateError) {
            updated++;
            console.log(`✅ Source mise à jour: "${newSource}"`);
            results.push({
              id: article.id,
              title: article.title?.substring(0, 30) + '...',
              oldSource: 'Source inconnue',
              newSource: newSource,
              status: 'updated'
            });
          } else {
            console.error(`❌ Erreur mise à jour ${article.id}:`, updateError);
            results.push({
              id: article.id,
              status: 'error',
              error: updateError.message
            });
          }
        } else {
          results.push({
            id: article.id,
            status: 'skipped',
            reason: 'Source non détectée'
          });
        }
        
        processed++;
        
        // Pause entre articles pour éviter la surcharge
        await new Promise(resolve => setTimeout(resolve, 100));
        
      } catch (articleError) {
        console.error(`❌ Erreur traitement article ${article.id}:`, articleError);
        results.push({
          id: article.id,
          status: 'error',
          error: articleError.message
        });
        processed++;
      }
    }

    console.log(`🎉 Traitement terminé: ${updated}/${processed} articles mis à jour`);
    
    return {
      success: true,
      processed,
      updated,
      results,
      message: `${updated} sources mises à jour sur ${processed} articles traités`
    };

  } catch (error) {
    console.error('❌ Erreur mise à jour sources:', error);
    return {
      success: false,
      error: error.message,
      processed: 0,
      updated: 0
    };
  }
}

// Handler Netlify
exports.handler = async (event, context) => {
  context.callbackWaitsForEmptyEventLoop = false;
  
  const headers = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'Content-Type',
    'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
    'Content-Type': 'application/json'
  };

  if (event.httpMethod === 'OPTIONS') {
    return { statusCode: 200, headers, body: '' };
  }

  try {
    if (!supabaseUrl || !supabaseServiceKey) {
      return {
        statusCode: 500,
        headers,
        body: JSON.stringify({
          success: false,
          error: 'Configuration Supabase manquante'
        })
      };
    }
    
    const batchSize = parseInt(event.queryStringParameters?.batch_size) || 50;
    console.log(`🚀 Lancement mise à jour sources inconnues (batch: ${batchSize})`);
    
    // Traitement avec timeout de 8 minutes
    const result = await Promise.race([
      updateUnknownSources(batchSize),
      new Promise((_, reject) => 
        setTimeout(() => reject(new Error('Timeout fonction (8min)')), 480000)
      )
    ]);
    
    return {
      statusCode: 200,
      headers,
      body: JSON.stringify({
        ...result,
        timestamp: new Date().toISOString(),
        batchSize
      })
    };
    
  } catch (error) {
    console.error('❌ Erreur handler:', error);
    
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({
        success: false,
        error: 'Erreur mise à jour sources inconnues',
        message: error.message
      })
    };
  }
};

// Export des fonctions pour tests
exports.updateUnknownSources = updateUnknownSources;
