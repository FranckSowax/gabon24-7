const { createClient } = require('@supabase/supabase-js');

// Configuration Supabase
const supabaseUrl = process.env.SUPABASE_URL;
const supabaseServiceKey = process.env.SUPABASE_SERVICE_ROLE_KEY;

if (!supabaseUrl || !supabaseServiceKey) {
  console.error('❌ Variables d\'environnement manquantes');
}

const supabase = createClient(supabaseUrl, supabaseServiceKey);

// Fonction pour traiter un chunk de flux (max 10 flux par chunk)
async function processChunkFeeds(chunkSize = 10, startOffset = 0) {
  try {
    console.log(`🚀 Démarrage synchronisation chunk RSS (offset: ${startOffset}, taille: ${chunkSize})`);
    
    // Récupérer un chunk de flux actifs
    const { data: feeds, error: feedsError } = await supabase
      .from('rss_feeds')
      .select('*')
      .eq('status', 'active')
      .order('priority', { ascending: false })
      .order('id', { ascending: true })
      .range(startOffset, startOffset + chunkSize - 1);
    
    if (feedsError) {
      throw feedsError;
    }
    
    console.log(`📡 ${feeds?.length || 0} flux RSS à synchroniser dans ce chunk`);
    
    let totalProcessed = 0;
    let totalNewArticles = 0;
    let successCount = 0;
    let errorCount = 0;
    const errors = [];
    const startTime = Date.now();
    
    // Traiter chaque flux individuellement avec délai réduit
    for (const feed of feeds || []) {
      try {
        console.log(`🔍 [${startOffset + totalProcessed + 1}] Synchronisation: ${feed.name}`);
        
        // Appeler la fonction batch pour un seul flux avec l'offset correct
        const batchUrl = `${process.env.URL || 'https://gabon24-7.netlify.app'}/.netlify/functions/rss-sync-batch`;
        const response = await fetch(`${batchUrl}?batch_size=1&offset=${startOffset + totalProcessed}`, {
          method: 'GET',
          timeout: 25000 // Timeout de 25s pour éviter les blocages
        });
        
        if (response.ok) {
          const result = await response.json();
          if (result.success) {
            totalNewArticles += result.totalNewArticles || 0;
            successCount++;
            console.log(`✅ ${feed.name}: ${result.totalNewArticles || 0} nouveaux articles`);
          } else {
            errorCount++;
            errors.push(`${feed.name}: ${result.message || 'Erreur inconnue'}`);
            console.error(`❌ ${feed.name}: ${result.message}`);
          }
        } else {
          errorCount++;
          errors.push(`${feed.name}: HTTP ${response.status}`);
          console.error(`❌ ${feed.name}: HTTP ${response.status}`);
        }
        
        totalProcessed++;
        
        // Délai réduit entre les flux (500ms au lieu de 1s)
        if (totalProcessed < feeds.length) {
          await new Promise(resolve => setTimeout(resolve, 500));
        }
        
      } catch (feedError) {
        errorCount++;
        errors.push(`${feed.name}: ${feedError.message}`);
        console.error(`❌ Erreur ${feed.name}:`, feedError.message);
        totalProcessed++;
      }
    }
    
    const duration = Date.now() - startTime;
    
    // Enregistrer les statistiques de synchronisation
    try {
      await supabase
        .from('sync_logs')
        .insert({
          sync_type: 'chunk',
          feeds_processed: totalProcessed,
          articles_extracted: totalNewArticles,
          success_count: successCount,
          error_count: errorCount,
          errors: errors,
          duration_ms: duration,
          created_at: new Date().toISOString()
        });
    } catch (logError) {
      console.error('❌ Erreur enregistrement log:', logError);
    }
    
    console.log(`🎯 Chunk terminé: ${totalNewArticles} nouveaux articles en ${Math.round(duration/1000)}s`);
    
    // Vérifier s'il y a d'autres chunks à traiter
    const { count: totalFeeds } = await supabase
      .from('rss_feeds')
      .select('*', { count: 'exact', head: true })
      .eq('status', 'active');
    
    const hasMoreChunks = (startOffset + chunkSize) < totalFeeds;
    
    return {
      success: true,
      summary: {
        chunkFeeds: feeds.length,
        processed: totalProcessed,
        newArticles: totalNewArticles,
        successCount: successCount,
        errorCount: errorCount,
        duration: duration,
        hasMoreChunks: hasMoreChunks,
        nextOffset: hasMoreChunks ? startOffset + chunkSize : null,
        totalFeeds: totalFeeds
      },
      errors: errors
    };
    
  } catch (error) {
    console.error('❌ Erreur synchronisation chunk:', error);
    throw error;
  }
}

exports.handler = async (event, context) => {
  context.callbackWaitsForEmptyEventLoop = false;
  
  const headers = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'Content-Type',
    'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
    'Content-Type': 'application/json'
  };

  if (event.httpMethod === 'OPTIONS') {
    return { statusCode: 200, headers, body: '' };
  }

  try {
    // Récupérer les paramètres de chunk
    const chunkSize = parseInt(event.queryStringParameters?.chunk_size || '10');
    const offset = parseInt(event.queryStringParameters?.offset || '0');
    
    console.log(`🔄 Coordinateur RSS - Chunk ${Math.floor(offset/chunkSize) + 1} (offset: ${offset}, taille: ${chunkSize})`);
    
    const result = await processChunkFeeds(chunkSize, offset);
    
    return {
      statusCode: 200,
      headers,
      body: JSON.stringify({
        success: true,
        message: `Chunk terminé: ${result.summary.newArticles} nouveaux articles`,
        ...result,
        timestamp: new Date().toISOString()
      })
    };
    
  } catch (error) {
    console.error('❌ Erreur handler coordinator:', error);
    
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({
        success: false,
        error: 'Erreur synchronisation coordinator',
        message: error.message
      })
    };
  }
};
