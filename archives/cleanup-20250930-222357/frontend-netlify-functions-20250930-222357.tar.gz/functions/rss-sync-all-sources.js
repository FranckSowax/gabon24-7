const { createClient } = require('@supabase/supabase-js');
const Parser = require('rss-parser');

const supabase = createClient(
  process.env.SUPABASE_URL,
  process.env.SUPABASE_SERVICE_ROLE_KEY
);

const parser = new Parser({
  timeout: 10000,
  customFields: {
    item: [
      ['media:content', 'media:content', {keepArray: false}],
      ['content:encoded', 'contentEncoded'],
      ['dc:creator', 'creator']
    ]
  }
});

// Liste complète des 48 sources RSS
const RSS_SOURCES = [
  { url: 'https://echosdeleco.com/feed/', name: 'Echos de l\'Eco' },
  { url: 'https://gabonactu.com/feed/', name: 'Gabon Actu' },
  { url: 'https://agpgabon.ga/feed/', name: 'AGP - Agence Gabonaise de Presse' },
  { url: 'https://gabonallsport.com/feed/', name: 'Gabon All Sport' },
  { url: 'https://gaboneco.com/feed/', name: 'GabonEco' },
  { url: 'https://mediapostegabon.com/feed/', name: 'MediaPost Gabon' },
  { url: 'https://union.sonapresse.com/rss.xml', name: 'L\'Union' },
  { url: 'https://7joursinfo.com/category/actualites/feed/', name: '7 Jours Info' },
  { url: 'https://gabonmediatime.com/feed/', name: 'Gabon Media Time' },
  { url: 'https://www.africaintelligence.fr/feeds/AI-GAB.xml', name: 'Africa Intelligence' },
  { url: 'https://www.agencequateur.com/feed/', name: 'Agence Equateur' },
  { url: 'https://courrierdesjournalistes.net/feed/', name: 'Courrier des Journalistes' },
  { url: 'https://directinfosgabon.com/feed/', name: 'Direct Infos Gabon' },
  { url: 'https://www.focusgroupemedia.com/feed/', name: 'Focus Groupe Media' },
  { url: 'https://afrique.latribune.fr/afrique-centrale/gabon.rss', name: 'La Tribune Afrique' },
  { url: 'https://www.rfi.fr/fr/tag/gabon/rss', name: 'RFI' },
  { url: 'https://www.gabonews.com/feed/', name: 'Gabonews' },
  { url: 'https://depeches241.com/feed/', name: 'Dépêches 241' },
  { url: 'https://fr.infosgabon.com/feed/', name: 'Infos Gabon' },
  { url: 'https://insidenews241.com/feed/', name: 'Inside News 241' },
  { url: 'https://www.journaldugabon.com/feed/', name: 'Journal du Gabon' },
  { url: 'https://kongossanews.info/feed/', name: 'Kongossa News' },
  { url: 'https://letouracovert.com/feed/', name: 'Le Touraco Vert' },
  // Pages Facebook gouvernementales (nécessitent une approche différente)
  // YouTube et autres sources vidéo (nécessitent une approche différente)
];

function processImageUrl(imageUrl) {
  if (!imageUrl) return null;
  
  try {
    // Nettoyer les URLs d'images
    if (imageUrl.includes('i0.wp.com') || imageUrl.includes('i1.wp.com')) {
      return imageUrl.split('?')[0]; // Enlever les paramètres
    }
    return imageUrl;
  } catch (error) {
    return null;
  }
}

exports.handler = async (event, context) => {
  const headers = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'Content-Type',
    'Content-Type': 'application/json'
  };

  if (event.httpMethod === 'OPTIONS') {
    return { statusCode: 200, headers, body: '' };
  }

  console.log('🚀 Synchronisation complète de toutes les sources RSS');
  const startTime = Date.now();
  
  const results = {
    success: true,
    sources_processed: 0,
    total_articles: 0,
    new_articles: 0,
    errors: []
  };

  try {
    // Traiter chaque source individuellement
    for (const source of RSS_SOURCES) {
      try {
        console.log(`📡 Récupération de: ${source.name}`);
        const feed = await parser.parseURL(source.url);
        
        if (!feed.items || feed.items.length === 0) {
          console.log(`⚠️ Aucun article trouvé pour ${source.name}`);
          continue;
        }

        results.sources_processed++;
        console.log(`📰 ${feed.items.length} articles trouvés pour ${source.name}`);

        // Limiter à 10 articles par source pour éviter les timeouts
        const articlesToProcess = feed.items.slice(0, 10);
        
        for (const item of articlesToProcess) {
          try {
            if (!item.link) continue;
            
            results.total_articles++;
            
            // Vérifier si l'article existe déjà
            const { data: existingArticle } = await supabase
              .from('articles')
              .select('id')
              .eq('url', item.link)
              .single();
            
            if (existingArticle) {
              continue; // Article déjà existant
            }
            
            // Préparer les données de l'article
            const title = item.title || 'Sans titre';
            const content = item.contentEncoded || item.content || item.contentSnippet || '';
            const pubDate = item.pubDate ? new Date(item.pubDate).toISOString() : new Date().toISOString();
            const imageUrl = processImageUrl(
              item.enclosure?.url || 
              item['media:content']?.url || 
              item['media:content']?.$?.url
            );
            
            // Insérer l'article
            const { error: insertError } = await supabase
              .from('articles')
              .insert({
                title: title,
                content: content,
                url: item.link,
                published_at: pubDate,
                image_url: imageUrl,
                summary: content.substring(0, 300) || '',
                external_id: item.guid || item.link,
                category: 'Actualités',
                author: item.creator || source.name,
                view_count: 0,
                sentiment: 'neutre',
                keywords: [],
                read_time_minutes: Math.ceil(content.length / 1000) || 2,
                is_published: true
              });
            
            if (insertError) {
              console.error(`❌ Erreur insertion pour ${source.name}:`, insertError.message);
              results.errors.push(`${source.name}: ${insertError.message}`);
            } else {
              results.new_articles++;
              console.log(`✅ Article ajouté de ${source.name}`);
              
              // Ajouter à la queue AI pour traitement différé
              supabase
                .from('pending_ai_summaries')
                .insert({
                  article_external_id: item.guid || item.link,
                  status: 'pending',
                  created_at: new Date().toISOString()
                })
                .catch(err => console.warn('⚠️ Erreur queue IA:', err.message));
            }
            
          } catch (itemError) {
            console.error(`❌ Erreur article ${source.name}:`, itemError.message);
          }
        }
        
      } catch (sourceError) {
        console.error(`❌ Erreur source ${source.name}:`, sourceError.message);
        results.errors.push(`${source.name}: ${sourceError.message}`);
      }
    }

    const duration = Date.now() - startTime;
    console.log(`✅ Synchronisation terminée en ${duration}ms`);
    console.log(`📊 Résultats: ${results.sources_processed} sources, ${results.new_articles} nouveaux articles`);

    // Log dans Supabase
    await supabase
      .from('sync_logs')
      .insert({
        sync_type: 'all_sources_sync',
        feeds_processed: results.sources_processed,
        articles_extracted: results.total_articles,
        success_count: results.new_articles,
        error_count: results.errors.length,
        errors: results.errors,
        duration_ms: duration
      });

    return {
      statusCode: 200,
      headers,
      body: JSON.stringify({
        ...results,
        message: `Synchronisation terminée: ${results.new_articles} nouveaux articles de ${results.sources_processed} sources`,
        duration_ms: duration,
        timestamp: new Date().toISOString()
      })
    };

  } catch (error) {
    console.error('❌ Erreur fatale:', error);
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({
        success: false,
        error: error.message,
        timestamp: new Date().toISOString()
      })
    };
  }
};
