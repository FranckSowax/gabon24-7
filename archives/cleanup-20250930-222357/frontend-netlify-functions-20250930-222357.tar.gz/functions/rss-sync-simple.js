const { createClient } = require('@supabase/supabase-js');
const Parser = require('rss-parser');

// Configuration Supabase
const supabaseUrl = process.env.SUPABASE_URL;
const supabaseServiceKey = process.env.SUPABASE_SERVICE_ROLE_KEY;

if (!supabaseUrl || !supabaseServiceKey) {
  console.error('❌ Variables d\'environnement manquantes:', {
    SUPABASE_URL: !!supabaseUrl,
    SUPABASE_SERVICE_ROLE_KEY: !!supabaseServiceKey
  });
}

const supabase = createClient(supabaseUrl, supabaseServiceKey);
const parser = new Parser({
  timeout: 15000,
  headers: {
    'User-Agent': 'Gabon24-7 RSS Reader 1.0'
  },
  customFields: {
    feed: [],
    item: []
  }
});

// Fonction pour extraire l'image depuis le contenu HTML avec gestion proxy pour Info Gabon
function extractImageFromContent(content, description, feedName) {
  if (!content && !description) return null;
  
  const text = content || description || '';
  
  // Recherche d'images dans les balises img
  const imgMatch = text.match(/<img[^>]+src=["']([^"']+)["'][^>]*>/i);
  if (imgMatch) {
    let imageUrl = imgMatch[1];
    
    // Gestion spéciale pour Info Gabon - utiliser proxy pour les images
    if (feedName && (feedName.toLowerCase().includes('info') || feedName.toLowerCase().includes('gabon'))) {
      if (imageUrl.startsWith('http') && !imageUrl.includes('gabon24-7.netlify.app')) {
        // Encoder l'URL pour le proxy
        const encodedUrl = encodeURIComponent(imageUrl);
        imageUrl = `https://gabon24-7.netlify.app/.netlify/functions/image-proxy?url=${encodedUrl}`;
      }
    }
    
    return imageUrl;
  }
  
  // Recherche d'URLs d'images directes
  const urlMatch = text.match(/(https?:\/\/[^\s]+\.(?:jpg|jpeg|png|gif|webp))/i);
  if (urlMatch) {
    let imageUrl = urlMatch[1];
    
    // Gestion spéciale pour Info Gabon - utiliser proxy pour les images
    if (feedName && (feedName.toLowerCase().includes('info') || feedName.toLowerCase().includes('gabon'))) {
      if (!imageUrl.includes('gabon24-7.netlify.app')) {
        const encodedUrl = encodeURIComponent(imageUrl);
        imageUrl = `https://gabon24-7.netlify.app/.netlify/functions/image-proxy?url=${encodedUrl}`;
      }
    }
    
    return imageUrl;
  }
  
  return null;
}

// Fonction simplifiée de synchronisation RSS
async function syncRSSFeeds() {
  try {
    console.log('🔄 Synchronisation RSS simplifiée démarrée...');
    
    // Récupérer TOUS les flux RSS actifs
    const { data: feeds, error: feedsError } = await supabase
      .from('rss_feeds')
      .select('*')
      .eq('status', 'active')
      .order('priority', { ascending: false });
    
    if (feedsError) {
      throw feedsError;
    }
    
    console.log(`📡 ${feeds?.length || 0} flux RSS à synchroniser`);
    
    let totalNewArticles = 0;
    
    for (const feed of feeds || []) {
      try {
        console.log(`🔍 Synchronisation: ${feed.name}`);
        
        // Parser le flux RSS avec gestion d'erreur
        let rssFeed;
        try {
          rssFeed = await parser.parseURL(feed.url);
        } catch (parseError) {
          console.warn(`⚠️ Flux RSS ignoré (${feed.name}): ${parseError.message}`);
          continue;
        }
        
        // Traiter TOUS les articles du flux
        for (const item of rssFeed.items || []) {
          try {
            const externalId = item.guid || item.link || `${feed.id}-${Date.now()}`;
            
            // Vérifier si l'article existe déjà
            const { data: existingArticle } = await supabase
              .from('articles')
              .select('id')
              .eq('feed_id', feed.id)
              .eq('external_id', externalId)
              .single();
            
            if (existingArticle) {
              continue;
            }
            
            // Extraire l'image avec gestion proxy pour Info Gabon
            const imageUrl = extractImageFromContent(item.content, item.contentSnippet, feed.name);
            
            // Insérer le nouvel article avec UPSERT pour éviter les doublons
            const { error: insertError } = await supabase
              .from('articles')
              .upsert({
                feed_id: feed.id,
                external_id: externalId,
                title: item.title,
                summary: item.contentSnippet || item.content?.substring(0, 500),
                ai_summary: null, // Pas de résumé IA pour éviter les timeouts
                content: item.content || item.contentSnippet,
                url: item.link,
                image_url: imageUrl,
                author: item.creator || item['dc:creator'] || 'Rédaction',
                published_at: item.pubDate ? new Date(item.pubDate).toISOString() : new Date().toISOString(),
                category: feed.category || 'actualités',
                is_published: true,
                view_count: 0
              }, {
                onConflict: 'feed_id,external_id',
                ignoreDuplicates: true
              });
            
            if (insertError) {
              console.error(`❌ Erreur insertion article ${item.title}:`, insertError);
            } else {
              totalNewArticles++;
              console.log(`✅ Nouvel article: ${item.title}`);
            }
            
          } catch (articleError) {
            console.error(`❌ Erreur traitement article:`, articleError);
          }
        }
        
        // Mettre à jour la date de dernière synchronisation
        await supabase
          .from('rss_feeds')
          .update({ last_fetch_at: new Date().toISOString() })
          .eq('id', feed.id);
          
      } catch (feedError) {
        console.error(`❌ Erreur feed ${feed.name}:`, feedError);
      }
    }
    
    return {
      newArticles: totalNewArticles,
      message: `Synchronisation terminée: ${totalNewArticles} nouveaux articles`
    };
    
  } catch (error) {
    console.error('❌ Erreur synchronisation RSS:', error);
    throw error;
  }
}

// Handler Netlify optimisé
exports.handler = async (event, context) => {
  // Configuration optimisée pour Netlify
  context.callbackWaitsForEmptyEventLoop = false;
  
  const headers = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'Content-Type',
    'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
    'Content-Type': 'application/json'
  };

  if (event.httpMethod === 'OPTIONS') {
    return { statusCode: 200, headers, body: '' };
  }

  try {
    // Vérification rapide des variables d'environnement
    if (!supabaseUrl || !supabaseServiceKey) {
      return {
        statusCode: 500,
        headers,
        body: JSON.stringify({
          success: false,
          error: 'Configuration manquante'
        })
      };
    }
    
    // Exécuter la synchronisation avec timeout étendu pour traiter tous les flux
    const result = await Promise.race([
      syncRSSFeeds(),
      new Promise((_, reject) => 
        setTimeout(() => reject(new Error('Timeout fonction')), 480000) // 8 minutes pour traiter tous les flux
      )
    ]);
    
    return {
      statusCode: 200,
      headers,
      body: JSON.stringify({
        success: true,
        message: result.message,
        newArticles: result.newArticles,
        timestamp: new Date().toISOString()
      })
    };
    
  } catch (error) {
    console.error('❌ Erreur handler RSS sync:', error);
    
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({
        success: false,
        error: 'Erreur synchronisation RSS',
        message: error.message
      })
    };
  }
};
