const { createClient } = require('@supabase/supabase-js');
const Parser = require('rss-parser');

const supabase = createClient(
  process.env.SUPABASE_URL,
  process.env.SUPABASE_SERVICE_ROLE_KEY
);

const parser = new Parser({
  timeout: 3000, // Réduit pour traiter plus de sources
  customFields: {
    item: [
      ['media:content', 'media:content', {keepArray: false}],
      ['content:encoded', 'contentEncoded'],
      ['dc:creator', 'creator']
    ]
  }
});

// Liste complète des 48 sources RSS (toutes les sources du bundle)
const RSS_SOURCES = [
  // Sources d'actualités principales
  { url: 'https://echosdeleco.com/feed/', name: 'Echos de l\'Eco' },
  { url: 'https://gabonactu.com/feed/', name: 'Gabon Actu' },
  { url: 'https://agpgabon.ga/feed/', name: 'AGP - Agence Gabonaise de Presse' },
  { url: 'https://gabonallsport.com/feed/', name: 'Gabon All Sport' },
  { url: 'https://gaboneco.com/feed/', name: 'GabonEco' },
  { url: 'https://mediapostegabon.com/feed/', name: 'MediaPost Gabon' },
  { url: 'https://union.sonapresse.com/rss.xml', name: 'L\'Union' },
  { url: 'https://7joursinfo.com/category/actualites/feed/', name: '7 Jours Info' },
  { url: 'https://gabonmediatime.com/feed/', name: 'Gabon Media Time' },
  { url: 'https://www.africaintelligence.fr/feeds/AI-GAB.xml', name: 'Africa Intelligence' },
  { url: 'https://www.agencequateur.com/feed/', name: 'Agence Equateur' },
  { url: 'https://courrierdesjournalistes.net/feed/', name: 'Courrier des Journalistes' },
  { url: 'https://directinfosgabon.com/feed/', name: 'Direct Infos Gabon' },
  { url: 'https://www.focusgroupemedia.com/feed/', name: 'Focus Groupe Media' },
  { url: 'https://afrique.latribune.fr/afrique-centrale/gabon.rss', name: 'La Tribune Afrique' },
  { url: 'https://www.rfi.fr/fr/tag/gabon/rss', name: 'RFI' },
  { url: 'https://www.gabonews.com/feed/', name: 'Gabonews' },
  { url: 'https://depeches241.com/feed/', name: 'Dépêches 241' },
  { url: 'https://fr.infosgabon.com/feed/', name: 'Infos Gabon' },
  { url: 'https://infosgabon.com/feed/', name: 'Infos Gabon Alt' },
  { url: 'https://insidenews241.com/feed/', name: 'Inside News 241' },
  { url: 'https://www.journaldugabon.com/feed/', name: 'Journal du Gabon' },
  { url: 'https://kongossanews.info/feed/', name: 'Kongossa News' },
  { url: 'https://letouracovert.com/feed/', name: 'Le Touraco Vert' },
  { url: 'https://sport241.com/feed/', name: 'Sport 241' },
  
  // Sources gouvernementales (Facebook - peuvent ne pas avoir de RSS direct)
  { url: 'https://www.facebook.com/CommunicationGOUVGA/posts.rss', name: 'Communication Gouvernementale' },
  { url: 'https://www.facebook.com/tvgabon24/posts.rss', name: 'Gabon 24' },
  { url: 'https://www.facebook.com/AgricultureGOUVGA/posts.rss', name: 'Ministère de l\'Agriculture' },
  { url: 'https://www.facebook.com/NumeriqueGOUVGA/posts.rss', name: 'Ministère de l\'Economie Numérique' },
  { url: 'https://www.facebook.com/EducationGOUVGA/posts.rss', name: 'Ministère de l\'Education Nationale' },
  { url: 'https://www.facebook.com/EsupGOUVGA/posts.rss', name: 'Ministère de l\'Enseignement Supérieur' },
  { url: 'https://www.facebook.com/ministereindustriegabon/posts.rss', name: 'Ministère de l\'Industrie' },
  { url: 'https://www.facebook.com/InterieurGOUVGA/posts.rss', name: 'Ministère de l\'Intérieur' },
  { url: 'https://www.facebook.com/CommunicationEnGOUVGA/posts.rss', name: 'Ministère de la Communication' },
  { url: 'https://www.facebook.com/JusticeGOUVGA/posts.rss', name: 'Ministère de la Justice' },
  { url: 'https://www.facebook.com/MinesGOUVGA/posts.rss', name: 'Ministère des Mines' },
  { url: 'https://www.facebook.com/TransportsGOUVGA/posts.rss', name: 'Ministère des Transports' },
  { url: 'https://www.facebook.com/EquipementGOUVGA/posts.rss', name: 'Ministère des Travaux Publics' },
  { url: 'https://www.facebook.com/CommercePmePmiGOUVGA/posts.rss', name: 'Ministère du Commerce' },
  { url: 'https://www.facebook.com/PetroleGOUVGA/posts.rss', name: 'Ministère du Pétrole' },
  { url: 'https://www.facebook.com/TourismeGOUVGA/posts.rss', name: 'Ministère du Tourisme' },
  { url: 'https://www.facebook.com/TravailGOUVGA/posts.rss', name: 'Ministère du Travail' },
  
  // Sources supplémentaires pour atteindre 48
  { url: 'https://gabonreview.com/feed/', name: 'Gabon Review' },
  { url: 'https://infogabon.ga/feed/', name: 'Info Gabon' },
  { url: 'https://directinfos.ga/feed/', name: 'Direct Infos' },
  { url: 'https://legabonais.com/feed/', name: 'Le Gabonais' },
  { url: 'https://alibreville.com/feed/', name: 'A Libreville' },
  { url: 'https://lequotidien-ga.com/feed/', name: 'Le Quotidien' },
  { url: 'https://agp.ga/feed/', name: 'AGP Alt' },
  { url: 'https://www.youtube.com/feeds/videos.xml?channel_id=UCGabonMediaTime', name: 'YouTube Gabon Media Time' }
];

function processImageUrl(imageUrl) {
  if (!imageUrl) return null;
  
  try {
    if (imageUrl.includes('i0.wp.com') || imageUrl.includes('i1.wp.com')) {
      return imageUrl.split('?')[0];
    }
    return imageUrl;
  } catch (error) {
    return null;
  }
}

async function processSingleFeed(source, tenHoursAgo) {
  const results = {
    source: source.name,
    processed: 0,
    new_articles: 0,
    errors: []
  };

  try {
    console.log(`📡 Récupération: ${source.name}`);
    const feed = await parser.parseURL(source.url);
    
    if (!feed.items || feed.items.length === 0) {
      console.log(`⚠️ Aucun article pour ${source.name}`);
      return results;
    }

    // Filtrer les articles des 10 dernières heures
    const recentArticles = feed.items.filter(item => {
      if (!item.pubDate) return false;
      const articleDate = new Date(item.pubDate);
      return articleDate >= tenHoursAgo;
    });

    console.log(`📰 ${recentArticles.length} articles récents trouvés pour ${source.name}`);
    
    for (const item of recentArticles) {
      try {
        if (!item.link) continue;
        
        results.processed++;
        
        // Vérifier si l'article existe déjà
        const { data: existingArticle } = await supabase
          .from('articles')
          .select('id')
          .eq('url', item.link)
          .single();
        
        if (existingArticle) {
          continue; // Article déjà existant
        }
        
        // Préparer les données de l'article
        const title = item.title || 'Sans titre';
        const content = item.contentEncoded || item.content || item.contentSnippet || '';
        const pubDate = item.pubDate ? new Date(item.pubDate).toISOString() : new Date().toISOString();
        const imageUrl = processImageUrl(
          item.enclosure?.url || 
          item['media:content']?.url || 
          item['media:content']?.$?.url
        );
        
        // Insérer l'article
        const { error: insertError } = await supabase
          .from('articles')
          .insert({
            title: title,
            content: content,
            url: item.link,
            published_at: pubDate,
            image_url: imageUrl,
            summary: content.substring(0, 300) || '',
            external_id: item.guid || item.link,
            category: 'Actualités',
            author: item.creator || source.name,
            view_count: 0,
            sentiment: 'neutre',
            keywords: [],
            read_time_minutes: Math.ceil(content.length / 1000) || 2,
            is_published: true
          });
        
        if (insertError) {
          console.error(`❌ Erreur insertion ${source.name}:`, insertError.message);
          results.errors.push(insertError.message);
        } else {
          results.new_articles++;
          console.log(`✅ Article ajouté de ${source.name}: ${title.substring(0, 50)}...`);
          
          // Ajouter à la queue AI pour traitement différé
          const queueInsert = async () => {
            try {
              await supabase
                .from('pending_ai_summaries')
                .insert({
                  article_external_id: item.guid || item.link,
                  status: 'pending',
                  created_at: new Date().toISOString()
                });
            } catch (err) {
              console.warn(`⚠️ Erreur queue IA: ${err.message}`);
            }
          };
          queueInsert();
        }
        
      } catch (itemError) {
        console.error(`❌ Erreur article ${source.name}:`, itemError.message);
        results.errors.push(`Article: ${itemError.message}`);
      }
    }
    
  } catch (sourceError) {
    console.error(`❌ Erreur source ${source.name}:`, sourceError.message);
    results.errors.push(`Source: ${sourceError.message}`);
  }

  return results;
}

async function catchupMissingArticles() {
  console.log('🚀 Récupération des articles manqués des 10 dernières heures');
  const startTime = Date.now();
  
  // Calculer la limite de 10 heures
  const tenHoursAgo = new Date(Date.now() - (10 * 60 * 60 * 1000));
  console.log(`⏰ Recherche d'articles après: ${tenHoursAgo.toISOString()}`);
  
  const globalResults = {
    success: true,
    sources_processed: 0,
    total_new_articles: 0,
    errors: [],
    source_details: []
  };

  try {
    // Traiter chaque source individuellement avec délai
    for (const source of RSS_SOURCES) {
      try {
        const sourceResult = await processSingleFeed(source, tenHoursAgo);
        
        globalResults.sources_processed++;
        globalResults.total_new_articles += sourceResult.new_articles;
        globalResults.source_details.push(sourceResult);
        
        if (sourceResult.errors.length > 0) {
          globalResults.errors.push(...sourceResult.errors.map(err => `${source.name}: ${err}`));
        }
        
        // Délai de 200ms entre chaque source pour traiter les 48 sources
        await new Promise(resolve => setTimeout(resolve, 200));
        
      } catch (sourceError) {
        console.error(`❌ Erreur fatale source ${source.name}:`, sourceError.message);
        globalResults.errors.push(`${source.name}: ${sourceError.message}`);
      }
    }

    const duration = Date.now() - startTime;
    console.log(`✅ Récupération terminée en ${duration}ms`);
    console.log(`📊 Résultats: ${globalResults.sources_processed} sources, ${globalResults.total_new_articles} nouveaux articles`);

    // Log dans Supabase (sans colonne details qui n'existe pas)
    const { error: logError } = await supabase
      .from('sync_logs')
      .insert({
        sync_type: 'catchup_missing_10h',
        feeds_processed: globalResults.sources_processed,
        articles_extracted: globalResults.total_new_articles,
        success_count: globalResults.total_new_articles,
        error_count: globalResults.errors.length,
        errors: globalResults.errors,
        duration_ms: duration
      });

    if (logError) {
      console.warn('Erreur log sync:', logError.message);
    }

    return {
      success: true,
      message: `Récupération terminée: ${globalResults.total_new_articles} nouveaux articles de ${globalResults.sources_processed} sources`,
      new_articles: globalResults.total_new_articles,
      sources_processed: globalResults.sources_processed,
      errors: globalResults.errors.length,
      duration_ms: duration,
      timestamp: new Date().toISOString()
    };

  } catch (error) {
    console.error('❌ Erreur fatale:', error);
    
    // Log d'erreur (sans colonne details)
    const { error: logInsertError } = await supabase
      .from('sync_logs')
      .insert({
        sync_type: 'catchup_missing_10h',
        total_articles: 0,
        errors: 1,
        duration_ms: 0,
        status: 'error'
      });
    
    if (logInsertError) {
      console.warn('Erreur log sync:', logInsertError.message);
    }
    
    return {
      success: false,
      error: error.message,
      new_articles: 0
    };
  }
}

exports.handler = async (event, context) => {
  const headers = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'Content-Type',
    'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
    'Content-Type': 'application/json'
  };

  if (event.httpMethod === 'OPTIONS') {
    return { statusCode: 200, headers, body: '' };
  }

  if (event.httpMethod !== 'GET' && event.httpMethod !== 'POST') {
    return {
      statusCode: 405,
      headers,
      body: JSON.stringify({ error: 'Method Not Allowed' })
    };
  }

  try {
    const result = await catchupMissingArticles();
    
    return {
      statusCode: 200,
      headers,
      body: JSON.stringify(result)
    };
    
  } catch (error) {
    console.error('❌ Erreur handler:', error);
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({
        success: false,
        error: 'Erreur synchronisation RSS',
        message: error.message
      })
    };
  }
};
