const { createClient } = require('@supabase/supabase-js');

// Configuration Supabase
const supabaseUrl = process.env.SUPABASE_URL;
const supabaseServiceKey = process.env.SUPABASE_SERVICE_ROLE_KEY;

if (!supabaseUrl || !supabaseServiceKey) {
  console.error('❌ Variables d\'environnement manquantes');
}

const supabase = createClient(supabaseUrl, supabaseServiceKey);

// Liste complète des flux RSS gabonais avec URLs corrigées
const GABON_RSS_FEEDS = [
  {
    name: 'L\'Union',
    url: 'https://www.lunion.ga/rss',
    category: 'Actualités',
    description: 'Journal officiel du Gabon',
    priority: 1,
    status: 'active'
  },
  {
    name: 'Info241',
    url: 'https://info241.com/spip.php?page=backend',
    category: 'Actualités',
    description: 'Premier portail d\'information du Gabon',
    priority: 1,
    status: 'active'
  },
  {
    name: 'Gabon Review',
    url: 'https://www.gabonreview.com/feed',
    category: 'Économie',
    description: 'Actualités économiques et politiques du Gabon',
    priority: 1,
    status: 'active'
  },
  {
    name: 'Gabon Media Time',
    url: 'https://www.gabonmediatime.com/feed',
    category: 'Actualités',
    description: 'Média d\'information gabonais',
    priority: 2,
    status: 'active'
  },
  {
    name: 'Libreville.com',
    url: 'https://www.libreville.com/feed',
    category: 'Actualités',
    description: 'Actualités de Libreville et du Gabon',
    priority: 2,
    status: 'active'
  },
  {
    name: 'Gabon Eco',
    url: 'https://www.gaboneco.com/rss',
    category: 'Économie',
    description: 'Actualités économiques du Gabon',
    priority: 2,
    status: 'active'
  },
  {
    name: 'Gabon Matin',
    url: 'https://www.gabonmatin.com/rss',
    category: 'Actualités',
    description: 'Quotidien d\'information gabonais',
    priority: 2,
    status: 'active'
  },
  {
    name: 'Agence Gabonaise de Presse',
    url: 'https://www.agpgabon.ga/rss',
    category: 'Actualités',
    description: 'Agence officielle de presse du Gabon',
    priority: 1,
    status: 'active'
  },
  {
    name: 'Gabon Actu',
    url: 'https://www.gabonactu.com/feed',
    category: 'Actualités',
    description: 'Actualités générales du Gabon',
    priority: 3,
    status: 'active'
  },
  {
    name: 'Le Nouveau Gabon',
    url: 'https://www.lenouveaugabon.com/rss',
    category: 'Actualités',
    description: 'Journal d\'information gabonais',
    priority: 3,
    status: 'active'
  }
];

// Fonction pour ajouter ou mettre à jour un flux RSS
async function upsertFeed(feed) {
  try {
    // Vérifier si le flux existe déjà
    const { data: existingFeed } = await supabase
      .from('rss_feeds')
      .select('id, name, url, status')
      .eq('url', feed.url)
      .single();

    if (existingFeed) {
      // Mettre à jour le flux existant
      const { error: updateError } = await supabase
        .from('rss_feeds')
        .update({
          name: feed.name,
          category: feed.category,
          description: feed.description,
          priority: feed.priority,
          status: feed.status,
          updated_at: new Date().toISOString()
        })
        .eq('id', existingFeed.id);

      if (updateError) {
        console.error(`❌ Erreur mise à jour ${feed.name}:`, updateError);
        return { success: false, action: 'update', error: updateError.message };
      }

      console.log(`✅ Flux mis à jour: ${feed.name}`);
      return { success: true, action: 'updated', feed: feed.name };
    } else {
      // Insérer un nouveau flux
      const { error: insertError } = await supabase
        .from('rss_feeds')
        .insert({
          name: feed.name,
          url: feed.url,
          category: feed.category,
          description: feed.description,
          priority: feed.priority,
          status: feed.status,
          created_at: new Date().toISOString(),
          updated_at: new Date().toISOString()
        });

      if (insertError) {
        console.error(`❌ Erreur insertion ${feed.name}:`, insertError);
        return { success: false, action: 'insert', error: insertError.message };
      }

      console.log(`✅ Nouveau flux ajouté: ${feed.name}`);
      return { success: true, action: 'inserted', feed: feed.name };
    }
  } catch (error) {
    console.error(`❌ Erreur traitement ${feed.name}:`, error);
    return { success: false, action: 'error', error: error.message };
  }
}

// Handler Netlify
exports.handler = async (event, context) => {
  context.callbackWaitsForEmptyEventLoop = false;
  
  const headers = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'Content-Type',
    'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
    'Content-Type': 'application/json'
  };

  if (event.httpMethod === 'OPTIONS') {
    return { statusCode: 200, headers, body: '' };
  }

  try {
    console.log('🚀 Ajout/Mise à jour des flux RSS gabonais');
    
    const results = [];
    let inserted = 0;
    let updated = 0;
    let errors = 0;

    // Traiter chaque flux RSS
    for (const feed of GABON_RSS_FEEDS) {
      const result = await upsertFeed(feed);
      results.push(result);
      
      if (result.success) {
        if (result.action === 'inserted') inserted++;
        if (result.action === 'updated') updated++;
      } else {
        errors++;
      }
    }

    // Vérifier le nombre total de flux actifs
    const { count: totalActiveFeeds } = await supabase
      .from('rss_feeds')
      .select('*', { count: 'exact', head: true })
      .eq('status', 'active');

    return {
      statusCode: 200,
      headers,
      body: JSON.stringify({
        success: true,
        message: `Configuration des flux RSS terminée`,
        summary: {
          totalProcessed: GABON_RSS_FEEDS.length,
          inserted: inserted,
          updated: updated,
          errors: errors,
          totalActiveFeeds: totalActiveFeeds
        },
        results: results,
        timestamp: new Date().toISOString()
      })
    };
    
  } catch (error) {
    console.error('❌ Erreur configuration flux RSS:', error);
    
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({
        success: false,
        error: 'Erreur configuration flux RSS',
        message: error.message
      })
    };
  }
};
