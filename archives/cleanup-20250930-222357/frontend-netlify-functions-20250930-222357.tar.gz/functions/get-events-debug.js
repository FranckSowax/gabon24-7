const { createClient } = require('@supabase/supabase-js');

exports.handler = async (event, context) => {
  // Configuration Supabase
  const supabaseUrl = process.env.SUPABASE_URL;
  const supabaseServiceKey = process.env.SUPABASE_SERVICE_ROLE_KEY;

  console.log('🔧 Debug - Variables d\'environnement:', {
    hasUrl: !!supabaseUrl,
    hasKey: !!supabaseServiceKey,
    urlLength: supabaseUrl?.length || 0,
    keyLength: supabaseServiceKey?.length || 0
  });

  if (!supabaseUrl || !supabaseServiceKey) {
    console.error('❌ Variables d\'environnement manquantes');
    return {
      statusCode: 500,
      headers: {
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Headers': 'Content-Type',
        'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        success: false,
        error: 'Configuration manquante',
        debug: {
          hasUrl: !!supabaseUrl,
          hasKey: !!supabaseServiceKey
        }
      })
    };
  }

  const supabase = createClient(supabaseUrl, supabaseServiceKey);
  const headers = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'Content-Type',
    'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
    'Content-Type': 'application/json'
  };

  if (event.httpMethod === 'OPTIONS') {
    return { statusCode: 200, headers, body: '' };
  }

  try {
    console.log('🔍 Test de connexion Supabase...');
    
    // Test simple de connexion
    const { data: testData, error: testError } = await supabase
      .from('articles')
      .select('count')
      .limit(1);

    console.log('📊 Test connexion:', { 
      success: !testError,
      error: testError?.message || 'aucune erreur'
    });

    if (testError) {
      return {
        statusCode: 500,
        headers,
        body: JSON.stringify({
          success: false,
          error: 'Erreur de connexion Supabase',
          details: testError.message
        })
      };
    }

    // Récupérer les événements
    const { data: events, error } = await supabase
      .from('articles')
      .select(`
        id,
        title,
        summary,
        image_urls,
        url,
        published_at,
        location,
        date
      `)
      .eq('category', 'événements')
      .order('published_at', { ascending: false })
      .limit(5);

    console.log('📊 Résultats de la requête:', { 
      count: events?.length || 0, 
      error: error?.message || 'aucune erreur',
      sampleTitles: events?.slice(0, 2).map(e => e.title)
    });

    if (error) {
      return {
        statusCode: 500,
        headers,
        body: JSON.stringify({
          success: false,
          error: 'Erreur lors de la récupération des événements',
          details: error.message
        })
      };
    }

    // Transformer les données
    const transformedEvents = events.map(event => {
      let imageUrl = null;
      if (event.image_urls && Array.isArray(event.image_urls) && event.image_urls.length > 0) {
        imageUrl = event.image_urls[0];
      }
      
      return {
        id: event.id,
        title: event.title,
        description: event.summary || '',
        image_url: imageUrl,
        url: event.url,
        published_at: event.published_at,
        location: event.location || null,
        date: event.date || event.published_at
      };
    });

    return {
      statusCode: 200,
      headers,
      body: JSON.stringify({
        success: true,
        events: transformedEvents,
        total: transformedEvents.length,
        timestamp: new Date().toISOString(),
        debug: {
          originalCount: events.length,
          hasImages: transformedEvents.filter(e => e.image_url).length
        }
      })
    };

  } catch (error) {
    console.error('❌ Erreur handler get-events-debug:', error);
    
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({
        success: false,
        error: 'Erreur lors de la récupération des événements',
        message: error.message,
        stack: error.stack,
        events: []
      })
    };
  }
};
