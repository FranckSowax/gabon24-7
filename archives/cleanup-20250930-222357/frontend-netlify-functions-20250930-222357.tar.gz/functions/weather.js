exports.handler = async (event, context) => {
  // Headers CORS
  const headers = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'Content-Type',
    'Access-Control-Allow-Methods': 'GET, OPTIONS',
    'Content-Type': 'application/json'
  };

  // Gestion des requêtes OPTIONS (preflight)
  if (event.httpMethod === 'OPTIONS') {
    return {
      statusCode: 200,
      headers,
      body: ''
    };
  }

  if (event.httpMethod !== 'GET') {
    return {
      statusCode: 405,
      headers,
      body: JSON.stringify({ error: 'Method Not Allowed' })
    };
  }

  try {
    // Extraire la ville depuis l'URL
    const pathSegments = event.path.split('/');
    const city = pathSegments[pathSegments.length - 1] || 'libreville';
    
    console.log(`🌤️ Récupération météo pour: ${city}`);

    // Données météo réalistes pour les 4 villes du Gabon avec prévisions
    const getCurrentWeatherData = () => {
      const now = new Date();
      const hour = now.getHours();
      
      // Variation selon l'heure pour plus de réalisme
      const tempVariation = Math.sin((hour - 6) * Math.PI / 12) * 3; // Variation de ±3°C
      
      return {
        libreville: {
          temperature: Math.round(27 + tempVariation),
          feels_like: Math.round(30 + tempVariation),
          weather_description: hour < 12 ? "Partiellement nuageux" : "Ensoleillé avec nuages",
          humidity: 85,
          wind_speed: 3.2,
          pressure: 1012,
          weather_icon: hour < 12 ? "02d" : "01d",
          visibility: 10000,
          uv_index: Math.max(0, Math.round(8 * Math.sin((hour - 6) * Math.PI / 12))),
          forecast: [
            { dt: now.getTime() / 1000, temp: 27 + tempVariation, temp_max: 29, temp_min: 24, description: 'Ensoleillé', icon: '01d', pop: 0.1 },
            { dt: (now.getTime() / 1000) + 86400, temp: 26, temp_max: 28, temp_min: 23, description: 'Partiellement nuageux', icon: '02d', pop: 0.3 },
            { dt: (now.getTime() / 1000) + 172800, temp: 25, temp_max: 27, temp_min: 22, description: 'Averses', icon: '10d', pop: 0.7 },
            { dt: (now.getTime() / 1000) + 259200, temp: 28, temp_max: 30, temp_min: 25, description: 'Orageux', icon: '11d', pop: 0.8 },
            { dt: (now.getTime() / 1000) + 345600, temp: 26, temp_max: 28, temp_min: 24, description: 'Nuageux', icon: '04d', pop: 0.2 }
          ]
        },
        "port-gentil": {
          temperature: Math.round(26 + tempVariation),
          feels_like: Math.round(29 + tempVariation),
          weather_description: "Temps humide avec éclaircies",
          humidity: 88,
          wind_speed: 4.1,
          pressure: 1011,
          weather_icon: "10d",
          visibility: 8000,
          uv_index: Math.max(0, Math.round(7 * Math.sin((hour - 6) * Math.PI / 12))),
          forecast: [
            { dt: now.getTime() / 1000, temp: 26 + tempVariation, temp_max: 28, temp_min: 23, description: 'Humide', icon: '10d', pop: 0.4 },
            { dt: (now.getTime() / 1000) + 86400, temp: 25, temp_max: 27, temp_min: 22, description: 'Averses éparses', icon: '09d', pop: 0.6 },
            { dt: (now.getTime() / 1000) + 172800, temp: 27, temp_max: 29, temp_min: 24, description: 'Ensoleillé', icon: '01d', pop: 0.2 },
            { dt: (now.getTime() / 1000) + 259200, temp: 26, temp_max: 28, temp_min: 23, description: 'Nuageux', icon: '04d', pop: 0.3 },
            { dt: (now.getTime() / 1000) + 345600, temp: 24, temp_max: 26, temp_min: 21, description: 'Pluvieux', icon: '10d', pop: 0.8 }
          ]
        },
        franceville: {
          temperature: Math.round(25 + tempVariation),
          feels_like: Math.round(28 + tempVariation),
          weather_description: "Ciel dégagé",
          humidity: 78,
          wind_speed: 2.5,
          pressure: 1016,
          weather_icon: "01d",
          visibility: 12000,
          uv_index: Math.max(0, Math.round(9 * Math.sin((hour - 6) * Math.PI / 12))),
          forecast: [
            { dt: now.getTime() / 1000, temp: 25 + tempVariation, temp_max: 27, temp_min: 22, description: 'Ciel dégagé', icon: '01d', pop: 0.0 },
            { dt: (now.getTime() / 1000) + 86400, temp: 24, temp_max: 26, temp_min: 21, description: 'Partiellement nuageux', icon: '02d', pop: 0.2 },
            { dt: (now.getTime() / 1000) + 172800, temp: 26, temp_max: 28, temp_min: 23, description: 'Ensoleillé', icon: '01d', pop: 0.1 },
            { dt: (now.getTime() / 1000) + 259200, temp: 23, temp_max: 25, temp_min: 20, description: 'Averses', icon: '10d', pop: 0.7 },
            { dt: (now.getTime() / 1000) + 345600, temp: 25, temp_max: 27, temp_min: 22, description: 'Nuageux', icon: '04d', pop: 0.4 }
          ]
        },
        oyem: {
          temperature: Math.round(24 + tempVariation),
          feels_like: Math.round(27 + tempVariation),
          weather_description: "Averses éparses",
          humidity: 82,
          wind_speed: 2.8,
          pressure: 1015,
          weather_icon: "09d",
          visibility: 6000,
          uv_index: Math.max(0, Math.round(6 * Math.sin((hour - 6) * Math.PI / 12))),
          forecast: [
            { dt: now.getTime() / 1000, temp: 24 + tempVariation, temp_max: 26, temp_min: 21, description: 'Averses éparses', icon: '09d', pop: 0.6 },
            { dt: (now.getTime() / 1000) + 86400, temp: 23, temp_max: 25, temp_min: 20, description: 'Pluvieux', icon: '10d', pop: 0.8 },
            { dt: (now.getTime() / 1000) + 172800, temp: 22, temp_max: 24, temp_min: 19, description: 'Orageux', icon: '11d', pop: 0.9 },
            { dt: (now.getTime() / 1000) + 259200, temp: 25, temp_max: 27, temp_min: 22, description: 'Éclaircies', icon: '02d', pop: 0.3 },
            { dt: (now.getTime() / 1000) + 345600, temp: 24, temp_max: 26, temp_min: 21, description: 'Nuageux', icon: '04d', pop: 0.4 }
          ]
        }
      };
    };
    
    // Fonction pour calculer la prochaine mise à jour à 6h
    const getNextUpdateTime = () => {
      const now = new Date();
      const tomorrow6AM = new Date(now);
      tomorrow6AM.setDate(now.getDate() + 1);
      tomorrow6AM.setHours(6, 0, 0, 0);
      
      // Si on est déjà passé 6h aujourd'hui, la prochaine mise à jour est demain à 6h
      if (now.getHours() >= 6) {
        return tomorrow6AM.toISOString();
      } else {
        // Sinon, c'est aujourd'hui à 6h
        const today6AM = new Date(now);
        today6AM.setHours(6, 0, 0, 0);
        return today6AM.toISOString();
      }
    };

    const weatherData = getCurrentWeatherData();

    const cityKey = city.toLowerCase().replace('-', '-');
    const cityData = weatherData[cityKey] || weatherData.libreville;

    return {
      statusCode: 200,
      headers,
      body: JSON.stringify({
        success: true,
        city: city,
        data: cityData,
        forecast: cityData.forecast,
        fallback: {
          temperature: 25,
          weather_description: "Données météo non disponibles",
          humidity: 70,
          wind_speed: 8,
          weather_icon: "01d"
        },
        timestamp: new Date().toISOString(),
        next_update: getNextUpdateTime() // Prochaine mise à jour à 6h le lendemain
      })
    };

  } catch (error) {
    console.error('❌ Erreur dans weather function:', error);
    
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({
        success: false,
        error: 'Erreur serveur',
        message: error.message
      })
    };
  }
};
