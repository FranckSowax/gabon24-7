const { createClient } = require('@supabase/supabase-js');

// Configuration Supabase avec validation
const supabaseUrl = process.env.SUPABASE_URL;
const supabaseServiceKey = process.env.SUPABASE_SERVICE_ROLE_KEY;

if (!supabaseUrl || !supabaseServiceKey) {
  console.error('❌ Variables d\'environnement manquantes:', {
    SUPABASE_URL: !!supabaseUrl,
    SUPABASE_SERVICE_ROLE_KEY: !!supabaseServiceKey
  });
}

const supabase = createClient(supabaseUrl, supabaseServiceKey);

exports.handler = async (event, context) => {
  // Headers CORS
  const headers = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'Content-Type',
    'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
    'Content-Type': 'application/json'
  };

  // Gestion des requêtes OPTIONS (preflight)
  if (event.httpMethod === 'OPTIONS') {
    return {
      statusCode: 200,
      headers,
      body: ''
    };
  }

  try {
    // Vérification des variables d'environnement
    if (!supabaseUrl || !supabaseServiceKey) {
      return {
        statusCode: 500,
        headers,
        body: JSON.stringify({
          success: false,
          error: 'Configuration manquante',
          message: 'Variables d\'environnement Supabase non configurées'
        })
      };
    }

    // GET - Récupérer les slides actifs
    if (event.httpMethod === 'GET') {
      console.log('🎯 Récupération des slides publicitaires...');
      
      const { data: slides, error } = await supabase
        .from('promotional_slides')
        .select(`
          *,
          ad_campaigns!inner (
            company_name,
            is_active,
            admin_approved,
            payment_status,
            start_date,
            end_date
          )
        `)
        .eq('is_active', true)
        .eq('admin_approved', true)
        .eq('ad_campaigns.is_active', true)
        .eq('ad_campaigns.admin_approved', true)
        .eq('ad_campaigns.payment_status', 'paid')
        .gte('ad_campaigns.end_date', new Date().toISOString())
        .order('display_order', { ascending: true });

      if (error) {
        console.error('❌ Erreur Supabase slides:', error);
        throw error;
      }

      // Transformation pour le frontend
      const transformedSlides = slides?.map(slide => ({
        id: slide.id,
        title: slide.title,
        description: slide.description,
        imageUrl: slide.image_url,
        linkUrl: slide.link_url,
        ctaText: slide.cta_text || 'En savoir plus',
        companyName: slide.ad_campaigns?.company_name || slide.company_name,
        displayOrder: slide.display_order,
        slideType: slide.slide_type || 'image',
        htmlContent: slide.html_content
      })) || [];

      console.log(`✅ ${transformedSlides.length} slides récupérés`);

      return {
        statusCode: 200,
        headers,
        body: JSON.stringify({
          success: true,
          slides: transformedSlides
        })
      };
    }

    // POST - Enregistrer une vue ou un clic
    if (event.httpMethod === 'POST') {
      const body = JSON.parse(event.body || '{}');
      const { slideId, action, userAgent, referrer } = body;

      if (!slideId || !action) {
        return {
          statusCode: 400,
          headers,
          body: JSON.stringify({ 
            success: false, 
            error: 'slideId et action requis' 
          })
        };
      }

      console.log(`📊 Tracking ${action} pour slide ${slideId}`);

      // Insérer dans slide_analytics
      const { error: analyticsError } = await supabase
        .from('slide_analytics')
        .insert({
          slide_id: slideId,
          event_type: action,
          user_agent: userAgent,
          referrer: referrer,
          user_ip: event.headers['x-forwarded-for'] || event.headers['x-real-ip']
        });

      if (analyticsError) {
        console.error('❌ Erreur analytics:', analyticsError);
      }

      // Mettre à jour les compteurs dans promotional_slides
      const updateField = action === 'view' ? 'view_count' : 'click_count';
      
      // Fallback: mise à jour manuelle
      const { data: currentSlide } = await supabase
        .from('promotional_slides')
        .select(updateField)
        .eq('id', slideId)
        .single();

      if (currentSlide) {
        await supabase
          .from('promotional_slides')
          .update({ [updateField]: (currentSlide[updateField] || 0) + 1 })
          .eq('id', slideId);
      };

      return {
        statusCode: 200,
        headers,
        body: JSON.stringify({
          success: true,
          message: `${action} enregistré`
        })
      };
    }

    return {
      statusCode: 405,
      headers,
      body: JSON.stringify({ error: 'Method Not Allowed' })
    };

  } catch (error) {
    console.error('❌ Erreur dans slides function:', error);
    
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({
        success: false,
        error: 'Erreur serveur',
        message: error.message
      })
    };
  }
};
