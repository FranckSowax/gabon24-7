const { createClient } = require('@supabase/supabase-js');

const supabaseUrl = process.env.SUPABASE_URL;
const supabaseKey = process.env.SUPABASE_SERVICE_ROLE_KEY;
const supabase = createClient(supabaseUrl, supabaseKey);

exports.handler = async (event, context) => {
  context.callbackWaitsForEmptyEventLoop = false;
  
  const headers = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'Content-Type',
    'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
    'Content-Type': 'application/json'
  };

  if (event.httpMethod === 'OPTIONS') {
    return { statusCode: 200, headers };
  }

  try {
    // Récupérer les derniers logs de sync
    const { data: syncLogs } = await supabase
      .from('sync_logs')
      .select('*')
      .order('created_at', { ascending: false })
      .limit(5);

    // Récupérer les derniers articles
    const { data: recentArticles } = await supabase
      .from('articles')
      .select('title, source, created_at, published_at')
      .order('created_at', { ascending: false })
      .limit(10);

    // Récupérer les articles en attente de résumé IA
    const { data: pendingAI } = await supabase
      .from('pending_ai_summaries')
      .select('count')
      .eq('status', 'pending');

    const status = {
      timestamp: new Date().toISOString(),
      recentSyncLogs: syncLogs || [],
      recentArticles: recentArticles || [],
      pendingAISummaries: pendingAI?.length || 0,
      lastArticleTime: recentArticles?.[0]?.created_at || null,
      systemStatus: 'operational'
    };

    return {
      statusCode: 200,
      headers,
      body: JSON.stringify(status, null, 2)
    };

  } catch (error) {
    console.error('❌ Erreur status:', error);
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({
        error: error.message,
        timestamp: new Date().toISOString()
      })
    };
  }
};
