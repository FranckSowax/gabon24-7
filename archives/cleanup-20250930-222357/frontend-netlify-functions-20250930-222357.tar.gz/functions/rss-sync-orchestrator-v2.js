const { createClient } = require('@supabase/supabase-js');

// Configuration Supabase
const supabaseUrl = process.env.SUPABASE_URL;
const supabaseServiceKey = process.env.SUPABASE_SERVICE_ROLE_KEY;

if (!supabaseUrl || !supabaseServiceKey) {
  console.error('❌ Variables d\'environnement manquantes');
}

const supabase = createClient(supabaseUrl, supabaseServiceKey);

// Fonction pour orchestrer la synchronisation complète par chunks
async function orchestrateFullSync() {
  try {
    console.log('🚀 Orchestrateur RSS - Démarrage synchronisation complète par chunks');
    
    // Récupérer le nombre total de flux actifs
    const { count: totalFeeds } = await supabase
      .from('rss_feeds')
      .select('*', { count: 'exact', head: true })
      .eq('status', 'active');
    
    console.log(`📡 ${totalFeeds} flux RSS actifs à synchroniser`);
    
    const chunkSize = 3; // Réduire à 3 flux par chunk pour éviter les timeouts
    let currentOffset = 0;
    let totalNewArticles = 0;
    let totalProcessed = 0;
    let totalSuccess = 0;
    let totalErrors = 0;
    const allErrors = [];
    const startTime = Date.now();
    const maxExecutionTime = 8 * 60 * 1000; // 8 minutes max pour éviter le timeout Netlify
    
    // Traiter chunk par chunk avec limite de temps
    while (currentOffset < totalFeeds && (Date.now() - startTime) < maxExecutionTime) {
      const chunkNumber = Math.floor(currentOffset / chunkSize) + 1;
      const totalChunks = Math.ceil(totalFeeds / chunkSize);
      
      console.log(`🔄 Traitement chunk ${chunkNumber}/${totalChunks} (offset: ${currentOffset})`);
      
      try {
        // Appeler le coordinateur pour ce chunk
        const coordinatorUrl = `${process.env.URL || 'https://gabon24-7.netlify.app'}/.netlify/functions/rss-sync-coordinator`;
        const response = await fetch(`${coordinatorUrl}?chunk_size=${chunkSize}&offset=${currentOffset}`, {
          method: 'POST',
          timeout: 20000 // Timeout de 20s par chunk
        });
        
        if (response.ok) {
          const result = await response.json();
          if (result.success) {
            totalNewArticles += result.summary?.newArticles || 0;
            totalProcessed += result.summary?.processed || 0;
            totalSuccess += result.summary?.successCount || 0;
            totalErrors += result.summary?.errorCount || 0;
            
            if (result.errors && result.errors.length > 0) {
              allErrors.push(...result.errors);
            }
            
            console.log(`✅ Chunk ${chunkNumber} terminé: ${result.summary?.newArticles || 0} nouveaux articles`);
          } else {
            console.error(`❌ Chunk ${chunkNumber} échoué:`, result.message);
            allErrors.push(`Chunk ${chunkNumber}: ${result.message}`);
          }
        } else {
          console.error(`❌ Chunk ${chunkNumber} HTTP error:`, response.status);
          allErrors.push(`Chunk ${chunkNumber}: HTTP ${response.status}`);
        }
        
      } catch (chunkError) {
        console.error(`❌ Erreur chunk ${chunkNumber}:`, chunkError.message);
        allErrors.push(`Chunk ${chunkNumber}: ${chunkError.message}`);
      }
      
      currentOffset += chunkSize;
      
      // Délai réduit entre les chunks pour optimiser le temps
      if (currentOffset < totalFeeds && (Date.now() - startTime) < maxExecutionTime) {
        await new Promise(resolve => setTimeout(resolve, 1000));
      }
    }
    
    const duration = Date.now() - startTime;
    
    // Enregistrer les statistiques globales
    try {
      await supabase
        .from('sync_logs')
        .insert({
          sync_type: 'orchestrator',
          feeds_processed: totalProcessed,
          articles_extracted: totalNewArticles,
          success_count: totalSuccess,
          error_count: totalErrors,
          errors: allErrors,
          duration_ms: duration,
          created_at: new Date().toISOString()
        });
    } catch (logError) {
      console.error('❌ Erreur enregistrement log orchestrateur:', logError);
    }
    
    console.log(`🎯 Synchronisation complète terminée: ${totalNewArticles} nouveaux articles en ${Math.round(duration/1000)}s`);
    
    return {
      success: true,
      summary: {
        totalFeeds: totalFeeds,
        processed: totalProcessed,
        newArticles: totalNewArticles,
        successCount: totalSuccess,
        errorCount: totalErrors,
        duration: duration,
        chunksProcessed: Math.ceil(totalFeeds / chunkSize)
      },
      errors: allErrors
    };
    
  } catch (error) {
    console.error('❌ Erreur orchestrateur RSS:', error);
    throw error;
  }
}

exports.handler = async (event, context) => {
  context.callbackWaitsForEmptyEventLoop = false;
  
  const headers = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'Content-Type',
    'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
    'Content-Type': 'application/json'
  };

  if (event.httpMethod === 'OPTIONS') {
    return { statusCode: 200, headers, body: '' };
  }

  try {
    const result = await orchestrateFullSync();
    
    return {
      statusCode: 200,
      headers,
      body: JSON.stringify({
        success: true,
        message: `Synchronisation orchestrée terminée: ${result.summary.newArticles} nouveaux articles`,
        ...result,
        timestamp: new Date().toISOString()
      })
    };
    
  } catch (error) {
    console.error('❌ Erreur handler orchestrateur:', error);
    
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({
        success: false,
        error: 'Erreur synchronisation orchestrateur',
        message: error.message
      })
    };
  }
};
