const { createClient } = require('@supabase/supabase-js');
const Parser = require('rss-parser');

// Configuration Supabase
const supabaseUrl = process.env.SUPABASE_URL;
const supabaseServiceKey = process.env.SUPABASE_SERVICE_ROLE_KEY;

if (!supabaseUrl || !supabaseServiceKey) {
  console.error('❌ Variables d\'environnement manquantes');
}

const supabase = createClient(supabaseUrl, supabaseServiceKey);
const parser = new Parser({
  timeout: 10000,
  headers: {
    'User-Agent': 'Gabon24-7 RSS Reader 1.0'
  }
});

// Bundle RSS.app URL - remplace les 47 flux individuels
const RSS_BUNDLE_URL = 'https://rss.app/feeds/_SntJgjZXkqIWrDHq.xml';

// Fonction pour extraire l'image avec gestion proxy
function extractImageFromContent(content, description, feedName) {
  if (!content && !description) return null;
  
  const text = content || description || '';
  
  // Recherche d'images dans les balises img
  const imgMatch = text.match(/<img[^>]+src=["']([^"']+)["'][^>]*>/i);
  if (imgMatch) {
    let imageUrl = imgMatch[1];
    
    // Gestion proxy pour Info Gabon
    if (feedName && (feedName.toLowerCase().includes('info') || feedName.toLowerCase().includes('gabon'))) {
      if (imageUrl.startsWith('http') && !imageUrl.includes('gabon24-7.netlify.app')) {
        const encodedUrl = encodeURIComponent(imageUrl);
        imageUrl = `https://gabon24-7.netlify.app/.netlify/functions/image-proxy?url=${encodedUrl}`;
      }
    }
    
    return imageUrl;
  }
  
  return null;
}

// Fonction pour générer des keywords automatiquement
function extractKeywords(title, description, content) {
  if (!title && !description && !content) return [];
  
  const text = `${title || ''} ${description || ''} ${content || ''}`.toLowerCase();
  
  // Mots-clés spécifiques au Gabon et à l'actualité
  const keywordPatterns = [
    // Politique & Gouvernement
    'président', 'gouvernement', 'ministre', 'assemblée nationale', 'sénat', 'élection', 
    'politique', 'parti', 'opposition', 'démocratie', 'constitution', 'loi',
    
    // Économie & Business
    'économie', 'économique', 'business', 'entreprise', 'investissement', 'budget', 
    'finances', 'banque', 'commerce', 'marché', 'industrie', 'développement',
    
    // Secteurs clés du Gabon
    'pétrole', 'pétrolier', 'total', 'shell', 'énergie', 'mines', 'minerai', 
    'bois', 'forestier', 'agriculture', 'pêche', 'tourisme', 'infrastructure',
    
    // Social & Société
    'santé', 'éducation', 'université', 'école', 'hôpital', 'médecine', 
    'emploi', 'jeunesse', 'formation', 'culture', 'sport', 'société',
    
    // Villes & Régions
    'libreville', 'port-gentil', 'franceville', 'oyem', 'lambaréné', 'mouila', 
    'tchibanga', 'bitam', 'gamba', 'makokou', 'estuaire', 'haut-ogooué',
    
    // International
    'france', 'chine', 'usa', 'cemac', 'union européenne', 'afrique', 
    'coopération', 'partenariat', 'accord', 'traité'
  ];
  
  const foundKeywords = [];
  
  // Recherche des mots-clés dans le texte
  keywordPatterns.forEach(keyword => {
    if (text.includes(keyword)) {
      foundKeywords.push(keyword);
    }
  });
  
  // Extraction de mots importants (noms propres, mots de plus de 5 lettres)
  const words = text.match(/\b[a-zàâäéèêëïîôöùûüÿç]{5,}\b/gi) || [];
  const additionalKeywords = words
    .filter(word => !foundKeywords.includes(word.toLowerCase()))
    .slice(0, 5); // Max 5 mots supplémentaires
  
  return [...foundKeywords, ...additionalKeywords].slice(0, 10); // Max 10 keywords
}

// Fonctions utilitaires pour le bundle RSS
async function enhancedExtractSourceFromLink(link, articleContent = null) {
  if (!link) return 'Source inconnue';
  
  try {
    const url = new URL(link);
    let domain = url.hostname.toLowerCase().replace(/^(www\.|m\.|mobile\.|amp\.)/, '');
    
    // Niveau 1: Mapping existant rapide
    const mappedSource = getExistingMapping(domain, url.pathname);
    if (mappedSource !== domain) {
      return mappedSource;
    }
    
    // Niveau 2: Transformation intelligente du domaine
    const transformedSource = smartDomainTransform(domain);
    if (transformedSource !== domain && transformedSource.length > 3) {
      return transformedSource;
    }
    
    return domain;
    
  } catch (error) {
    return 'Source inconnue';
  }
}

function getExistingMapping(domain, path = '') {
    
    // Pour Facebook, vérifier le path complet pour identifier le ministère/page
    if (domain.includes('facebook.com') && path) {
      const fbPath = path.split('/')[1]; // Récupérer le nom de la page
      if (fbPath) {
        // Mapping spécifique pour les pages Facebook
        const fbPages = {
          'CommunicationGOUVGA': 'Communication Gouvernementale',
          'tvgabon24': 'Gabon 24',
          'AgricultureGOUVGA': 'Ministère de l\'Agriculture',
          'NumeriqueGOUVGA': 'Ministère de l\'Economie Numérique',
          'EducationGOUVGA': 'Ministère de l\'Education Nationale',
          'EsupGOUVGA': 'Ministère de l\'Enseignement Supérieur',
          'ministereindustriegabon': 'Ministère de l\'Industrie',
          'InterieurGOUVGA': 'Ministère de l\'Intérieur',
          'CommunicationEnGOUVGA': 'Ministère de la Communication',
          'JusticeGOUVGA': 'Ministère de la Justice',
          'MinesGOUVGA': 'Ministère des Mines',
          'TransportsGOUVGA': 'Ministère des Transports',
          'EquipementGOUVGA': 'Ministère des Travaux Publics',
          'CommercePmePmiGOUVGA': 'Ministère du Commerce',
          'PetroleGOUVGA': 'Ministère du Pétrole',
          'TourismeGOUVGA': 'Ministère du Tourisme',
          'TravailGOUVGA': 'Ministère du Travail'
        };
        
        if (fbPages[fbPath]) {
          return fbPages[fbPath];
        }
      }
    }
    
    const sourceMap = {
      // Sources d'actualités principales
      'echosdeleco.com': 'Echos de l\'Eco',
      'gabonactu.com': 'Gabon Actu',
      'agpgabon.ga': 'AGP - Agence Gabonaise de Presse',
      'gabonallsport.com': 'Gabon All Sport',
      'gaboneco.com': 'GabonEco',
      'mediapostegabon.com': 'MediaPost Gabon',
      'union.sonapresse.com': "L'Union",
      '7joursinfo.com': '7 Jours Info',
      'gabonmediatime.com': 'Gabon Media Time',
      'gabonmailinfos.com': 'Gabon Mail Infos',
      'africaintelligence.fr': 'Africa Intelligence',
      'agencequateur.com': 'Agence Equateur',
      'courrierdesjournalistes.net': 'Courrier des Journalistes',
      'directinfosgabon.com': 'Direct Infos Gabon',
      'focusgroupemedia.com': 'Focus Groupe Media',
      'afrique.latribune.fr': 'La Tribune Afrique',
      'rfi.fr': 'RFI',
      'gabonews.com': 'Gabonews',
      'depeches241.com': 'Dépêches 241',
      'fr.infosgabon.com': 'InfosGabon',
      'infosgabon.com': 'InfosGabon',
      'insidenews241.com': 'Inside News 241',
      'journaldugabon.com': 'Journal du Gabon',
      'kongossanews.info': 'Kongossa News',
      'letouracovert.com': 'Le Touraco Vert',
      'sport241.com': 'Sport 241',
      
      // Sources génériques
      'facebook.com': 'Facebook',
      'youtube.com': 'YouTube',
      
      // Anciennes sources (au cas où)
      'gabonreview.com': 'Gabon Review',
      'infogabon.ga': 'Info Gabon',
      'directinfos.ga': 'Direct Infos',
      'legabonais.com': 'Le Gabonais',
      'alibreville.com': 'A Libreville',
      'lequotidien-ga.com': 'Le Quotidien',
      'agp.ga': 'AGP'
    };
    
    // Vérification avec le mapping puis fallback par correspondance partielle
    if (sourceMap[domain]) {
      return sourceMap[domain];
    }
    
    // Fallback: chercher une correspondance partielle pour les domaines complexes
    for (const [mappedDomain, sourceName] of Object.entries(sourceMap)) {
      if (domain.includes(mappedDomain) || mappedDomain.includes(domain)) {
        return sourceName;
      }
    }
    
    return domain;
}

// Transformation intelligente du domaine
function smartDomainTransform(domain) {
  // Supprimer TLD et nettoyer
  let name = domain
    .replace(/\.(com|ga|net|org|info|fr)$/i, '')
    .replace(/^(www|m|mobile|amp)\./, '');
  
  // Transformations spéciales pour le Gabon
  name = name
    .replace(/gabon/gi, 'Gabon')
    .replace(/241/g, '241')
    .replace(/news/gi, 'News')
    .replace(/info/gi, 'Info')
    .replace(/media/gi, 'Media')
    .replace(/journal/gi, 'Journal')
    .replace(/presse/gi, 'Presse');
  
  // Diviser sur les délimiteurs et capitaliser
  const words = name.split(/[-_.]/).filter(word => word.length > 0);
  
  if (words.length > 1) {
    return words.map(word => 
      word.charAt(0).toUpperCase() + word.slice(1).toLowerCase()
    ).join(' ');
  }
  
  // Si un seul mot, capitaliser proprement
  if (name.length > 3) {
    return name.charAt(0).toUpperCase() + name.slice(1).toLowerCase();
  }
  
  return domain; // Fallback
}

function processImageUrl(imageUrl, articleLink) {
  if (!imageUrl) return null;
  
  try {
    // Utiliser le proxy pour Info Gabon, Gabon 24 et Gabon Actu
    if (articleLink && (articleLink.includes('infogabon.ga') || 
                       articleLink.includes('tvgabon24.com') ||
                       articleLink.includes('gabon24.com') ||
                       articleLink.includes('gabonactu.com'))) {
      const encodedUrl = encodeURIComponent(imageUrl);
      return `/.netlify/functions/image-proxy?url=${encodedUrl}`;
    }
    
    return imageUrl;
  } catch (error) {
    return imageUrl;
  }
}

// Synchronisation RSS optimisée avec bundle RSS.app
async function syncRSSFeedsOptimized() {
  try {
    console.log('🚀 Synchronisation RSS bundle démarrée...');
    
    const startTime = Date.now();
    let totalNewArticles = 0;
    let existingArticles = 0;
    const errors = [];
    
    let rssFeed;
    try {
      rssFeed = await parser.parseURL(RSS_BUNDLE_URL);
      console.log(`📰 ${rssFeed.items?.length || 0} articles trouvés dans le bundle`);
    } catch (parseError) {
      throw new Error(`Erreur parsing bundle RSS: ${parseError.message}`);
    }
    
    // Traiter ABSOLUMENT TOUS les articles du bundle (RSS.app limite à 50)
    const articlesToProcess = rssFeed.items || [];
    console.log(`🔄 Synchronisation de ${articlesToProcess.length} articles du bundle RSS.app`);
    
    for (const item of articlesToProcess) {
      try {
        // Extraire la source depuis l'URL avec méthode améliorée
        const source = await enhancedExtractSourceFromLink(item.link, item.content);
        const externalId = item.guid || item.link || `bundle-${Date.now()}-${Math.random()}`;
        
        // Vérifier si l'article existe déjà par URL ou external_id
        const { data: existingArticle } = await supabase
          .from('articles')
          .select('id')
          .or(`url.eq.${item.link},external_id.eq.${externalId}`)
          .maybeSingle();
        
        if (existingArticle) {
          existingArticles++;
          continue;
        }
        
        // Extraire l'image
        const imageUrl = processImageUrl(extractImageFromContent(item.content, item.contentSnippet, source), item.link);
        
        // Insérer le nouvel article sans résumé IA
        const { error: insertError } = await supabase
          .from('articles')
          .insert({
            external_id: externalId,
            title: item.title,
            summary: item.contentSnippet || item.content?.substring(0, 500),
            ai_summary: null,
            content: item.content || item.contentSnippet,
            url: item.link,
            image_url: imageUrl,
            author: item.creator || item['dc:creator'] || 'Rédaction',
            published_at: item.pubDate ? new Date(item.pubDate).toISOString() : new Date().toISOString(),
            category: 'Actualités',
            is_published: true,
            view_count: 0,
            read_time_minutes: 2,
            sentiment: 'neutre',
            keywords: extractKeywords(item.title, item.contentSnippet || item.summary, item.content)
          });
        
        if (insertError) {
          console.warn(`⚠️ Erreur insertion article: ${insertError.message}`);
          continue;
        }
        
        totalNewArticles++;
        console.log(`✅ Article ajouté: ${item.title?.substring(0, 50)}...`);
        
        // Déclencher le traitement des alertes pour ce nouvel article
        try {
          const alertResponse = await fetch(`${process.env.URL}/.netlify/functions/process-alert-matches`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ article_ids: [data.id] })
          });
          
          if (alertResponse.ok) {
            const alertResult = await alertResponse.json();
            if (alertResult.total_matches > 0) {
              console.log(`🎯 ${alertResult.total_matches} correspondance(s) d'alerte trouvée(s) pour cet article`);
            }
          }
        } catch (alertError) {
          console.warn(`⚠️ Erreur traitement alertes: ${alertError.message}`);
        }
        
        // Ajouter à la queue pour traitement IA différé (sans attendre)
        const queueInsert = async () => {
          try {
            await supabase
              .from('pending_ai_summaries')
              .insert({
                article_external_id: externalId,
                status: 'pending',
                created_at: new Date().toISOString()
              });
          } catch (err) {
            console.warn(`⚠️ Erreur queue IA: ${err.message}`);
          }
        };
        queueInsert(); // Exécuter sans attendre
        
      } catch (itemError) {
        console.warn(`⚠️ Erreur traitement article: ${itemError.message}`);
        errors.push(`Article: ${itemError.message}`);
        continue;
      }
    }
    
    const duration = Date.now() - startTime;
    
    // Log de fin de synchronisation
    const logData = {
      sync_type: 'rss_bundle_optimized',
      total_articles: totalNewArticles,
      errors: errors.length,
      duration_ms: duration,
      status: errors.length > 0 ? 'partial_success' : 'success'
    };
    
    const { error: logError } = await supabase
      .from('sync_logs')
      .insert(logData);
    
    if (logError) {
      console.warn('Erreur log sync:', logError.message);
    }
    
    console.log(`🎉 Synchronisation terminée: ${totalNewArticles} nouveaux articles en ${Math.round(duration/1000)}s`);
    
    return {
      success: true,
      newArticles: totalNewArticles,
      errors: errors.length,
      duration: Math.round(duration/1000),
      message: `Bundle RSS synchronisé avec succès: ${totalNewArticles} nouveaux articles`
    };
    
  } catch (error) {
    console.error('❌ Erreur synchronisation RSS bundle:', error);
    
    // Log d'erreur
    const { error: logInsertError } = await supabase
      .from('sync_logs')
      .insert({
        sync_type: 'rss_bundle_optimized',
        total_articles: 0,
        errors: 1,
        duration_ms: 0,
        status: 'error',
        details: { error_message: error.message }
      });
    
    if (logInsertError) {
      console.warn('Erreur log sync:', logInsertError.message);
    }
    
    return {
      success: false,
      error: error.message,
      newArticles: 0
    };
  }
}

exports.handler = async (event, context) => {
  context.callbackWaitsForEmptyEventLoop = false;
  
  const headers = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'Content-Type',
    'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
    'Content-Type': 'application/json'
  };

  if (event.httpMethod === 'OPTIONS') {
    return { statusCode: 200, headers, body: '' };
  }

  try {
    if (!supabaseUrl || !supabaseServiceKey) {
      return {
        statusCode: 500,
        headers,
        body: JSON.stringify({
          success: false,
          error: 'Configuration manquante'
        })
      };
    }
    
    // Synchronisation optimisée avec timeout de 9 minutes
    const result = await Promise.race([
      syncRSSFeedsOptimized(),
      new Promise((_, reject) => 
        setTimeout(() => reject(new Error('Timeout fonction')), 540000) // 9 minutes
      )
    ]);
    
    return {
      statusCode: 200,
      headers,
      body: JSON.stringify({
        success: true,
        message: result.message,
        newArticles: result.newArticles,
        processedFeeds: result.processedFeeds,
        errorCount: result.errorCount,
        duration: result.duration,
        timestamp: new Date().toISOString()
      })
    };
    
  } catch (error) {
    console.error('❌ Erreur handler:', error);
    
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({
        success: false,
        error: 'Erreur synchronisation RSS',
        message: error.message
      })
    };
  }
};
