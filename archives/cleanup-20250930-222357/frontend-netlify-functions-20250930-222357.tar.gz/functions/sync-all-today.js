const Parser = require('rss-parser');
const { createClient } = require('@supabase/supabase-js');

const supabaseUrl = process.env.SUPABASE_URL;
const supabaseServiceKey = process.env.SUPABASE_SERVICE_ROLE_KEY;
const supabase = createClient(supabaseUrl, supabaseServiceKey);

const parser = new Parser({
  timeout: 20000,
  headers: {
    'User-Agent': 'Gabon24-7-RSS-Reader/1.0'
  }
});

const RSS_BUNDLE_URL = 'https://rss.app/feeds/_SntJgjZXkqIWrDHq.xml';

function extractSourceFromLink(link) {
  if (!link) return 'Source inconnue';
  
  try {
    const url = new URL(link);
    const domain = url.hostname.toLowerCase();
    
    const sourceMap = {
      // Sources d'actualités principales
      'echosdeleco.com': 'Echos de l\'Eco',
      'gabonactu.com': 'Gabon Actu',
      'agpgabon.ga': 'AGP - Agence Gabonaise de Presse',
      'gabonallsport.com': 'Gabon All Sport',
      'gaboneco.com': 'GabonEco',
      'mediapostegabon.com': 'MediaPost Gabon',
      'union.sonapresse.com': "L'Union",
      '7joursinfo.com': '7 Jours Info',
      'gabonmediatime.com': 'Gabon Media Time',
      'africaintelligence.fr': 'Africa Intelligence',
      'agencequateur.com': 'Agence Equateur',
      'courrierdesjournalistes.net': 'Courrier des Journalistes',
      'directinfosgabon.com': 'Direct Infos Gabon',
      'focusgroupemedia.com': 'Focus Groupe Media',
      'afrique.latribune.fr': 'La Tribune Afrique',
      'rfi.fr': 'RFI',
      'gabonews.com': 'Gabonews',
      'depeches241.com': 'Dépêches 241',
      'fr.infosgabon.com': 'Infos Gabon',
      'infosgabon.com': 'Infos Gabon',
      'insidenews241.com': 'Inside News 241',
      'journaldugabon.com': 'Journal du Gabon',
      'kongossanews.info': 'Kongossa News',
      'letouracovert.com': 'Le Touraco Vert',
      'sport241.com': 'Sport 241',
      
      // Pages Facebook gouvernementales
      'facebook.com/CommunicationGOUVGA': 'Communication Gouvernementale',
      'facebook.com/tvgabon24': 'Gabon 24',
      'facebook.com/AgricultureGOUVGA': 'Ministère de l\'Agriculture',
      'facebook.com/NumeriqueGOUVGA': 'Ministère de l\'Economie Numérique',
      'facebook.com/EducationGOUVGA': 'Ministère de l\'Education Nationale',
      'facebook.com/EsupGOUVGA': 'Ministère de l\'Enseignement Supérieur',
      'facebook.com/ministereindustriegabon': 'Ministère de l\'Industrie',
      'facebook.com/InterieurGOUVGA': 'Ministère de l\'Intérieur',
      'facebook.com/CommunicationEnGOUVGA': 'Ministère de la Communication',
      'facebook.com/JusticeGOUVGA': 'Ministère de la Justice',
      'facebook.com/MinesGOUVGA': 'Ministère des Mines',
      'facebook.com/TransportsGOUVGA': 'Ministère des Transports',
      'facebook.com/EquipementGOUVGA': 'Ministère des Travaux Publics',
      'facebook.com/CommercePmePmiGOUVGA': 'Ministère du Commerce',
      'facebook.com/PetroleGOUVGA': 'Ministère du Pétrole',
      'facebook.com/TourismeGOUVGA': 'Ministère du Tourisme',
      'facebook.com/TravailGOUVGA': 'Ministère du Travail',
      
      // Sources génériques
      'facebook.com': 'Facebook',
      'youtube.com': 'YouTube',
      
      // Anciennes sources (au cas où)
      'gabonreview.com': 'Gabon Review',
      'infogabon.ga': 'Info Gabon',
      'directinfos.ga': 'Direct Infos',
      'legabonais.com': 'Le Gabonais',
      'alibreville.com': 'A Libreville',
      'lequotidien-ga.com': 'Le Quotidien',
      'agp.ga': 'AGP'
    };
    
    return sourceMap[domain] || domain;
  } catch (error) {
    return 'Source inconnue';
  }
}

function processImageUrl(imageUrl, articleLink) {
  if (!imageUrl) return null;
  
  try {
    if (articleLink && articleLink.includes('infogabon.ga')) {
      const encodedUrl = encodeURIComponent(imageUrl);
      return `/.netlify/functions/image-proxy?url=${encodedUrl}`;
    }
    
    return imageUrl;
  } catch (error) {
    return imageUrl;
  }
}

exports.handler = async (event, context) => {
  context.callbackWaitsForEmptyEventLoop = false;
  
  const headers = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'Content-Type',
    'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
    'Content-Type': 'application/json'
  };

  if (event.httpMethod === 'OPTIONS') {
    return { statusCode: 200, headers, body: '' };
  }

  console.log('🚀 Synchronisation complète du bundle RSS démarrée');
  const startTime = Date.now();
  
  try {
    // Récupérer ABSOLUMENT TOUS les articles du bundle RSS sans aucune limite
    console.log('📡 Récupération COMPLETE du bundle:', RSS_BUNDLE_URL);
    const feed = await parser.parseURL(RSS_BUNDLE_URL);
    
    console.log(`📰 Bundle parsé: ${feed.items?.length || 0} articles trouvés`);
    
    let newArticles = 0;
    let processedArticles = 0;
    let skippedArticles = 0;
    const errors = [];
    
    // Traiter ABSOLUMENT TOUS les articles sans exception ni limite
    console.log(`📊 Traitement de ${feed.items.length} articles au total`);
    for (const item of feed.items) {
      try {
        processedArticles++;
        
        if (!item.link) {
          console.log(`⚠️ Article sans lien ignoré: ${item.title}`);
          skippedArticles++;
          continue;
        }
        
        // Vérifier si l'article existe déjà par lien
        const { data: existingArticle } = await supabase
          .from('articles')
          .select('id')
          .eq('url', item.link)
          .single();
        
        if (existingArticle) {
          console.log(`📋 Article existant: ${item.title?.substring(0, 50)}...`);
          skippedArticles++;
          continue;
        }
        
        // Extraire les données
        const title = item.title || 'Titre non disponible';
        const content = item.contentSnippet || item.content || item.summary || '';
        const pubDate = item.pubDate ? new Date(item.pubDate).toISOString() : new Date().toISOString();
        const source = extractSourceFromLink(item.link);
        const imageUrl = processImageUrl(item.enclosure?.url || item.image?.url, item.link);
        
        // Insérer l'article
        const { data: insertedArticle, error: insertError } = await supabase
          .from('articles')
          .insert({
            title: title,
            content: content,
            url: item.link,
            published_at: pubDate,
            image_url: imageUrl,
            summary: content.substring(0, 300) || '',
            external_id: item.guid || item.link || `bundle-${Date.now()}-${Math.random()}`,
            category: 'Actualités',
            author: item.creator || source,
            view_count: 0,
            sentiment: 'neutre',
            keywords: [],
            read_time_minutes: 2
          })
          .select('id')
          .single();
        
        if (insertError) {
          console.error('❌ Erreur insertion:', insertError.message);
          errors.push(`Erreur insertion: ${insertError.message}`);
        } else {
          newArticles++;
          console.log(`✅ Nouvel article: ${title.substring(0, 50)}...`);
          
          // Ajouter à la queue IA (sans attendre)
          if (insertedArticle?.id) {
            supabase
              .from('pending_ai_summaries')
              .insert({
                article_external_id: item.guid || item.link,
                status: 'pending',
                created_at: new Date().toISOString()
              })
              .catch(err => console.warn('⚠️ Erreur queue IA:', err.message));
          }
        }
        
      } catch (itemError) {
        console.error('❌ Erreur traitement article:', itemError.message);
        errors.push(`Article error: ${itemError.message}`);
      }
    }
    
    const duration = Date.now() - startTime;
    
    // Log des statistiques
    try {
      await supabase
        .from('sync_logs')
        .insert({
          sync_type: 'manual_complete_sync',
          feeds_processed: 1,
          articles_extracted: newArticles,
          success_count: 1,
          error_count: errors.length,
          errors: errors,
          duration_ms: duration,
          created_at: new Date().toISOString()
        });
    } catch (logError) {
      console.error('❌ Erreur log:', logError);
    }
    
    const result = {
      success: true,
      message: `Synchronisation complète terminée: ${newArticles} nouveaux articles sur ${processedArticles} traités`,
      bundle_url: RSS_BUNDLE_URL,
      total_items_in_feed: feed.items?.length || 0,
      processed: processedArticles,
      new_articles: newArticles,
      existing_articles: skippedArticles,
      duration_ms: duration,
      errors: errors.length > 0 ? errors : undefined,
      timestamp: new Date().toISOString()
    };
    
    console.log('📊 Résultat synchronisation complète:', result);
    
    return {
      statusCode: 200,
      headers,
      body: JSON.stringify(result, null, 2)
    };
    
  } catch (error) {
    console.error('❌ Erreur synchronisation bundle:', error);
    
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({
        success: false,
        error: 'Erreur synchronisation bundle RSS',
        message: error.message,
        timestamp: new Date().toISOString()
      })
    };
  }
};
