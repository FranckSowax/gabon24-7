const { createClient } = require('@supabase/supabase-js');

const supabaseUrl = process.env.SUPABASE_URL;
const supabaseServiceKey = process.env.SUPABASE_SERVICE_ROLE_KEY;

if (!supabaseUrl || !supabaseServiceKey) {
  console.error('Missing Supabase environment variables');
}

const supabase = createClient(supabaseUrl, supabaseServiceKey);

exports.handler = async (event, context) => {
  // Headers CORS
  const headers = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'Content-Type',
    'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
    'Content-Type': 'application/json'
  };

  if (event.httpMethod === 'OPTIONS') {
    return { statusCode: 200, headers, body: '' };
  }

  try {
    // 1. Créer une alerte de test si elle n'existe pas
    const testUserId = '550e8400-e29b-41d4-a716-446655440000';
    const testAlertId = '550e8400-e29b-41d4-a716-446655440001';
    
    const { data: existingAlert } = await supabase
      .from('user_alerts')
      .select('*')
      .eq('id', testAlertId)
      .single();

    if (!existingAlert) {
      const { error: insertError } = await supabase
        .from('user_alerts')
        .insert({
          id: testAlertId,
          user_id: testUserId,
          name: 'Test Alerte Gabon',
          keywords: ['Gabon', 'président', 'économie', 'gouvernement'],
          delivery_channels: { email: true, whatsapp: false },
          email_address: 'test@example.com',
          is_active: true,
          created_at: new Date().toISOString()
        });

      if (insertError) {
        console.warn('Erreur création alerte test:', insertError.message);
      } else {
        console.log('✅ Alerte de test créée');
      }
    }

    // 2. Vérifier les articles récents avec keywords
    const { data: articles, error: articlesError } = await supabase
      .from('articles')
      .select('id, title, summary, keywords, published_at')
      .order('published_at', { ascending: false })
      .limit(10);

    if (articlesError) {
      throw articlesError;
    }

    // 3. Tester le matching avec l'alerte
    const testKeywords = ['Gabon', 'président', 'économie', 'gouvernement'];
    const matches = [];

    for (const article of articles) {
      const title = (article.title || '').toLowerCase();
      const summary = (article.summary || '').toLowerCase();
      const articleKeywords = (article.keywords || []).map(k => k.toLowerCase());
      
      const matchedKeywords = [];
      let totalScore = 0;

      for (const keyword of testKeywords) {
        const keywordLower = keyword.toLowerCase();
        let keywordScore = 0;
        
        // Recherche dans le titre (poids fort: 3x)
        if (title.includes(keywordLower)) {
          const titleOccurrences = (title.match(new RegExp(keywordLower, 'g')) || []).length;
          keywordScore += titleOccurrences * 0.3;
        }
        
        // Recherche dans le résumé (poids moyen: 2x)
        if (summary.includes(keywordLower)) {
          const summaryOccurrences = (summary.match(new RegExp(keywordLower, 'g')) || []).length;
          keywordScore += summaryOccurrences * 0.2;
        }
        
        // Recherche dans les keywords de l'article (poids fort: 3x)
        if (articleKeywords.some(ak => ak.includes(keywordLower))) {
          keywordScore += 0.3;
        }
        
        if (keywordScore > 0) {
          matchedKeywords.push(keyword);
          totalScore += keywordScore;
        }
      }

      if (matchedKeywords.length > 0) {
        const keywordRatio = matchedKeywords.length / testKeywords.length;
        const confidenceScore = Math.min(totalScore * keywordRatio, 0.95);
        
        matches.push({
          article_id: article.id,
          article_title: article.title,
          matched_keywords: matchedKeywords,
          confidence_score: confidenceScore,
          published_at: article.published_at
        });
      }
    }

    // 4. Informations système
    const { data: alertStats } = await supabase
      .from('user_alerts')
      .select('id, name, is_active')
      .limit(5);

    const { data: matchStats } = await supabase
      .from('alert_matches')
      .select('id, confidence_score, created_at')
      .order('created_at', { ascending: false })
      .limit(5);

    return {
      statusCode: 200,
      headers,
      body: JSON.stringify({
        success: true,
        system_status: {
          articles_checked: articles.length,
          articles_with_keywords: articles.filter(a => a.keywords && a.keywords.length > 0).length,
          total_alerts: alertStats?.length || 0,
          recent_matches: matchStats?.length || 0
        },
        test_results: {
          test_alert_created: !existingAlert,
          matches_found: matches.length,
          matches: matches.slice(0, 5)
        },
        sample_articles: articles.slice(0, 3).map(a => ({
          title: a.title?.substring(0, 80) + '...',
          keywords_count: (a.keywords || []).length,
          has_keywords: (a.keywords || []).length > 0
        })),
        recent_matches: matchStats || []
      })
    };

  } catch (error) {
    console.error('Error testing alert system:', error);
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({ 
        error: 'Internal server error',
        details: error.message 
      })
    };
  }
};
