const { createClient } = require('@supabase/supabase-js');
const Parser = require('rss-parser');

// Configuration Supabase
const supabaseUrl = process.env.SUPABASE_URL;
const supabaseServiceKey = process.env.SUPABASE_SERVICE_ROLE_KEY;
const openaiApiKey = process.env.OPENAI_API_KEY;

const supabase = createClient(supabaseUrl, supabaseServiceKey);
const parser = new Parser({
  timeout: 15000,
  headers: {
    'User-Agent': 'Gabon24-7 RSS Reader 1.0'
  },
  customFields: {
    feed: [],
    item: []
  }
});

// Fonction pour extraire l'image depuis le contenu HTML avec gestion proxy
function extractImageFromContent(content, description, feedName) {
  if (!content && !description) return null;
  
  const text = content || description || '';
  
  // Recherche d'images dans les balises img
  const imgMatch = text.match(/<img[^>]+src=["']([^"']+)["'][^>]*>/i);
  if (imgMatch) {
    let imageUrl = imgMatch[1];
    
    // Gestion proxy pour Info Gabon
    if (feedName && (feedName.toLowerCase().includes('info') || feedName.toLowerCase().includes('gabon'))) {
      if (imageUrl.startsWith('http') && !imageUrl.includes('gabon24-7.netlify.app')) {
        const encodedUrl = encodeURIComponent(imageUrl);
        imageUrl = `https://gabon24-7.netlify.app/.netlify/functions/image-proxy?url=${encodedUrl}`;
      }
    }
    
    return imageUrl;
  }
  
  // Recherche d'URLs d'images directes
  const urlMatch = text.match(/(https?:\/\/[^\s]+\.(?:jpg|jpeg|png|gif|webp))/i);
  if (urlMatch) {
    let imageUrl = urlMatch[1];
    
    // Gestion proxy pour Info Gabon
    if (feedName && (feedName.toLowerCase().includes('info') || feedName.toLowerCase().includes('gabon'))) {
      if (!imageUrl.includes('gabon24-7.netlify.app')) {
        const encodedUrl = encodeURIComponent(imageUrl);
        imageUrl = `https://gabon24-7.netlify.app/.netlify/functions/image-proxy?url=${encodedUrl}`;
      }
    }
    
    return imageUrl;
  }
  
  return null;
}

// Fonction pour générer un résumé IA avec OpenAI
async function generateAISummary(title, content) {
  if (!openaiApiKey || !content) return null;
  
  try {
    const response = await fetch('https://api.openai.com/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${openaiApiKey}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        model: 'gpt-3.5-turbo',
        messages: [{
          role: 'user',
          content: `Résume cet article en français en 2-3 phrases maximum:\n\nTitre: ${title}\n\nContenu: ${content.substring(0, 1000)}`
        }],
        max_tokens: 150,
        temperature: 0.7
      })
    });
    
    if (response.ok) {
      const data = await response.json();
      return data.choices[0]?.message?.content?.trim() || null;
    }
  } catch (error) {
    console.error('Erreur génération résumé IA:', error);
  }
  
  return null;
}

// Handler pour synchronisation manuelle
exports.handler = async (event, context) => {
  const headers = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'Content-Type',
    'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
    'Content-Type': 'application/json'
  };

  if (event.httpMethod === 'OPTIONS') {
    return { statusCode: 200, headers, body: '' };
  }

  try {
    console.log('🔄 Synchronisation RSS manuelle démarrée...');
    
    // Récupérer les paramètres de la requête
    const { hours_back = '6' } = event.queryStringParameters || {};
    const hoursBack = parseInt(hours_back);
    const cutoffTime = new Date(Date.now() - hoursBack * 60 * 60 * 1000);
    
    console.log(`🕐 Synchronisation des articles depuis ${hoursBack}h (${cutoffTime.toISOString()})`);
    
    // Récupérer tous les flux RSS actifs, en priorisant ceux jamais traités ou les plus anciens
    const { data: feeds, error: feedsError } = await supabase
      .from('rss_feeds')
      .select('*')
      .eq('status', 'active')
      .order('last_fetch_at', { ascending: true, nullsFirst: true }) // Flux jamais traités en premier
      .order('priority', { ascending: false });
    
    if (feedsError) {
      throw feedsError;
    }
    
    let totalNewArticles = 0;
    const processedFeeds = [];
    
    for (const feed of feeds || []) {
      try {
        console.log(`📡 Processing: ${feed.name}`);
        
        // Parser le flux RSS avec gestion d'erreur améliorée
        let rssFeed;
        try {
          rssFeed = await parser.parseURL(feed.url);
        } catch (parseError) {
          // Ignorer les erreurs de parsing XML malformé et continuer
          if (parseError.message.includes('Invalid character in entity name') || 
              parseError.message.includes('Status code 403')) {
            console.warn(`⚠️ Flux RSS ignoré (${feed.name}): ${parseError.message}`);
            processedFeeds.push({
              name: feed.name,
              newArticles: 0,
              status: 'skipped',
              error: parseError.message
            });
            continue;
          }
          throw parseError; // Re-lancer les autres erreurs
        }
        let feedNewArticles = 0;
        
        for (const item of rssFeed.items || []) {
          try {
            // Filtrer les articles par date - seulement ceux des X dernières heures
            const articleDate = item.pubDate ? new Date(item.pubDate) : new Date();
            if (articleDate < cutoffTime) {
              continue; // Article trop ancien, ignorer
            }
            
            // Créer un external_id unique basé sur le contenu
            const externalId = item.guid || item.link || `${feed.id}-${Date.now()}-${Math.random()}`;
            
            // Vérifier si l'article existe déjà avec external_id
            const { data: existingArticle } = await supabase
              .from('articles')
              .select('id')
              .eq('feed_id', feed.id)
              .eq('external_id', externalId)
              .single();
            
            if (existingArticle) {
              continue; // Article déjà existant
            }
            
            // Extraire l'image avec gestion proxy
            const imageUrl = extractImageFromContent(item.content, item.contentSnippet, feed.name);
            
            // Pas de résumé IA pour éviter les rate limits OpenAI lors de la sync manuelle
            const aiSummary = null;
            
            // Insérer le nouvel article avec UPSERT pour éviter les doublons
            const { error: insertError } = await supabase
              .from('articles')
              .upsert({
                feed_id: feed.id,
                external_id: externalId,
                title: item.title,
                summary: item.contentSnippet || item.content?.substring(0, 500),
                ai_summary: aiSummary,
                content: item.content || item.contentSnippet,
                url: item.link,
                image_url: imageUrl,
                author: item.creator || item['dc:creator'] || 'Rédaction',
                published_at: item.pubDate ? new Date(item.pubDate).toISOString() : new Date().toISOString(),
                category: feed.category || 'actualités',
                is_published: true,
                view_count: 0
              }, {
                onConflict: 'feed_id,external_id',
                ignoreDuplicates: true
              });
            
            if (!insertError) {
              feedNewArticles++;
              totalNewArticles++;
              console.log(`✅ Nouvel article: ${item.title}`);
            }
            
          } catch (articleError) {
            console.error(`❌ Erreur article ${item.title}:`, articleError);
          }
        }
        
        processedFeeds.push({
          name: feed.name,
          newArticles: feedNewArticles,
          status: 'success',
          lastFetch: feed.last_fetch_at,
          neverProcessed: !feed.last_fetch_at
        });
        
        // Mettre à jour la date de dernière synchronisation
        await supabase
          .from('rss_feeds')
          .update({ last_fetch_at: new Date().toISOString() })
          .eq('id', feed.id);
          
      } catch (feedError) {
        console.error(`❌ Erreur feed ${feed.name}:`, feedError);
        processedFeeds.push({
          name: feed.name,
          newArticles: 0,
          status: 'error',
          error: feedError.message
        });
      }
    }
    
    return {
      statusCode: 200,
      headers,
      body: JSON.stringify({
        success: true,
        message: `Synchronisation manuelle terminée: ${totalNewArticles} nouveaux articles`,
        totalNewArticles,
        processedFeeds,
        timestamp: new Date().toISOString()
      })
    };
    
  } catch (error) {
    console.error('❌ Erreur synchronisation manuelle:', error);
    
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({
        success: false,
        error: 'Erreur synchronisation RSS',
        message: error.message
      })
    };
  }
};
