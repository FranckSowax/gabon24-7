const { createClient } = require('@supabase/supabase-js');
const Parser = require('rss-parser');

// Configuration Supabase
const supabaseUrl = process.env.SUPABASE_URL;
const supabaseServiceKey = process.env.SUPABASE_SERVICE_ROLE_KEY;

if (!supabaseUrl || !supabaseServiceKey) {
  console.error('❌ Variables d\'environnement manquantes');
}

const supabase = createClient(supabaseUrl, supabaseServiceKey);
const parser = new Parser({
  timeout: 8000,
  headers: {
    'User-Agent': 'Gabon24-7 RSS Monitor 1.0'
  }
});

// Fonction pour tester un flux RSS
async function testRSSFeed(feed) {
  try {
    console.log(`🔍 Test du flux: ${feed.name}`);
    
    const startTime = Date.now();
    const rssFeed = await parser.parseURL(feed.url);
    const responseTime = Date.now() - startTime;
    
    const itemsCount = rssFeed.items ? rssFeed.items.length : 0;
    const lastItemDate = itemsCount > 0 ? rssFeed.items[0].pubDate : null;
    
    // Mettre à jour le statut du flux
    await supabase
      .from('rss_feeds')
      .update({
        status: 'active',
        last_success_at: new Date().toISOString(),
        last_error: null,
        updated_at: new Date().toISOString()
      })
      .eq('id', feed.id);
    
    return {
      feedId: feed.id,
      name: feed.name,
      url: feed.url,
      status: 'success',
      responseTime: responseTime,
      itemsCount: itemsCount,
      lastItemDate: lastItemDate,
      title: rssFeed.title || 'N/A',
      description: rssFeed.description || 'N/A'
    };
    
  } catch (error) {
    console.error(`❌ Erreur flux ${feed.name}:`, error.message);
    
    // Mettre à jour le statut d'erreur
    await supabase
      .from('rss_feeds')
      .update({
        status: 'error',
        last_error: error.message,
        updated_at: new Date().toISOString()
      })
      .eq('id', feed.id);
    
    return {
      feedId: feed.id,
      name: feed.name,
      url: feed.url,
      status: 'error',
      error: error.message,
      responseTime: null,
      itemsCount: 0,
      lastItemDate: null
    };
  }
}

// Handler Netlify pour monitoring des flux RSS
exports.handler = async (event, context) => {
  context.callbackWaitsForEmptyEventLoop = false;
  
  const headers = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'Content-Type',
    'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
    'Content-Type': 'application/json'
  };

  if (event.httpMethod === 'OPTIONS') {
    return { statusCode: 200, headers, body: '' };
  }

  try {
    console.log('🚀 Monitoring des flux RSS démarré');
    
    // Récupérer tous les flux RSS
    const { data: feeds, error: feedsError } = await supabase
      .from('rss_feeds')
      .select('*')
      .order('priority', { ascending: false });
    
    if (feedsError) {
      throw feedsError;
    }
    
    console.log(`📡 ${feeds?.length || 0} flux RSS à tester`);
    
    // Tester chaque flux
    const results = [];
    let successCount = 0;
    let errorCount = 0;
    
    for (const feed of feeds || []) {
      const result = await testRSSFeed(feed);
      results.push(result);
      
      if (result.status === 'success') {
        successCount++;
      } else {
        errorCount++;
      }
      
      // Petite pause entre les tests
      await new Promise(resolve => setTimeout(resolve, 500));
    }
    
    // Statistiques globales
    const totalFeeds = feeds?.length || 0;
    const successRate = totalFeeds > 0 ? (successCount / totalFeeds * 100).toFixed(1) : 0;
    
    // Grouper les résultats par statut
    const successfulFeeds = results.filter(r => r.status === 'success');
    const errorFeeds = results.filter(r => r.status === 'error');
    
    // Récupérer le nombre d'articles par flux depuis la DB
    const { data: articleCounts } = await supabase
      .from('articles')
      .select('rss_feed_id')
      .not('rss_feed_id', 'is', null);

    const articleCountsByFeed = {};
    if (articleCounts) {
      articleCounts.forEach(article => {
        articleCountsByFeed[article.rss_feed_id] = (articleCountsByFeed[article.rss_feed_id] || 0) + 1;
      });
    }

    // Formater les données pour la page de monitoring
    const feedsForMonitoring = feeds.map(feed => ({
      id: feed.id,
      name: feed.name,
      url: feed.url,
      status: feed.status || 'inactive',
      last_sync: feed.last_success_at || feed.updated_at,
      articles_count: articleCountsByFeed[feed.id] || 0,
      error_message: feed.last_error
    }));

    return {
      statusCode: 200,
      headers,
      body: JSON.stringify({
        success: true,
        message: `Monitoring terminé: ${successCount}/${totalFeeds} flux actifs`,
        summary: {
          totalFeeds: totalFeeds,
          successfulFeeds: successCount,
          errorFeeds: errorCount,
          successRate: `${successRate}%`,
          averageResponseTime: successfulFeeds.length > 0 
            ? Math.round(successfulFeeds.reduce((sum, f) => sum + f.responseTime, 0) / successfulFeeds.length)
            : 0,
          totalArticles: successfulFeeds.reduce((sum, f) => sum + f.itemsCount, 0)
        },
        feeds: feedsForMonitoring,
        detailedResults: {
          successful: successfulFeeds.map(f => ({
            name: f.name,
            url: f.url,
            responseTime: f.responseTime,
            itemsCount: f.itemsCount,
            lastItemDate: f.lastItemDate,
            title: f.title
          })),
          errors: errorFeeds.map(f => ({
            name: f.name,
            url: f.url,
            error: f.error
          }))
        },
        timestamp: new Date().toISOString()
      })
    };
    
  } catch (error) {
    console.error('❌ Erreur monitoring RSS:', error);
    
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({
        success: false,
        error: 'Erreur monitoring RSS',
        message: error.message
      })
    };
  }
};
