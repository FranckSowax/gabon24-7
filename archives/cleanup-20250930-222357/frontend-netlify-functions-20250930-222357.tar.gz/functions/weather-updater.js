// Fonction pour mettre à jour les données météo automatiquement
// Cette fonction peut être appelée par un cron job ou un webhook

exports.handler = async (event, context) => {
  const headers = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'Content-Type',
    'Access-Control-Allow-Methods': 'POST, OPTIONS',
    'Content-Type': 'application/json'
  };

  if (event.httpMethod === 'OPTIONS') {
    return {
      statusCode: 200,
      headers,
      body: ''
    };
  }

  try {
    console.log('🌤️ Mise à jour automatique des données météo...');
    
    // Simuler une mise à jour des données météo
    // Dans un vrai scénario, ici on ferait appel à une vraie API météo
    const updateTimestamp = new Date().toISOString();
    
    // Log de la mise à jour
    console.log(`✅ Données météo mises à jour: ${updateTimestamp}`);
    
    return {
      statusCode: 200,
      headers,
      body: JSON.stringify({
        success: true,
        message: 'Données météo mises à jour avec succès',
        timestamp: updateTimestamp,
        cities_updated: ['Libreville', 'Port-Gentil', 'Franceville', 'Oyem']
      })
    };

  } catch (error) {
    console.error('❌ Erreur lors de la mise à jour météo:', error);
    
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({
        success: false,
        error: 'Erreur lors de la mise à jour météo',
        message: error.message
      })
    };
  }
};
