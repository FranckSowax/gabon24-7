// Synchronisation manuelle directe du bundle RSS
const Parser = require('rss-parser');
const { createClient } = require('@supabase/supabase-js');

const supabaseUrl = process.env.SUPABASE_URL;
const supabaseServiceKey = process.env.SUPABASE_SERVICE_ROLE_KEY;
const supabase = createClient(supabaseUrl, supabaseServiceKey);

const parser = new Parser({
  timeout: 15000,
  headers: {
    'User-Agent': 'Gabon24-7-RSS-Reader/1.0'
  }
});

const RSS_BUNDLE_URL = 'https://rss.app/feeds/_SntJgjZXkqIWrDHq.xml';

function extractSourceFromLink(link) {
  if (!link) return 'Source inconnue';
  
  try {
    const url = new URL(link);
    const domain = url.hostname.toLowerCase();
    
    const sourceMap = {
      'gabonreview.com': 'Gabon Review',
      'infogabon.ga': 'Info Gabon',
      'directinfosgabon.com': 'Direct Infos Gabon',
      'legabonais.com': 'Le Gabonais',
      'alibreville.com': 'A Libreville',
      'gabonmediatime.com': 'Gabon Media Time',
      'lequotidien-ga.com': 'Le Quotidien',
      'union.sonapresse.com': "L'Union",
      '7joursinfo.com': '7 Jours Info',
      'depeches241.com': 'Dépêches 241',
      'facebook.com': 'Facebook'
    };
    
    return sourceMap[domain] || domain;
  } catch (error) {
    return 'Source inconnue';
  }
}

function processImageUrl(imageUrl, articleLink) {
  if (!imageUrl) return null;
  
  try {
    if (articleLink && articleLink.includes('infogabon.ga')) {
      const encodedUrl = encodeURIComponent(imageUrl);
      return `${process.env.URL}/.netlify/functions/image-proxy?url=${encodedUrl}`;
    }
    
    return imageUrl;
  } catch (error) {
    return imageUrl;
  }
}

exports.handler = async (event, context) => {
  const headers = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'Content-Type',
    'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
    'Content-Type': 'application/json'
  };

  if (event.httpMethod === 'OPTIONS') {
    return { statusCode: 200, headers, body: '' };
  }

  console.log('🚀 Synchronisation manuelle directe du bundle RSS démarrée');
  const startTime = Date.now();
  
  try {
    // Récupérer et parser le bundle RSS
    console.log(`📡 Récupération du bundle: ${RSS_BUNDLE_URL}`);
    const feed = await parser.parseURL(RSS_BUNDLE_URL);
    
    console.log(`📰 Bundle parsé: ${feed.items?.length || 0} articles trouvés`);
    
    let newArticles = 0;
    let processedArticles = 0;
    let skippedArticles = 0;
    const errors = [];
    
    // Traiter TOUS les articles du bundle
    const itemsToProcess = feed.items || [];
    
    for (const item of itemsToProcess) {
      try {
        processedArticles++;
        
        if (!item.link) {
          console.log(`⚠️ Article sans lien ignoré: ${item.title}`);
          skippedArticles++;
          continue;
        }
        
        // Vérifier si l'article existe déjà
        const { data: existingArticle } = await supabase
          .from('articles')
          .select('id')
          .eq('link', item.link)
          .single();
        
        if (existingArticle) {
          console.log(`📋 Article existant: ${item.title?.substring(0, 50)}...`);
          skippedArticles++;
          continue;
        }
        
        // Extraire les données
        const title = item.title || 'Titre non disponible';
        const content = item.contentSnippet || item.content || item.summary || '';
        const pubDate = item.pubDate ? new Date(item.pubDate).toISOString() : new Date().toISOString();
        const source = extractSourceFromLink(item.link);
        const imageUrl = processImageUrl(item.enclosure?.url || item.image?.url, item.link);
        
        // Insérer l'article
        const { data: insertedArticle, error: insertError } = await supabase
          .from('articles')
          .insert({
            title: title,
            content: content,
            link: item.link,
            published_at: pubDate,
            source: source,
            image_url: imageUrl,
            summary: content.substring(0, 300) || ''
          })
          .select('id')
          .single();
        
        if (insertError) {
          console.error('❌ Erreur insertion:', insertError.message);
          errors.push(`Erreur insertion: ${insertError.message}`);
        } else {
          newArticles++;
          console.log(`✅ Nouvel article: ${title.substring(0, 50)}...`);
          
          // Ajouter à la queue IA
          if (insertedArticle?.id) {
            try {
              await supabase
                .from('pending_ai_summaries')
                .insert({
                  article_id: insertedArticle.id,
                  priority: 1,
                  status: 'pending',
                  created_at: new Date().toISOString()
                });
            } catch (queueError) {
              console.warn('⚠️ Erreur queue IA:', queueError.message);
            }
          }
        }
        
      } catch (itemError) {
        console.error('❌ Erreur traitement article:', itemError.message);
        errors.push(`Article error: ${itemError.message}`);
      }
    }
    
    const duration = Date.now() - startTime;
    
    // Log des statistiques
    try {
      await supabase
        .from('sync_logs')
        .insert({
          sync_type: 'manual_bundle_full',
          feeds_processed: 1,
          articles_extracted: newArticles,
          success_count: 1,
          error_count: errors.length,
          errors: errors,
          duration_ms: duration,
          created_at: new Date().toISOString()
        });
    } catch (logError) {
      console.error('❌ Erreur log:', logError);
    }
    
    const result = {
      success: true,
      message: `Synchronisation terminée: ${newArticles} nouveaux articles sur ${processedArticles} traités`,
      bundle_url: RSS_BUNDLE_URL,
      total_items_in_feed: feed.items?.length || 0,
      processed: processedArticles,
      new_articles: newArticles,
      existing_articles: skippedArticles,
      duration_ms: duration,
      errors: errors.length > 0 ? errors : undefined,
      timestamp: new Date().toISOString()
    };
    
    console.log('📊 Résultat synchronisation:', result);
    
    return {
      statusCode: 200,
      headers,
      body: JSON.stringify(result)
    };
    
  } catch (error) {
    console.error('❌ Erreur synchronisation bundle:', error);
    
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({
        success: false,
        error: 'Erreur synchronisation bundle RSS',
        message: error.message,
        timestamp: new Date().toISOString()
      })
    };
  }
};
