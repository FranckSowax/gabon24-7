const { createClient } = require('@supabase/supabase-js');

const supabaseUrl = process.env.SUPABASE_URL;
const supabaseServiceKey = process.env.SUPABASE_SERVICE_ROLE_KEY;
const supabase = createClient(supabaseUrl, supabaseServiceKey);

// Cache des sources détectées pour éviter les re-calculs
const sourceCache = new Map();

// Fonction de détection de source améliorée (intégrée)
async function enhancedExtractSourceFromLink(link, articleContent = null) {
  if (!link) return 'Source inconnue';
  
  try {
    const url = new URL(link);
    let domain = url.hostname.toLowerCase().replace(/^(www\.|m\.|mobile\.|amp\.)/, '');
    
    // Vérifier le cache
    if (sourceCache.has(domain)) {
      return sourceCache.get(domain);
    }
    
    // Niveau 1: Mapping existant
    const mappedSource = getExistingMapping(domain, url.pathname);
    if (mappedSource !== domain) {
      sourceCache.set(domain, mappedSource);
      return mappedSource;
    }
    
    // Niveau 2: Transformation intelligente du domaine
    const transformedSource = smartDomainTransform(domain);
    if (transformedSource !== domain && transformedSource.length > 3) {
      sourceCache.set(domain, transformedSource);
      return transformedSource;
    }
    
    return domain;
    
  } catch (error) {
    console.error('Erreur extraction source:', error);
    return 'Source inconnue';
  }
}

// Mapping des sources existantes
function getExistingMapping(domain, path = '') {
  // Pour Facebook, identifier les pages spécifiques
  if (domain.includes('facebook.com') && path) {
    const fbPath = path.split('/')[1];
    if (fbPath) {
      const fbPages = {
        'CommunicationGOUVGA': 'Communication Gouvernementale',
        'tvgabon24': 'Gabon 24',
        'AgricultureGOUVGA': 'Ministère de l\'Agriculture',
        'NumeriqueGOUVGA': 'Ministère de l\'Economie Numérique',
        'EducationGOUVGA': 'Ministère de l\'Education Nationale',
        'EsupGOUVGA': 'Ministère de l\'Enseignement Supérieur',
        'ministereindustriegabon': 'Ministère de l\'Industrie',
        'InterieurGOUVGA': 'Ministère de l\'Intérieur',
        'CommunicationEnGOUVGA': 'Ministère de la Communication',
        'JusticeGOUVGA': 'Ministère de la Justice',
        'MinesGOUVGA': 'Ministère des Mines',
        'TransportsGOUVGA': 'Ministère des Transports',
        'EquipementGOUVGA': 'Ministère des Travaux Publics',
        'CommercePmePmiGOUVGA': 'Ministère du Commerce',
        'PetroleGOUVGA': 'Ministère du Pétrole',
        'TourismeGOUVGA': 'Ministère du Tourisme',
        'TravailGOUVGA': 'Ministère du Travail'
      };
      
      if (fbPages[fbPath]) {
        return fbPages[fbPath];
      }
    }
  }
  
  const sourceMap = {
    // Sources d'actualités principales
    'echosdeleco.com': 'Echos de l\'Eco',
    'gabonactu.com': 'Gabon Actu',
    'agpgabon.ga': 'AGP - Agence Gabonaise de Presse',
    'gabonallsport.com': 'Gabon All Sport',
    'gaboneco.com': 'GabonEco',
    'mediapostegabon.com': 'MediaPost Gabon',
    'union.sonapresse.com': 'L\'Union',
    '7joursinfo.com': '7 Jours Info',
    'gabonmediatime.com': 'Gabon Media Time',
    'gabonmailinfos.com': 'Gabon Mail Infos',
    'africaintelligence.fr': 'Africa Intelligence',
    'agencequateur.com': 'Agence Equateur',
    'courrierdesjournalistes.net': 'Courrier des Journalistes',
    'directinfosgabon.com': 'Direct Infos Gabon',
    'focusgroupemedia.com': 'Focus Groupe Media',
    'afrique.latribune.fr': 'La Tribune Afrique',
    'rfi.fr': 'RFI',
    'gabonews.com': 'Gabonews',
    'depeches241.com': 'Dépêches 241',
    'fr.infosgabon.com': 'Infos Gabon',
    'infosgabon.com': 'Infos Gabon',
    'insidenews241.com': 'Inside News 241',
    'journaldugabon.com': 'Journal du Gabon',
    'kongossanews.info': 'Kongossa News',
    'letouracovert.com': 'Le Touraco Vert',
    'sport241.com': 'Sport 241',
    'gabonreview.com': 'Gabon Review',
    'infogabon.ga': 'Info Gabon',
    'directinfos.ga': 'Direct Infos',
    'legabonais.com': 'Le Gabonais',
    'alibreville.com': 'A Libreville',
    'lequotidien-ga.com': 'Le Quotidien',
    'agp.ga': 'AGP'
  };
  
  // Correspondance exacte
  if (sourceMap[domain]) {
    return sourceMap[domain];
  }
  
  // Correspondance partielle
  for (const [mappedDomain, sourceName] of Object.entries(sourceMap)) {
    if (domain.includes(mappedDomain) || mappedDomain.includes(domain)) {
      return sourceName;
    }
  }
  
  return domain;
}

// Transformation intelligente du domaine
function smartDomainTransform(domain) {
  // Supprimer TLD et nettoyer
  let name = domain
    .replace(/\.(com|ga|net|org|info|fr)$/i, '')
    .replace(/^(www|m|mobile|amp)\./, '');
  
  // Transformations spéciales pour le Gabon
  name = name
    .replace(/gabon/gi, 'Gabon')
    .replace(/241/g, '241')
    .replace(/news/gi, 'News')
    .replace(/info/gi, 'Info')
    .replace(/media/gi, 'Media')
    .replace(/journal/gi, 'Journal')
    .replace(/presse/gi, 'Presse')
    .replace(/actu/gi, 'Actu');
  
  // Diviser sur les délimiteurs et capitaliser
  const words = name.split(/[-_.]/).filter(word => word.length > 0);
  
  if (words.length > 1) {
    return words.map(word => 
      word.charAt(0).toUpperCase() + word.slice(1).toLowerCase()
    ).join(' ');
  }
  
  // Si un seul mot, capitaliser proprement
  if (name.length > 3) {
    return name.charAt(0).toUpperCase() + name.slice(1).toLowerCase();
  }
  
  return domain; // Fallback
}

// Fonction principale pour traiter les articles récents
async function processRecentSources() {
  try {
    console.log('🕐 Démarrage du traitement des sources des articles récents (24h)...');
    
    const startTime = Date.now();
    
    // Calculer la date limite (24h en arrière)
    const twentyFourHoursAgo = new Date(Date.now() - 24 * 60 * 60 * 1000).toISOString();
    
    // Récupérer les articles récents avec des sources problématiques
    const { data: articles, error } = await supabase
      .from('articles')
      .select('id, url, title, content, summary, source, created_at')
      .gte('created_at', twentyFourHoursAgo)
      .or('source.is.null,source.eq.Source inconnue,source.like.%.com,source.like.%.ga,source.like.%.net,source.like.%.org,source.like.%.fr')
      .order('created_at', { ascending: false });

    if (error) {
      console.error('❌ Erreur récupération articles récents:', error);
      return { success: false, error: error.message };
    }

    if (!articles || articles.length === 0) {
      return { 
        success: true, 
        message: 'Aucun article récent avec source problématique trouvé',
        processed: 0,
        updated: 0 
      };
    }

    console.log(`📰 ${articles.length} articles récents à traiter`);
    
    let processed = 0;
    let updated = 0;
    let errors = 0;
    const results = [];
    const stats = {
      bySource: {},
      updateMethods: {
        mapping: 0,
        transform: 0,
        unchanged: 0
      }
    };

    for (const article of articles) {
      try {
        console.log(`🔄 Traitement: ${article.title?.substring(0, 60)}...`);
        
        const oldSource = article.source || 'null';
        
        // Extraire la nouvelle source avec le système amélioré
        const newSource = await enhancedExtractSourceFromLink(
          article.url, 
          article.content || article.summary
        );
        
        // Vérifier si la source a changé et est valide
        const isImprovedSource = newSource && 
                                newSource !== 'Source inconnue' && 
                                newSource !== oldSource &&
                                !newSource.includes('.com') &&
                                !newSource.includes('.ga') &&
                                newSource.length > 2;
        
        if (isImprovedSource) {
          // Mettre à jour l'article
          const { error: updateError } = await supabase
            .from('articles')
            .update({ source: newSource })
            .eq('id', article.id);
            
          if (!updateError) {
            updated++;
            
            // Statistiques
            if (!stats.bySource[newSource]) {
              stats.bySource[newSource] = 0;
            }
            stats.bySource[newSource]++;
            
            // Déterminer la méthode utilisée
            const wasMapped = getExistingMapping(new URL(article.url).hostname.toLowerCase().replace(/^(www\.|m\.|mobile\.|amp\.)/, '')) !== new URL(article.url).hostname.toLowerCase().replace(/^(www\.|m\.|mobile\.|amp\.)/, '');
            if (wasMapped) {
              stats.updateMethods.mapping++;
            } else {
              stats.updateMethods.transform++;
            }
            
            console.log(`✅ "${oldSource}" → "${newSource}"`);
            
            results.push({
              id: article.id,
              title: article.title?.substring(0, 50) + '...',
              url: article.url,
              oldSource: oldSource,
              newSource: newSource,
              status: 'updated',
              createdAt: article.created_at
            });
          } else {
            console.error(`❌ Erreur mise à jour ${article.id}:`, updateError);
            errors++;
            results.push({
              id: article.id,
              status: 'error',
              error: updateError.message
            });
          }
        } else {
          stats.updateMethods.unchanged++;
          results.push({
            id: article.id,
            status: 'skipped',
            reason: `Source non améliorée: "${oldSource}" → "${newSource}"`
          });
        }
        
        processed++;
        
        // Pause légère entre articles
        if (processed % 5 === 0) {
          await new Promise(resolve => setTimeout(resolve, 100));
        }
        
      } catch (articleError) {
        console.error(`❌ Erreur traitement article ${article.id}:`, articleError);
        errors++;
        results.push({
          id: article.id,
          status: 'error',
          error: articleError.message
        });
        processed++;
      }
    }

    const duration = Math.round((Date.now() - startTime) / 1000);
    
    console.log(`🎉 Traitement terminé: ${updated}/${processed} sources mises à jour en ${duration}s`);
    console.log('📊 Sources mises à jour:', Object.keys(stats.bySource).length);
    
    // Log des résultats dans Supabase
    try {
      await supabase
        .from('sync_logs')
        .insert({
          sync_type: 'recent_sources_processing',
          total_articles: updated,
          errors: errors,
          duration_ms: Date.now() - startTime,
          status: errors === 0 ? 'success' : 'partial_success',
          details: { 
            processed, 
            updated, 
            errors,
            stats,
            cache_size: sourceCache.size 
          }
        });
    } catch (logError) {
      console.warn('Erreur log:', logError);
    }
    
    return {
      success: true,
      processed,
      updated,
      errors,
      duration,
      results: results.slice(0, 20), // Limiter pour la réponse
      stats,
      cacheSize: sourceCache.size,
      message: `${updated} sources mises à jour sur ${processed} articles récents (${duration}s)`
    };

  } catch (error) {
    console.error('❌ Erreur traitement sources récentes:', error);
    return {
      success: false,
      error: error.message,
      processed: 0,
      updated: 0
    };
  }
}

// Handler Netlify
// Export principal pour Netlify
exports.handler = async (event, context) => {
  context.callbackWaitsForEmptyEventLoop = false;
  
  const headers = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'Content-Type',
    'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
    'Content-Type': 'application/json'
  };

  if (event.httpMethod === 'OPTIONS') {
    return { statusCode: 200, headers, body: '' };
  }

  try {
    if (!supabaseUrl || !supabaseServiceKey) {
      return {
        statusCode: 500,
        headers,
        body: JSON.stringify({
          success: false,
          error: 'Configuration Supabase manquante'
        })
      };
    }
    
    console.log('🚀 Lancement traitement sources articles récents (24h)');
    
    // Traitement avec timeout de 8 minutes
    const result = await Promise.race([
      processRecentSources(),
      new Promise((_, reject) => 
        setTimeout(() => reject(new Error('Timeout fonction (8min)')), 480000)
      )
    ]);
    
    return {
      statusCode: 200,
      headers,
      body: JSON.stringify({
        ...result,
        timestamp: new Date().toISOString(),
        timeframe: '24h'
      })
    };
    
  } catch (error) {
    console.error('❌ Erreur handler:', error);
    
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({
        success: false,
        error: 'Erreur traitement sources récentes',
        message: error.message
      })
    };
  }
};

// Export des fonctions pour tests
exports.processRecentSources = processRecentSources;
