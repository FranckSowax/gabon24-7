const { createClient } = require('@supabase/supabase-js');

// Fonction pour extraire le nom de la source depuis l'URL
function extractSourceFromUrl(url) {
  if (!url) return null;
  
  try {
    const urlObj = new URL(url);
    const domain = urlObj.hostname.toLowerCase();
    const path = urlObj.pathname;
    
    // Pour Facebook, vérifier le path complet pour identifier le ministère/page
    if (domain.includes('facebook.com') && path) {
      const fbPath = path.split('/')[1]; // Récupérer le nom de la page
      if (fbPath) {
        // Mapping spécifique pour les pages Facebook
        const fbPages = {
          'CommunicationGOUVGA': 'Communication Gouvernementale',
          'tvgabon24': 'Gabon 24',
          'AgricultureGOUVGA': 'Ministère de l\'Agriculture',
          'NumeriqueGOUVGA': 'Ministère de l\'Economie Numérique',
          'EducationGOUVGA': 'Ministère de l\'Education Nationale',
          'EsupGOUVGA': 'Ministère de l\'Enseignement Supérieur',
          'ministereindustriegabon': 'Ministère de l\'Industrie',
          'InterieurGOUVGA': 'Ministère de l\'Intérieur',
          'CommunicationEnGOUVGA': 'Ministère de la Communication',
          'JusticeGOUVGA': 'Ministère de la Justice',
          'MinesGOUVGA': 'Ministère des Mines',
          'TransportsGOUVGA': 'Ministère des Transports',
          'EquipementGOUVGA': 'Ministère des Travaux Publics',
          'CommercePmePmiGOUVGA': 'Ministère du Commerce',
          'PetroleGOUVGA': 'Ministère du Pétrole',
          'TourismeGOUVGA': 'Ministère du Tourisme',
          'TravailGOUVGA': 'Ministère du Travail'
        };
        
        if (fbPages[fbPath]) {
          return fbPages[fbPath];
        }
      }
    }
    
    const sourceMap = {
      // Sources d'actualités principales
      'echosdeleco.com': 'Echos de l\'Eco',
      'gabonactu.com': 'Gabon Actu',
      'agpgabon.ga': 'AGP - Agence Gabonaise de Presse',
      'gabonallsport.com': 'Gabon All Sport',
      'gaboneco.com': 'GabonEco',
      'mediapostegabon.com': 'MediaPost Gabon',
      'union.sonapresse.com': "L'Union",
      '7joursinfo.com': '7 Jours Info',
      'gabonmediatime.com': 'Gabon Media Time',
      'gabonmailinfos.com': 'Gabon Mail Infos',
      'africaintelligence.fr': 'Africa Intelligence',
      'agencequateur.com': 'Agence Equateur',
      'courrierdesjournalistes.net': 'Courrier des Journalistes',
      'directinfosgabon.com': 'Direct Infos Gabon',
      'focusgroupemedia.com': 'Focus Groupe Media',
      'afrique.latribune.fr': 'La Tribune Afrique',
      'rfi.fr': 'RFI',
      'gabonews.com': 'Gabonews',
      'depeches241.com': 'Dépêches 241',
      'fr.infosgabon.com': 'InfosGabon',
      'infosgabon.com': 'InfosGabon',
      'infogabon.net': 'Info Gabon',
      'gabon-info.com': 'Gabon Infos',
      'gabonreview.com': 'Gabon Review',
      'lalibreville.com': 'La Libreville',
      'gabon1er.com': 'Gabon 1er',
      'insidenews241.com': 'Inside News 241',
      'sport241.com': 'Sport 241',
      'gabonclic.info': 'Gabon Clic',
      'vxp241.com': 'Vox Populi 241',
      'letouracovert.com': 'Le Touraco vert',
      'leconfidentiel.ga': 'Le Confidentiel',
      'youtube.com': 'YouTube',
      'facebook.com': 'Facebook'
    };
    
    return sourceMap[domain] || null;
  } catch (error) {
    return null;
  }
}

// Fonction pour extraire la source depuis le nom de l'auteur (ministères)
function extractSourceFromAuthor(author) {
  if (!author) return null;
  
  const authorLower = author.toLowerCase();
  
  // Mapping des noms d'auteurs vers les sources ministérielles
  const authorMap = {
    'travail': 'Ministère du Travail',
    'energie': 'Ministère de l\'Energie',
    'agriculture': 'Ministère de l\'Agriculture',
    'education': 'Ministère de l\'Education Nationale',
    'enseignement': 'Ministère de l\'Enseignement Supérieur',
    'industrie': 'Ministère de l\'Industrie',
    'intérieur': 'Ministère de l\'Intérieur',
    'communication': 'Ministère de la Communication',
    'justice': 'Ministère de la Justice',
    'mines': 'Ministère des Mines',
    'transports': 'Ministère des Transports',
    'travaux': 'Ministère des Travaux Publics',
    'commerce': 'Ministère du Commerce',
    'pétrole': 'Ministère du Pétrole',
    'tourisme': 'Ministère du Tourisme',
    'economie numérique': 'Ministère de l\'Economie Numérique',
    'numérique': 'Ministère de l\'Economie Numérique',
    'communication gouvernementale': 'Communication Gouvernementale',
    'gabon 24': 'Gabon 24',
    'equateur': 'Agence Equateur',
    'focus groupe media': 'Focus Groupe Media',
    'daniel dematsatsa': 'Sport 241'
  };
  
  // Chercher une correspondance partielle
  for (const [key, value] of Object.entries(authorMap)) {
    if (authorLower.includes(key)) {
      return value;
    }
  }
  
  return null;
}

// Fonction pour extraire la source depuis le chemin de l'URL (cas spéciaux)
function extractSourceFromUrlPath(url) {
  if (!url) return null;
  
  try {
    // Détecter Focus Groupe Media par le chemin /author/redaction/
    if (url.includes('focusgroupemedia.com/author/redaction/')) {
      return 'Focus Groupe Media';
    }
    
    return null;
  } catch (error) {
    return null;
  }
}

// Configuration Supabase avec validation
const supabaseUrl = process.env.SUPABASE_URL;
const supabaseServiceKey = process.env.SUPABASE_SERVICE_ROLE_KEY;

if (!supabaseUrl || !supabaseServiceKey) {
  console.error('❌ Variables d\'environnement manquantes:', {
    SUPABASE_URL: !!supabaseUrl,
    SUPABASE_SERVICE_ROLE_KEY: !!supabaseServiceKey
  });
}

const supabase = createClient(supabaseUrl, supabaseServiceKey);

exports.handler = async (event, context) => {
  // Headers CORS
  const headers = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'Content-Type',
    'Access-Control-Allow-Methods': 'GET, OPTIONS',
    'Cache-Control': 'no-cache, no-store, must-revalidate',
    'Pragma': 'no-cache',
    'Expires': '0',
    'Content-Type': 'application/json'
  };

  // Gestion des requêtes OPTIONS (preflight)
  if (event.httpMethod === 'OPTIONS') {
    return {
      statusCode: 200,
      headers,
      body: ''
    };
  }

  if (event.httpMethod !== 'GET') {
    return {
      statusCode: 405,
      headers,
      body: JSON.stringify({ error: 'Method Not Allowed' })
    };
  }

  try {
    // Vérification des variables d'environnement
    if (!supabaseUrl || !supabaseServiceKey) {
      return {
        statusCode: 500,
        headers,
        body: JSON.stringify({
          success: false,
          error: 'Configuration manquante',
          message: 'Variables d\'environnement Supabase non configurées'
        })
      };
    }

    // Extraire le paramètre tab depuis l'URL
    const { tab } = event.queryStringParameters || {};
    
    console.log('🔍 Récupération des articles depuis Supabase...');

    // Requête de base avec jointure LEFT pour inclure les articles du bundle RSS
    let query = supabase
      .from('articles')
      .select(`
        *,
        rss_feeds (
          name,
          category,
          description,
          url
        )
      `)
      .eq('is_published', true);

    // Filtrage par onglet
    const now = new Date();
    
    switch (tab) {
      case 'week':
      case 'cette-semaine':
        // Articles de plus de 36h jusqu'à 7 jours
        const weekAgo = new Date(now.getTime() - (7 * 24 * 60 * 60 * 1000));
        const dayAndHalfAgo = new Date(now.getTime() - (36 * 60 * 60 * 1000));
        console.log(`📅 Filtre Cette semaine: ${weekAgo.toISOString()} à ${dayAndHalfAgo.toISOString()}`);
        query = query
          .gte('published_at', weekAgo.toISOString())
          .lt('published_at', dayAndHalfAgo.toISOString());
        break;
      case 'archives':
        // Articles de plus de 7 jours
        const weekAgoArchives = new Date(now.getTime() - (7 * 24 * 60 * 60 * 1000));
        console.log(`📚 Filtre Archives: articles avant ${weekAgoArchives.toISOString()}`);
        query = query.lt('published_at', weekAgoArchives.toISOString());
        break;
      case 'home':
      case 'pour-vous':
      default:
        // Articles des dernières 36h (page d'aujourd'hui)
        const dayAndHalfAgoHome = new Date(now.getTime() - (36 * 60 * 60 * 1000));
        console.log(`🏠 Filtre Accueil: articles après ${dayAndHalfAgoHome.toISOString()}`);
        query = query.gte('published_at', dayAndHalfAgoHome.toISOString());
        break;
    }

    const { data: articles, error } = await query
      .order('published_at', { ascending: false });

    if (error) {
      console.error('❌ Erreur Supabase:', error);
      throw error;
    }

    console.log(`✅ ${articles?.length || 0} articles récupérés pour ${tab || 'home'}`);
    console.log(`🔍 DEBUG - Premier article: ${articles?.[0]?.title} - ${articles?.[0]?.published_at}`);
    console.log(`🔍 DEBUG - Deuxième article: ${articles?.[1]?.title} - ${articles?.[1]?.published_at}`);

    // Fonction pour traiter les URLs d'images
    const processImageUrl = (imageUrl) => {
      if (!imageUrl) {
        return `https://picsum.photos/800/400?random=${Math.random()}`;
      }
      
      // Utiliser le proxy pour les images Facebook, Gabon Media Time, Gabon 24 et Gabon Actu
      if (imageUrl.includes('fbcdn.net') || 
          imageUrl.includes('facebook.com') || 
          imageUrl.includes('gabonmediatime.com') ||
          imageUrl.includes('tvgabon24.com') ||
          imageUrl.includes('gabon24.com') ||
          imageUrl.includes('gabonactu.com')) {
        return `/.netlify/functions/image-proxy?url=${encodeURIComponent(imageUrl)}`;
      }
      
      // S'assurer que l'URL est en HTTPS
      if (imageUrl.startsWith('http://')) {
        return imageUrl.replace('http://', 'https://');
      }
      
      return imageUrl;
    };

    // Transformation des articles pour le frontend avec filtrage des articles incomplets
    const transformedArticles = articles?.filter(article => {
      // Filtrer les articles sans contenu réel (posts Facebook vides, etc.)
      const hasValidSummary = article.summary && article.summary !== 'Résumé non disponible' && article.summary.length > 20;
      const hasValidAiSummary = article.ai_summary && article.ai_summary.length > 20;
      const hasValidContent = article.content && article.content.length > 50;
      
      // Garder l'article s'il a au moins un résumé valide ou du contenu
      return hasValidSummary || hasValidAiSummary || hasValidContent;
    }).map(article => ({
      id: article.id,
      title: article.title,
      summary: article.ai_summary || article.summary || (article.content ? article.content.substring(0, 200) + '...' : 'Résumé non disponible'),
      content: article.content || article.ai_summary || article.summary || '',
      url: article.url,
      imageUrl: processImageUrl(article.image_url),
      author: article.author || 'Rédaction',
      publishedAt: article.published_at,
      published_at: article.published_at,
      created_at: article.created_at,
      source: article.rss_feeds?.name || extractSourceFromUrl(article.url) || extractSourceFromAuthor(article.author) || extractSourceFromUrlPath(article.url) || 'Source inconnue',
      category: article.category || article.rss_feeds?.category || 'actualités',
      viewCount: `${article.view_count || 0} vue${(article.view_count || 0) > 1 ? 's' : ''}`,
      view_count: article.view_count || 0,
      sentiment: article.sentiment || 'neutre',
      keywords: article.keywords || [],
      readTime: `${article.read_time_minutes || 2} min`
    })) || [];

    return {
      statusCode: 200,
      headers,
      body: JSON.stringify({
        success: true,
        articles: transformedArticles,
        total: transformedArticles.length,
        tab: tab || 'home',
        timestamp: new Date().toISOString()
      })
    };

  } catch (error) {
    console.error('❌ Erreur dans articles function:', error);
    console.error('Stack trace:', error.stack);
    
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({
        success: false,
        error: 'Erreur serveur',
        message: error.message,
        details: process.env.NODE_ENV === 'development' ? error.stack : undefined
      })
    };
  }
};
